import { useEffect } from 'react';
import { Routes, Route, Link, useLocation, useNavigate } from "react-router-dom";
import { Toaster } from "react-hot-toast";

// Contexts
import { AuthProvider } from "./contexts/AuthContext";
import { CompanyProvider } from './contexts/CompanyContext';
import { AdminProvider } from "./contexts/AdminContext";
import { useAuth } from "./contexts/AuthContext";

// Components
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import ProtectedRoute from "./components/ProtectedRoute";
import AdminLayout from "./components/admin/AdminLayout";
import Chatbot from "./components/Chatbot";

// Company Components
import CompanyRoute from "./routes/CompanyRoute";
import CompanyAuth from "./pages/Auth/CompanyAuth";
import RegisterCompany from "./pages/company/RegisterCompany";
import CompanyDashboard from "./pages/company/CompanyDashboard";
import CompanyJobs from "./pages/company/CompanyJobs";
import CreateJob from "./pages/company/CreateJob";
import EditJob from "./pages/company/EditJob";
import JobApplications from "./pages/company/JobApplications";
import InternshipManagement from "./pages/company/InternshipManagement";
import CreateInternship from "./pages/company/CreateInternship";
import EditInternship from "./pages/company/EditInternship";
import InternshipApplications from "./pages/company/InternshipApplications";
import CompanyProfile from "./pages/company/CompanyProfile";
import Reports from "./pages/company/Reports";
import CompanyApplications from "./pages/company/CompanyApplications";
import Pricing from "./pages/company/Pricing";
import CompanyStatusCheck from "./components/company/CompanyStatusCheck";

// Admin Components
import AdminRoute from "./routes/AdminRoute";
import AdminLogin from "./pages/admin/AdminLogin";
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminCompanies from "./pages/admin/AdminCompanies";
import AdminUsers from "./pages/admin/AdminUsers";
import AdminJobs from "./pages/admin/AdminJobs";
import AdminSubscriptions from "./pages/admin/AdminSubscriptions";
import AdminReports from "./pages/admin/AdminReports";
import AdminSettings from "./pages/admin/AdminSettings";
import AdminLogs from "./pages/admin/AdminLogs";
import AdminProfile from "./pages/admin/AdminProfile";
import AdminSetup from "./pages/admin/AdminSetup";

// Pages
import Home from "./pages/Home";
import Login from "./pages/Auth/Login";
import Register from "./pages/Auth/Register";
import ForgotPassword from "./pages/Auth/ForgotPassword";
import EmailVerification from "./pages/Auth/EmailVerification";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import Dashboard from "./pages/Dashboard";
import Courses from "./pages/Courses";
import CourseDetail from "./pages/CourseDetail";
import Jobs from "./pages/Jobs";
import JobDetail from "./pages/JobDetail";
import Internships from "./pages/Internships";
import InternshipDetail from "./pages/InternshipDetail";
import Applications from "./pages/Applications";
import Favorites from "./pages/Favorites";
import Notifications from "./pages/Notifications";
import Leaderboard from "./pages/Leaderboard";
import PointsSystem from "./pages/PointsSystem";
import DatabaseDebug from "./pages/DatabaseDebug";

// Footer Pages
import HowItWorks from "./pages/HowItWorks";
import About from "./pages/About";
import Contact from "./pages/Contact";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import TermsOfService from "./pages/TermsOfService";

// 404 Page
const NotFound = () => (
  <div className="flex flex-col items-center justify-center min-h-[60vh]">
    <h1 className="text-6xl font-bold text-purple-600 mb-4">404</h1>
    <p className="text-xl text-gray-600 mb-8">Sayfa bulunamadı</p>
    <Link 
      to="/" 
      className="inline-flex items-center justify-center gap-2 px-6 py-3 text-base font-semibold text-white bg-purple-600 rounded-lg shadow-md transition-all duration-200 hover:bg-purple-700 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2"
    >
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
      </svg>
      <span>Ana Sayfaya Dön</span>
    </Link>
  </div>
);

// Global Route Control Component
function GlobalRouteControl({ children }) {
  const { user, userType, loading } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && user && userType) {
      // İşletme hesabı öğrenci rotalarına girmeye çalışıyorsa
      const studentOnlyPaths = [
        '/courses', 
        '/jobs', 
        '/internships', 
        '/applications', 
        '/favorites',
        '/notifications',
        '/leaderboard',
        '/profile',
        '/dashboard',
        '/settings'
      ];
      
      // Admin sayfalarını kontrol et
      const adminPaths = [
        '/admin/dashboard',
        '/admin/companies',
        '/admin/users',
        '/admin/jobs',
        '/admin/subscriptions',
        '/admin/reports',
        '/admin/settings',
        '/admin/logs',
        '/admin/profile'
      ];
      
      // Öğrenci sayfalarını kontrol et (detay sayfaları dahil)
      const isStudentPath = studentOnlyPaths.some(path => 
        location.pathname === path || 
        location.pathname.startsWith(path + '/')
      );

      // Admin sayfalarını kontrol et
      const isAdminPath = adminPaths.some(path => 
        location.pathname === path || 
        location.pathname.startsWith(path + '/')
      );

      if (userType === 'company' && isStudentPath) {
        console.log('İşletme hesabı öğrenci sayfasına erişmeye çalışıyor, yönlendiriliyor...');
        navigate('/company/dashboard', { replace: true });
        return;
      }

      // Öğrenci hesabı işletme rotalarına girmeye çalışıyorsa
      if (userType === 'student' && location.pathname.startsWith('/company/')) {
        console.log('Öğrenci hesabı işletme sayfasına erişmeye çalışıyor, yönlendiriliyor...');
        navigate('/dashboard', { replace: true });
        return;
      }

      // Admin olmayan admin sayfalarına erişmeye çalışıyorsa
      if (userType !== 'admin' && isAdminPath && location.pathname !== '/admin/setup') {
        console.log('Admin olmayan kullanıcı admin sayfasına erişmeye çalışıyor, yönlendiriliyor...');
        navigate(userType === 'company' ? '/company/dashboard' : '/dashboard', { replace: true });
        return;
      }
    }
  }, [user, userType, location, navigate, loading]);

  return children;
}

// Main App Content Component
function AppContent() {
  const { user, userType, loading } = useAuth();
  const location = useLocation();
  
  // Admin sayfalarını kontrol et
  const isAdminRoute = location.pathname.startsWith('/admin/');
  const isAdminLoginRoute = location.pathname === '/admin/login';
  const isAdminSetupRoute = location.pathname === '/admin/setup';
  
  // Loading durumu
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <GlobalRouteControl>
      <div className="min-h-screen flex flex-col bg-gray-50 text-gray-800 font-sans">
        {/* Admin Layout veya Normal Layout */}
        {isAdminRoute && !isAdminLoginRoute && !isAdminSetupRoute && userType === 'admin' ? (
          // Admin Layout (AdminNavbar dahil)
          <AdminLayout>
            <Routes>
              {/* Admin Routes */}
              <Route path="/admin/dashboard" element={
                <AdminRoute>
                  <AdminDashboard />
                </AdminRoute>
              } />
              <Route path="/admin/companies" element={
                <AdminRoute>
                  <AdminCompanies />
                </AdminRoute>
              } />
              <Route path="/admin/users" element={
                <AdminRoute>
                  <AdminUsers />
                </AdminRoute>
              } />
              <Route path="/admin/jobs" element={
                <AdminRoute>
                  <AdminJobs />
                </AdminRoute>
              } />
              <Route path="/admin/subscriptions" element={
                <AdminRoute>
                  <AdminSubscriptions />
                </AdminRoute>
              } />
              <Route path="/admin/reports" element={
                <AdminRoute>
                  <AdminReports />
                </AdminRoute>
              } />
              <Route path="/admin/settings" element={
                <AdminRoute>
                  <AdminSettings />
                </AdminRoute>
              } />
              <Route path="/admin/logs" element={
                <AdminRoute>
                  <AdminLogs />
                </AdminRoute>
              } />
              <Route path="/admin/profile" element={
                <AdminRoute>
                  <AdminProfile />
                </AdminRoute>
              } />
            </Routes>
          </AdminLayout>
        ) : (
          // Normal Layout (Student/Company)
          <>
            {/* Normal sayfalar için Navbar göster (admin login/setup hariç) */}
            {!isAdminLoginRoute && !isAdminSetupRoute && <Navbar />}
            
            <main className="flex-grow px-4 md:px-8 py-8 w-full max-w-6xl mx-auto">
              <Routes>
                {/* Public Routes */}
                <Route path="/" element={<Home />} />
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="/forgot-password" element={<ForgotPassword />} />
                <Route path="/email-verification" element={<EmailVerification />} />

                {/* Company Auth Routes - PUBLIC */}
                <Route path="/company/auth" element={<CompanyAuth />} />

                {/* Admin Auth Routes - PUBLIC */}
                <Route path="/admin/login" element={<AdminLogin />} />
                <Route path="/admin/setup" element={<AdminSetup />} />

                {/* Protected Student Routes */}
                <Route path="/dashboard" element={
                  <ProtectedRoute>
                    <Dashboard />
                  </ProtectedRoute>
                } />
                <Route path="/profile" element={
                  <ProtectedRoute>
                    <Profile />
                  </ProtectedRoute>
                } />
                <Route path="/settings" element={
                  <ProtectedRoute>
                    <Settings />
                  </ProtectedRoute>
                } />
                <Route path="/courses" element={
                  <ProtectedRoute>
                    <Courses />
                  </ProtectedRoute>
                } />
                <Route path="/courses/:id" element={
                  <ProtectedRoute>
                    <CourseDetail />
                  </ProtectedRoute>
                } />
                <Route path="/jobs" element={
                  <ProtectedRoute>
                    <Jobs />
                  </ProtectedRoute>
                } />
                <Route path="/jobs/:id" element={
                  <ProtectedRoute>
                    <JobDetail />
                  </ProtectedRoute>
                } />
                <Route path="/internships" element={
                  <ProtectedRoute>
                    <Internships />
                  </ProtectedRoute>
                } />
                <Route path="/internships/:id" element={
                  <ProtectedRoute>
                    <InternshipDetail />
                  </ProtectedRoute>
                } />
                <Route path="/applications" element={
                  <ProtectedRoute>
                    <Applications />
                  </ProtectedRoute>
                } />
                <Route path="/favorites" element={
                  <ProtectedRoute>
                    <Favorites />
                  </ProtectedRoute>
                } />
                <Route path="/notifications" element={
                  <ProtectedRoute>
                    <Notifications />
                  </ProtectedRoute>
                } />
                <Route path="/leaderboard" element={
                  <ProtectedRoute>
                    <Leaderboard />
                  </ProtectedRoute>
                } />
                <Route path="/points-system" element={<PointsSystem />} />
                
                {/* Footer Pages */}
                <Route path="/how-it-works" element={<HowItWorks />} />
                <Route path="/about" element={<About />} />
                <Route path="/contact" element={<Contact />} />
                <Route path="/privacy-policy" element={<PrivacyPolicy />} />
                <Route path="/terms-of-service" element={<TermsOfService />} />
                
                {/* Debug Route */}
                <Route path="/debug" element={
                  <ProtectedRoute>
                    <DatabaseDebug />
                  </ProtectedRoute>
                } />

                {/* Company Protected Routes */}
                <Route path="/company/dashboard" element={
                  <CompanyRoute>
                    <CompanyDashboard />
                  </CompanyRoute>
                } />
                <Route path="/company/register" element={
                  <CompanyRoute>
                    <RegisterCompany />
                  </CompanyRoute>
                } />
                <Route path="/company/jobs" element={
                  <CompanyRoute>
                    <CompanyJobs />
                  </CompanyRoute>
                } />
                <Route path="/company/jobs/create" element={
                  <CompanyRoute>
                    <CompanyStatusCheck>
                      <CreateJob />
                    </CompanyStatusCheck>
                  </CompanyRoute>
                } />
                <Route path="/company/jobs/:id/edit" element={
                  <CompanyRoute>
                    <CompanyStatusCheck>
                      <EditJob />
                    </CompanyStatusCheck>
                  </CompanyRoute>
                } />
                <Route path="/company/jobs/:id/applications" element={
                  <CompanyRoute>
                    <JobApplications />
                  </CompanyRoute>
                } />
                <Route path="/company/internships" element={
                  <CompanyRoute>
                    <InternshipManagement />
                  </CompanyRoute>
                } />
                <Route path="/company/internships/create" element={
                  <CompanyRoute>
                    <CompanyStatusCheck>
                      <CreateInternship />
                    </CompanyStatusCheck>
                  </CompanyRoute>
                } />
                <Route path="/company/internships/:id/edit" element={
                  <CompanyRoute>
                    <CompanyStatusCheck>
                      <EditInternship />
                    </CompanyStatusCheck>
                  </CompanyRoute>
                } />
                <Route path="/company/internships/:id/applications" element={
                  <CompanyRoute>
                    <InternshipApplications />
                  </CompanyRoute>
                } />  
                <Route path="/company/profile" element={
                  <CompanyRoute>
                    <CompanyProfile />
                  </CompanyRoute>
                } />
                <Route path="/company/reports" element={
                  <CompanyRoute>
                    <Reports />
                  </CompanyRoute>
                } />
                <Route path="/company/applications" element={
                  <CompanyRoute>
                    <CompanyApplications />
                  </CompanyRoute>
                } />
                <Route path="/company/pricing" element={
                  <CompanyRoute>
                    <Pricing />
                  </CompanyRoute>
                } />

                {/* 404 Route */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </main>
            
            {/* Normal sayfalar için Footer göster (admin hariç) */}
            {!isAdminLoginRoute && !isAdminSetupRoute && !isAdminRoute && <Footer />}

            {/* Chatbot Component - Sadece öğrenci kullanıcılar için */}
            {user && userType === 'student' && <Chatbot />}
          </>
        )}

        {/* Toast Notifications */}
        <Toaster 
          position="top-right"
          toastOptions={{
            duration: 3000,
            style: {
              background: '#5A31F4',
              color: '#fff',
              fontWeight: 'bold',
              borderRadius: '12px',
              padding: '12px 20px',
            },
            success: {
              iconTheme: {
                primary: '#22c55e',
                secondary: '#fff',
              },
            },
            error: {
              iconTheme: {
                primary: '#ef4444',
                secondary: '#fff',
              },
            },
          }}
        />
      </div>
    </GlobalRouteControl>
  );
}

// Main App Export
export default function App() {
  return (
    <AuthProvider>
      <AdminProvider>
        <CompanyProvider>
          <AppContent />
        </CompanyProvider>
      </AdminProvider>
    </AuthProvider>
  );
}