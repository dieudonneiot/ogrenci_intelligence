// src/components/HowItWorks.jsx
import { 
  BookOpenCheck, 
  BriefcaseBusiness, 
  Users, 
  Trophy,
  ArrowRight 
} from "lucide-react";
import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";

const steps = [
  {
    icon: <BookOpenCheck className="h-10 w-10 text-indigo-600" />,
    title: "Eğitim Modülü",
    description: "Alanına özel temel bilgiler, video anlatımlar ve mini sınavlarla kariyer yolculuğuna güçlü bir başlangıç yap.",
    color: "bg-indigo-50",
    borderColor: "border-indigo-200",
  },
  {
    icon: <BriefcaseBusiness className="h-10 w-10 text-purple-600" />,
    title: "Saha Uygulaması",
    description: "Teorik bilgilerini pratikte uygulayarak gerçek iş ortamında deneyim kazan. Mentör desteği ile gelişimini pekiştir.",
    color: "bg-purple-50",
    borderColor: "border-purple-200",
  },
  {
    icon: <Users className="h-10 w-10 text-green-600" />,
    title: "Network Oluştur",
    description: "Sektör profesyonelleri ve diğer öğrencilerle tanış, kariyer ağını genişlet ve yeni fırsatlar keşfet.",
    color: "bg-green-50",
    borderColor: "border-green-200",
  },
  {
    icon: <Trophy className="h-10 w-10 text-yellow-600" />,
    title: "Başarıyı Yakala",
    description: "Sertifikalarını al, referanslarını topla ve hayalindeki kariyere doğru emin adımlarla ilerle.",
    color: "bg-yellow-50",
    borderColor: "border-yellow-200",
  },
];

export default function HowItWorks() {
  const { user } = useAuth();
  return (
    <section className="bg-gray-50 py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Başlık */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
            Nasıl Çalışır?
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            Platformumuz dört temel aşamadan oluşur. Her adımda yanındayız!
          </p>
        </div>

        {/* Adımlar */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((step, index) => (
            <div
              key={index}
              className="relative group"
            >
              {/* Adım Kartı */}
              <div
                className={`${step.color} ${step.borderColor} border-2 rounded-2xl p-6 h-full hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1`}
              >
                {/* Adım Numarası */}
                <div className="absolute -top-3 -right-3 w-8 h-8 bg-gray-800 text-white rounded-full flex items-center justify-center font-bold text-sm">
                  {index + 1}
                </div>

                {/* İkon */}
                <div className="mb-4">{step.icon}</div>

                {/* Başlık */}
                <h3 className="text-xl font-semibold text-gray-800 mb-3">
                  {step.title}
                </h3>

                {/* Açıklama */}
                <p className="text-gray-600 text-sm leading-relaxed">
                  {step.description}
                </p>
              </div>

              {/* Ok İşareti (son eleman hariç) */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -right-3 transform -translate-y-1/2 z-10">
                  <ArrowRight className="h-6 w-6 text-gray-400" />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* CTA Butonu - Kullanıcı durumuna göre değişir */}
        <div className="text-center mt-12">
          {user ? (
            <Link
              to="/dashboard"
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                backgroundColor: '#7c3aed',
                color: '#ffffff',
                padding: '12px 32px',
                borderRadius: '12px',
                fontWeight: '600',
                fontSize: '16px',
                textDecoration: 'none',
                boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
                transition: 'all 0.2s',
                transform: 'scale(1)',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#6d28d9';
                e.currentTarget.style.transform = 'scale(1.05)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = '#7c3aed';
                e.currentTarget.style.transform = 'scale(1)';
              }}
            >
              Dashboard'a Git
              <ArrowRight className="ml-2 h-5 w-5" style={{ color: 'inherit' }} />
            </Link>
          ) : (
            <Link
              to="/register"
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                backgroundColor: '#7c3aed',
                color: '#ffffff',
                padding: '12px 32px',
                borderRadius: '12px',
                fontWeight: '600',
                fontSize: '16px',
                textDecoration: 'none',
                boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
                transition: 'all 0.2s',
                transform: 'scale(1)',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#6d28d9';
                e.currentTarget.style.transform = 'scale(1.05)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = '#7c3aed';
                e.currentTarget.style.transform = 'scale(1)';
              }}
            >
              Hemen Başla
              <ArrowRight className="ml-2 h-5 w-5" style={{ color: 'inherit' }} />
            </Link>
          )}
        </div>
      </div>
    </section>
  );
}