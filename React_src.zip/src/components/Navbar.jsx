import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { getUserTotalPoints } from "../services/pointsService";
import { 
  Menu, X, User, LogOut, Trophy, Building2, 
  Briefcase, GraduationCap, Users, TrendingUp, Plus, CreditCard
} from "lucide-react";

export default function Navbar() {
  const { user, signOut, loading, userType, companyId } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const [userPoints, setUserPoints] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    // Sadece öğrenci ise puan getir
    if (user && userType === 'student') {
      getUserTotalPoints(user.id).then(points => setUserPoints(points));
    }
  }, [user, userType]);

  const handleLogout = async () => {
    await signOut();
    setMenuOpen(false);
    navigate("/");
  };

  const closeMenu = () => setMenuOpen(false);

  // Kullanıcı bilgilerini al
  const userEmail = user?.email;
  const userName = user?.user_metadata?.full_name || userEmail?.split('@')[0];

  // Öğrenci menü öğeleri
  const studentMenuItems = [
    { label: "Anasayfa", path: "/" },
    { label: "Kurslar", path: "/courses" },
    { label: "İş İlanları", path: "/jobs" },
    { label: "Stajlar", path: "/internships" },
  ];

  // İşletme menü öğeleri
  const companyMenuItems = [
    { label: "İlanlarım", path: "/company/jobs" },
    { label: "Staj Yönetimi", path: "/company/internships" },
    { label: "Başvurular", path: "/company/applications" },
    { label: "Raporlar", path: "/company/reports" },
  ];

  // Kullanıcı tipine göre menü seçimi
  const menuItems = userType === 'company' ? companyMenuItems : studentMenuItems;

  // Profil dropdown öğeleri
  const studentDropdownItems = [
    { label: "Profilim", path: "/profile" },
    { label: "Dashboard", path: "/dashboard" },
    { label: "Başvurularım", path: "/applications" },
    { label: "Favorilerim", path: "/favorites" },
    { label: "Bildirimler", path: "/notifications" },
    { label: "Ayarlar", path: "/settings" },
  ];

  const companyDropdownItems = [
    { label: "Şirket Profili", path: "/company/profile" },
    { label: "Dashboard", path: "/company/dashboard" },
    { label: "Paketler ve Fiyatlar", path: "/company/pricing", icon: <CreditCard className="w-4 h-4 mr-2" /> },
    { label: "Ayarlar", path: "/company/settings" },
  ];

  const dropdownItems = userType === 'company' ? companyDropdownItems : studentDropdownItems;

  return (
    <nav className="bg-white shadow-md border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 py-3 flex justify-between items-center">
        {/* Logo */}
        <Link to={userType === 'company' ? "/company/dashboard" : "/"} onClick={closeMenu} className="flex items-center space-x-3">
          {userType === 'company' ? (
            <>
              <Building2 className="h-10 w-10 text-purple-700" />
              <span className="hidden md:inline text-2xl font-bold text-purple-700 tracking-tight select-none">
                İşletme Paneli
              </span>
            </>
          ) : (
            <>
              <img
                src="/logo.png"
                alt="Öğrenci Platformu Logo"
                className="h-20 w-auto"
                draggable={false}
              />
              <span className="hidden md:inline text-2xl font-bold text-purple-700 tracking-tight select-none">
                Öğrenci İntelligence
              </span>
            </>
          )}
        </Link>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden text-gray-700 focus:outline-none"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label={menuOpen ? "Menüyü Kapat" : "Menüyü Aç"}
        >
          {menuOpen ? <X size={26} /> : <Menu size={26} />}
        </button>

        {/* Desktop Menu */}
        <ul className="hidden md:flex space-x-6 items-center font-medium text-sm">
          {/* Dinamik menü öğeleri */}
          {menuItems.map((item) => (
            <li key={item.path}>
              <Link to={item.path} className="hover:text-purple-600 transition">
                {item.label}
              </Link>
            </li>
          ))}

          {/* Giriş yapmamış kullanıcılar için işletme girişi */}
          {!user && (
            <li>
              <Link 
                to="/company/auth" 
                style={{
                  display: 'inline-block',
                  backgroundColor: '#7c3aed',
                  color: '#ffffff',
                  padding: '8px 16px',
                  borderRadius: '8px',
                  fontWeight: '500',
                  textDecoration: 'none',
                  transition: 'all 0.2s',
                  transform: 'scale(1)',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#6d28d9';
                  e.currentTarget.style.transform = 'scale(1.05)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = '#7c3aed';
                  e.currentTarget.style.transform = 'scale(1)';
                }}
              >
                İşletme Girişi
              </Link>
            </li>
          )}
          
          {loading ? (
            <li>
              <div className="animate-pulse bg-gray-200 h-8 w-20 rounded"></div>
            </li>
          ) : user ? (
            <>
              {/* Öğrenci ise puan göster */}
              {userType === 'student' && (
                <li>
                  <Link 
                    to="/points-system" 
                    className="flex items-center bg-purple-100 text-purple-700 px-3 py-1.5 rounded-lg hover:bg-purple-200 transition-colors mr-4"
                  >
                    <Trophy className="w-4 h-4 mr-1.5" />
                    <span className="font-semibold">{userPoints}</span>
                  </Link>
                </li>
              )}

              {/* İşletme ise yeni ilan butonu */}
              {userType === 'company' && (
                <li>
                  <Link
                    to="/company/jobs/create"
                    style={{
                      display: 'block',
                      width: '100%',
                      backgroundColor: '#7c3aed',
                      color: '#ffffff',
                      padding: '8px 16px',
                      borderRadius: '12px',
                      fontWeight: '500',
                      textAlign: 'center',
                      textDecoration: 'none',
                      boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
                      transition: 'all 0.2s',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = '#6d28d9';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = '#7c3aed';
                    }}
                    onClick={closeMenu}
                  >
                    Yeni İlan
                  </Link>
                </li>
              )}

              {/* Kullanıcı dropdown */}
              <li className="relative group">
                <div className="flex items-center space-x-2 hover:text-purple-600 transition cursor-pointer">
                  {userType === 'company' ? (
                    <Building2 size={18} />
                  ) : (
                    <User size={18} />
                  )}
                  <span>{userName}</span>
                  {userType === 'company' && (
                    <span className="text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full">İşletme</span>
                  )}
                </div>
                
                {/* Hover dropdown */}
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                  {dropdownItems.map((item) => (
                    <Link 
                      key={item.path}
                      to={item.path} 
                      className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-purple-50 first:rounded-t-lg"
                    >
                      {item.icon || null}
                      {item.label}
                    </Link>
                  ))}
                  <hr className="my-1" />
                  <button 
                    onClick={handleLogout}
                    className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 rounded-b-lg flex items-center space-x-2"
                  >
                    <LogOut size={16} />
                    <span>Çıkış Yap</span>
                  </button>
                </div>
              </li>
            </>
          ) : (
            <>
              <li>
                <Link 
                  to="/login" 
                  style={{
                    display: 'inline-block',
                    backgroundColor: '#7c3aed',
                    color: '#ffffff',
                    padding: '8px 16px',
                    borderRadius: '8px',
                    fontWeight: '500',
                    textDecoration: 'none',
                    transition: 'all 0.2s',
                    transform: 'scale(1)',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = '#6d28d9';
                    e.currentTarget.style.transform = 'scale(1.05)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = '#7c3aed';
                    e.currentTarget.style.transform = 'scale(1)';
                  }}
                >
                  Öğrenci Girişi
                </Link>
              </li>
              <li>
                <Link 
                  to="/register" 
                  style={{
                    display: 'inline-block',
                    backgroundColor: '#7c3aed',
                    color: '#ffffff',
                    padding: '8px 16px',
                    borderRadius: '8px',
                    fontWeight: '500',
                    textDecoration: 'none',
                    transition: 'all 0.2s',
                    transform: 'scale(1)',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = '#6d28d9';
                    e.currentTarget.style.transform = 'scale(1.05)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = '#7c3aed';
                    e.currentTarget.style.transform = 'scale(1)';
                  }}
                >
                  Kayıt Ol
                </Link>
              </li>
            </>
          )}
        </ul>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="md:hidden px-4 pb-4 pt-2 space-y-2 font-medium text-center border-t border-gray-200 bg-white animate-slideDown">
          <ul className="space-y-2 text-sm">
            {/* Dinamik menü öğeleri */}
            {menuItems.map((item) => (
              <li key={item.path}>
                <Link 
                  to={item.path} 
                  onClick={closeMenu}
                  className="block py-2 hover:text-purple-600 transition"
                >
                  {item.label}
                </Link>
              </li>
            ))}

            {/* Giriş yapmamış kullanıcılar için işletme girişi */}
            {!user && (
              <li>
                <Link
                  to="/company/auth"
                  style={{
                    display: 'block',
                    width: '100%',
                    backgroundColor: '#7c3aed',
                    color: '#ffffff',
                    padding: '8px 16px',
                    borderRadius: '12px',
                    fontWeight: '500',
                    textAlign: 'center',
                    textDecoration: 'none',
                    boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
                    transition: 'all 0.2s',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = '#6d28d9';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = '#7c3aed';
                  }}
                  onClick={closeMenu}
                >
                  İşletme Girişi
                </Link>
              </li>
            )}
            
            {loading ? (
              <li className="py-2">
                <div className="animate-pulse bg-gray-200 h-10 rounded-xl mx-auto w-32"></div>
              </li>
            ) : user ? (
              <>
                {/* Öğrenci ise puan göster */}
                {userType === 'student' && (
                  <li>
                    <Link 
                      to="/points-system" 
                      onClick={closeMenu}
                      className="flex items-center justify-center bg-purple-100 text-purple-700 px-3 py-1.5 rounded-lg hover:bg-purple-200 transition-colors mb-2"
                    >
                      <Trophy className="w-4 h-4 mr-1.5" />
                      <span className="font-semibold">{userPoints}</span>
                    </Link>
                  </li>
                )}

                {/* İşletme ise yeni ilan butonu */}
                {userType === 'company' && (
                  <li>
                    <Link
                      to="/company/jobs/create"
                      onClick={closeMenu}
                      className="flex items-center justify-center bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors mb-2"
                    >
                      <Plus className="w-4 h-4 mr-1.5" />
                      <span>Yeni İlan</span>
                    </Link>
                  </li>
                )}

                <li className="border-t pt-4 mt-4">
                  <div className="text-purple-600 font-semibold mb-3 flex items-center justify-center">
                    {userName}
                    {userType === 'company' && (
                      <span className="text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full ml-2">İşletme</span>
                    )}
                  </div>
                </li>
                
                {/* Mobil dropdown öğeleri */}
                {dropdownItems.map((item) => (
                  <li key={item.path}>
                    <Link 
                      to={item.path} 
                      onClick={closeMenu}
                      className="flex items-center justify-center py-2 hover:text-purple-600 transition"
                    >
                      {item.icon || null}
                      {item.label}
                    </Link>
                  </li>
                ))}
                
                <li>
                  <button
                    onClick={handleLogout}
                    className="w-full bg-red-500 text-white px-4 py-2 rounded-xl shadow-sm hover:bg-red-600 transition"
                  >
                    Çıkış Yap
                  </button>
                </li>
              </>
            ) : (
              <>
                <li>
                  <Link
                    to="/login"
                    style={{
                      display: 'block',
                      width: '100%',
                      backgroundColor: '#7c3aed',
                      color: '#ffffff',
                      padding: '8px 16px',
                      borderRadius: '12px',
                      fontWeight: '500',
                      textAlign: 'center',
                      textDecoration: 'none',
                      boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
                      transition: 'all 0.2s',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = '#6d28d9';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = '#7c3aed';
                    }}
                    onClick={closeMenu}
                  >
                    Öğrenci Girişi
                  </Link>
                </li>
                <li>
                  <Link
                    to="/register"
                    style={{
                      display: 'block',
                      width: '100%',
                      backgroundColor: '#7c3aed',
                      color: '#ffffff',
                      padding: '8px 16px',
                      borderRadius: '12px',
                      fontWeight: '500',
                      textAlign: 'center',
                      textDecoration: 'none',
                      boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)',
                      transition: 'all 0.2s',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = '#6d28d9';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = '#7c3aed';
                    }}
                    onClick={closeMenu}
                  >
                    Kayıt Ol
                  </Link>
                </li>
              </>
            )}
          </ul>
        </div>
      )}
    </nav>
  );
}