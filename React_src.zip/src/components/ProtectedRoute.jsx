import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";

export default function ProtectedRoute({ children }) {
  const { user, loading, userType } = useAuth();
  const location = useLocation();

  // Auth durumu yüklenirken loading göster
  if (loading) {
    return (
      <div className="flex justify-center items-center h-40 text-gray-500 text-lg">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600 mr-3"></div>
        Yükleniyor...
      </div>
    );
  }

  // Email doğrulaması kontrolü
  const isAuthorized = user && user.email_confirmed_at;

  if (!isAuthorized) {
    // Kullanıcının gitmek istediği sayfayı sakla
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // İşletme hesabı öğrenci sayfalarına erişmeye çalışıyorsa
  if (userType === 'company') {
    // İzin verilen sayfalar
    const allowedCompanyPaths = ['/company', '/points-system', '/terms-of-service', '/privacy-policy'];
    const isAllowed = allowedCompanyPaths.some(path => location.pathname.startsWith(path));
    
    if (!isAllowed) {
      return <Navigate to="/company/dashboard" replace />;
    }
  }

  // Öğrenci işletme sayfalarına erişmeye çalışıyorsa
  if (userType === 'student' && location.pathname.startsWith('/company')) {
    return <Navigate to="/dashboard" replace />;
  }

  // Kullanıcı giriş yapmış ve email'i doğrulanmışsa children'ı render et
  return children;
}