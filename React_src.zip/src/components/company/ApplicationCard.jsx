import { useState } from "react";
import { 
  Clock, CheckCircle, XCircle, Mail, Phone, Calendar, 
  FileText, Eye, MessageSquare, GraduationCap, Briefcase,
  MapPin, Building2, User
} from "lucide-react";

// Status Badge Component
const StatusBadge = ({ status }) => {
  const statusConfig = {
    pending: { 
      color: "bg-yellow-100 text-yellow-800 border-yellow-200", 
      icon: Clock, 
      text: "Beklemede" 
    },
    accepted: { 
      color: "bg-green-100 text-green-800 border-green-200", 
      icon: CheckCircle, 
      text: "Kabul Edildi" 
    },
    rejected: { 
      color: "bg-red-100 text-red-800 border-red-200", 
      icon: XCircle, 
      text: "Reddedildi" 
    }
  };

  const config = statusConfig[status] || statusConfig.pending;
  const Icon = config.icon;

  return (
    <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium border ${config.color}`}>
      <Icon className="w-3 h-3" />
      {config.text}
    </span>
  );
};

export default function ApplicationCard({ 
  application, 
  type = "job", // "job" veya "internship"
  onUpdateStatus, 
  onViewDetails,
  updating = false,
  showActions = true,
  compact = false 
}) {
  const [showMessage, setShowMessage] = useState(false);
  const isJob = type === "job";
  
  // Profil bilgileri
  const profile = application.profile || application.user || {};
  const name = profile.full_name || "İsimsiz Kullanıcı";
  const email = profile.email || "E-posta yok";
  const phone = profile.phone;
  const department = profile.department;
  const year = profile.year;
  
  // İlan bilgileri
  const jobInfo = isJob ? application.job : application.internship;
  const title = jobInfo?.title || "İlan başlığı yok";
  const jobDepartment = jobInfo?.department;
  const location = jobInfo?.location;
  const companyName = jobInfo?.company_name || jobInfo?.company;
  
  // Mesaj
  const message = application.cover_letter || application.motivation_letter;
  
  // Tarih
  const applicationDate = application.applied_at || application.created_at;

  if (compact) {
    // Kompakt görünüm
    return (
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 hover:shadow-md transition-all duration-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-blue-600 rounded-full flex items-center justify-center text-white font-semibold text-sm">
              {name.charAt(0).toUpperCase()}
            </div>
            <div>
              <h4 className="font-medium text-gray-900">{name}</h4>
              <p className="text-sm text-gray-600">{title}</p>
            </div>
          </div>
          <StatusBadge status={application.status} />
        </div>
      </div>
    );
  }

  // Normal görünüm
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-200">
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-start gap-4 flex-1">
          <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-blue-600 rounded-full flex items-center justify-center text-white font-semibold text-lg">
            {name.charAt(0).toUpperCase()}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-1">
              <h3 className="font-semibold text-lg text-gray-900">
                {name}
              </h3>
              <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                isJob ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700'
              }`}>
                {isJob ? <Briefcase className="w-3 h-3" /> : <GraduationCap className="w-3 h-3" />}
                {isJob ? 'İş İlanı' : 'Staj İlanı'}
              </div>
            </div>
            
            <p className="text-sm font-medium text-gray-700 mb-2">
              {title}
              {jobDepartment && <span className="text-gray-500 ml-2">• {jobDepartment}</span>}
              {companyName && <span className="text-gray-500 ml-2">• {companyName}</span>}
            </p>

            <div className="space-y-1">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Mail className="w-4 h-4" />
                {email}
              </div>
              {phone && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Phone className="w-4 h-4" />
                  {phone}
                </div>
              )}
              {department && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <GraduationCap className="w-4 h-4" />
                  {department} {year && `- ${year}.Sınıf`}
                </div>
              )}
              {location && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <MapPin className="w-4 h-4" />
                  {location}
                </div>
              )}
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <Calendar className="w-4 h-4" />
                {new Date(applicationDate).toLocaleDateString('tr-TR', {
                  day: 'numeric',
                  month: 'long',
                  year: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </div>
            </div>
          </div>
        </div>
        <StatusBadge status={application.status} />
      </div>

      {/* Ön Yazı / Motivasyon Mektubu */}
      {message && (
        <div className="mb-4">
          <button
            onClick={() => setShowMessage(!showMessage)}
            className="flex items-center gap-2 text-sm font-medium text-purple-600 hover:text-purple-700 transition-colors"
          >
            <MessageSquare className="w-4 h-4" />
            {isJob ? 'Ön Yazı' : 'Motivasyon Mektubu'}
            <span className="text-gray-400">{showMessage ? '▲' : '▼'}</span>
          </button>
          {showMessage && (
            <div className="mt-3 p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-700 whitespace-pre-wrap">
                {message}
              </p>
            </div>
          )}
        </div>
      )}

      {/* Action Buttons */}
      {showActions && (
        <div className="flex gap-3 pt-4 border-t border-gray-100">
          {application.cv_url && (
            <a
              href={application.cv_url}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm font-medium"
            >
              <FileText className="w-4 h-4" />
              CV Görüntüle
            </a>
          )}
          
          {onViewDetails && (
            <button
              onClick={() => onViewDetails(application, type)}
              className="inline-flex items-center gap-2 px-4 py-2 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 transition-colors text-sm font-medium"
            >
              <Eye className="w-4 h-4" />
              Detaylar
            </button>
          )}

          {application.status === "pending" && onUpdateStatus && (
            <div className="flex gap-2 ml-auto">
              <button
                onClick={() => onUpdateStatus(application.id, "accepted", type)}
                disabled={updating === application.id}
                className="inline-flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-medium disabled:opacity-50"
              >
                {updating === application.id ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <CheckCircle className="w-4 h-4" />
                )}
                Kabul Et
              </button>
              <button
                onClick={() => onUpdateStatus(application.id, "rejected", type)}
                disabled={updating === application.id}
                className="inline-flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm font-medium disabled:opacity-50"
              >
                {updating === application.id ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <XCircle className="w-4 h-4" />
                )}
                Reddet
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}