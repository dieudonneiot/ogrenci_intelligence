import { Link } from "react-router-dom";
import { 
  Building2, MapPin, Globe, Users, Calendar, 
  Mail, Phone, Edit, ArrowLeft, Shield,
  Linkedin, Twitter, Facebook, Instagram
} from "lucide-react";

export default function CompanyHeader({ 
  company, 
  showBackButton = false,
  onBack,
  showEditButton = false,
  onEdit,
  coverImage = true
}) {
  if (!company) return null;

  const memberSince = company.created_at 
    ? new Date(company.created_at).getFullYear() 
    : new Date().getFullYear();

  return (
    <div className="relative">
      {/* Kapak Görseli */}
      {coverImage && (
        <div className="relative h-48 md:h-64 bg-gradient-to-r from-purple-600 to-blue-600">
          {company.cover_image_url ? (
            <img 
              src={company.cover_image_url} 
              alt={`${company.name} kapak`}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-r from-purple-600 to-blue-600" />
          )}
          <div className="absolute inset-0 bg-black bg-opacity-30" />
          
          {/* Geri Butonu */}
          {showBackButton && (
            <button
              onClick={onBack}
              className="absolute top-4 left-4 p-2 bg-white/20 backdrop-blur-md text-white rounded-lg hover:bg-white/30 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          )}
        </div>
      )}

      {/* Şirket Bilgileri */}
      <div className={`bg-white ${coverImage ? 'rounded-t-none' : ''} rounded-xl shadow-sm border border-gray-200`}>
        <div className="px-6 py-6">
          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
            {/* Logo ve Temel Bilgiler */}
            <div className="flex items-start gap-4">
              {coverImage && (
                <div className="-mt-20 relative">
                  <div className="w-32 h-32 bg-white rounded-xl overflow-hidden border-4 border-white shadow-lg">
                    {company.logo_url ? (
                      <img 
                        src={company.logo_url} 
                        alt={company.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full bg-gray-100 flex items-center justify-center">
                        <Building2 className="w-12 h-12 text-gray-400" />
                      </div>
                    )}
                  </div>
                  {company.verified && (
                    <div className="absolute -bottom-2 -right-2 bg-blue-500 text-white p-2 rounded-full shadow-lg">
                      <Shield className="w-5 h-5" />
                    </div>
                  )}
                </div>
              )}
              
              <div className={coverImage ? 'mt-2' : ''}>
                <h1 className="text-2xl font-bold text-gray-900 mb-2">{company.name}</h1>
                <p className="text-gray-600 mb-3">{company.sector}</p>
                
                <div className="flex flex-wrap gap-4 text-sm text-gray-600">
                  <span className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    {company.city}
                  </span>
                  {company.employee_count && (
                    <span className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      {company.employee_count} çalışan
                    </span>
                  )}
                  <span className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    {memberSince}'den beri üye
                  </span>
                </div>
              </div>
            </div>

            {/* Eylem Butonları */}
            {showEditButton && (
              <div className={coverImage ? 'mt-8 md:mt-0' : ''}>
                <button
                  onClick={onEdit}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-medium"
                >
                  <Edit className="w-4 h-4" />
                  Profili Düzenle
                </button>
              </div>
            )}
          </div>

          {/* İletişim Bilgileri */}
          <div className="mt-6 pt-6 border-t border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {company.email && (
                <a 
                  href={`mailto:${company.email}`}
                  className="flex items-center gap-2 text-sm text-gray-600 hover:text-purple-600 transition-colors"
                >
                  <Mail className="w-4 h-4" />
                  {company.email}
                </a>
              )}
              {company.phone && (
                <a 
                  href={`tel:${company.phone}`}
                  className="flex items-center gap-2 text-sm text-gray-600 hover:text-purple-600 transition-colors"
                >
                  <Phone className="w-4 h-4" />
                  {company.phone}
                </a>
              )}
              {company.website && (
                <a 
                  href={company.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-sm text-gray-600 hover:text-purple-600 transition-colors"
                >
                  <Globe className="w-4 h-4" />
                  {company.website.replace(/^https?:\/\//, '')}
                </a>
              )}
            </div>

            {/* Sosyal Medya */}
            <div className="flex gap-3 mt-4">
              {company.linkedin && (
                <a 
                  href={company.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  <Linkedin className="w-4 h-4 text-gray-600" />
                </a>
              )}
              {company.twitter && (
                <a 
                  href={company.twitter}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  <Twitter className="w-4 h-4 text-gray-600" />
                </a>
              )}
              {company.facebook && (
                <a 
                  href={company.facebook}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  <Facebook className="w-4 h-4 text-gray-600" />
                </a>
              )}
              {company.instagram && (
                <a 
                  href={company.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  <Instagram className="w-4 h-4 text-gray-600" />
                </a>
              )}
            </div>
          </div>

          {/* Açıklama */}
          {company.description && (
            <div className="mt-6 pt-6 border-t border-gray-200">
              <h3 className="text-sm font-medium text-gray-900 mb-2">Hakkımızda</h3>
              <p className="text-sm text-gray-600 leading-relaxed">
                {company.description}
              </p>
            </div>
          )}

          {/* İstatistikler */}
          <div className="mt-6 pt-6 border-t border-gray-200">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">
                  {company.active_jobs_count || 0}
                </div>
                <div className="text-sm text-gray-600">Aktif İlan</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">
                  {company.total_applications || 0}
                </div>
                <div className="text-sm text-gray-600">Toplam Başvuru</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">
                  {company.hired_count || 0}
                </div>
                <div className="text-sm text-gray-600">İşe Alım</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">
                  {company.profile_completion_score || 0}%
                </div>
                <div className="text-sm text-gray-600">Profil Tamamlanma</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}