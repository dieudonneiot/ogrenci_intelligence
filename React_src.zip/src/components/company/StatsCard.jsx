import { TrendingUp, TrendingDown, Minus } from "lucide-react";

export default function StatsCard({ 
  icon: Icon, 
  label, 
  value, 
  previousValue,
  color = "bg-purple-600", 
  trend, 
  loading = false,
  prefix = "",
  suffix = "",
  description = "",
  size = "default" // "default", "small", "large"
}) {
  // Değişim hesaplama
  const calculateChange = () => {
    if (!previousValue || previousValue === 0) return 0;
    return ((value - previousValue) / previousValue * 100).toFixed(1);
  };

  const change = previousValue !== undefined ? calculateChange() : trend;
  const isPositive = change > 0;
  const isNeutral = change == 0;
  
  // Boyut stilleri
  const sizeStyles = {
    small: {
      container: "p-4",
      iconSize: "w-5 h-5",
      iconContainer: "p-2",
      valueSize: "text-xl",
      labelSize: "text-xs"
    },
    default: {
      container: "p-6",
      iconSize: "w-6 h-6",
      iconContainer: "p-3",
      valueSize: "text-2xl",
      labelSize: "text-sm"
    },
    large: {
      container: "p-8",
      iconSize: "w-8 h-8",
      iconContainer: "p-4",
      valueSize: "text-3xl",
      labelSize: "text-base"
    }
  };

  const styles = sizeStyles[size];

  return (
    <div className={`bg-white rounded-xl shadow-sm border border-gray-200 ${styles.container} hover:shadow-md transition-shadow`}>
      <div className="flex items-center justify-between mb-4">
        <div className={`${styles.iconContainer} rounded-lg ${color} bg-opacity-10`}>
          <Icon className={`${styles.iconSize} ${color.replace('bg-', 'text-')}`} />
        </div>
        {change !== undefined && !isNeutral && (
          <div className={`flex items-center gap-1 text-sm ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
            {isPositive ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
            <span className="font-medium">{Math.abs(change)}%</span>
          </div>
        )}
        {isNeutral && change !== undefined && (
          <div className="flex items-center gap-1 text-sm text-gray-500">
            <Minus className="w-4 h-4" />
            <span className="font-medium">0%</span>
          </div>
        )}
      </div>
      
      <div className={`${styles.valueSize} font-bold text-gray-900`}>
        {loading ? (
          <div className="w-16 h-6 bg-gray-200 rounded animate-pulse"></div>
        ) : (
          <>
            {prefix}
            {typeof value === 'number' ? value.toLocaleString('tr-TR') : value}
            {suffix}
          </>
        )}
      </div>
      
      <div className={`${styles.labelSize} text-gray-600 mt-1`}>
        {label}
      </div>
      
      {description && (
        <div className="text-xs text-gray-500 mt-2">
          {description}
        </div>
      )}
    </div>
  );
}