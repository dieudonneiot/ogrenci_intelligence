import { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import supabase from '../utils/supabaseClient';

const AdminContext = createContext({});

export const useAdmin = () => {
  const context = useContext(AdminContext);
  if (!context) {
    throw new Error('useAdmin must be used within AdminProvider');
  }
  return context;
};

export const AdminProvider = ({ children }) => {
  const { user } = useAuth();
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminData, setAdminData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      checkAdminStatus();
    } else {
      setIsAdmin(false);
      setAdminData(null);
      setLoading(false);
    }
  }, [user]);

  const checkAdminStatus = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('admins')
        .select('*')
        .eq('user_id', user.id)
        .eq('is_active', true)
        .single();

      if (error || !data) {
        setIsAdmin(false);
        setAdminData(null);
      } else {
        setIsAdmin(true);
        setAdminData(data);
      }
    } catch (error) {
      console.error('Admin status check error:', error);
      setIsAdmin(false);
      setAdminData(null);
    } finally {
      setLoading(false);
    }
  };

  const logAdminAction = async (action_type, target_type, target_id, details = {}) => {
    if (!isAdmin || !adminData) return;

    try {
      await supabase.from('admin_logs').insert({
        admin_id: adminData.id,
        action_type,
        target_type,
        target_id,
        details,
        ip_address: window.location.hostname // Production'da gerçek IP alınmalı
      });
    } catch (error) {
      console.error('Admin log error:', error);
    }
  };

  const value = {
    isAdmin,
    adminData,
    loading,
    checkAdminStatus,
    logAdminAction,
    isSuperAdmin: adminData?.role === 'super_admin'
  };

  return (
    <AdminContext.Provider value={value}>
      {children}
    </AdminContext.Provider>
  );
};