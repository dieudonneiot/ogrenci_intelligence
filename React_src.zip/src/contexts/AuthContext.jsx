import { createContext, useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import supabase from "../utils/supabaseClient";
import toast from "react-hot-toast";

// Context oluştur
const AuthContext = createContext({});

// Custom hook - AuthContext'i kullanmak için
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within AuthProvider");
  }
  return context;
};

// AuthProvider komponenti
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [session, setSession] = useState(null);

  // Şirket kullanıcı bilgileri
  const [userType, setUserType] = useState("student");
  const [companyId, setCompanyId] = useState(null);
  const [companyRole, setCompanyRole] = useState(null);

  const navigate = useNavigate();

  // Kullanıcı değiştiğinde şirket bilgilerini çek
  useEffect(() => {
    const fetchCompanyInfo = async () => {
      if (user) {
        const { data, error } = await supabase
          .from("company_users")
          .select("company_id, role")
          .eq("user_id", user.id)
          .maybeSingle();

        if (data) {
          setUserType("company");
          setCompanyId(data.company_id);
          setCompanyRole(data.role);
        } else {
          setUserType("student");
          setCompanyId(null);
          setCompanyRole(null);
        }
      } else {
        setUserType("student");
        setCompanyId(null);
        setCompanyRole(null);
      }
    };
    fetchCompanyInfo();
  }, [user]);

  // Session'ı kontrol et
  useEffect(() => {
    // Mevcut session'ı al
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
    });

    // Auth değişikliklerini dinle
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        setLoading(false);

        switch (event) {
          case "SIGNED_IN":
            toast.success("Başarıyla giriş yaptınız!");
            break;
          case "SIGNED_OUT":
            toast.success("Çıkış yapıldı");
            setUser(null);
            setSession(null);
            setUserType("student");
            setCompanyId(null);
            setCompanyRole(null);
            navigate("/");
            break;
          case "USER_UPDATED":
            toast.success("Profil güncellendi");
            break;
          case "USER_DELETED":
            setUser(null);
            setSession(null);
            setUserType("student");
            setCompanyId(null);
            setCompanyRole(null);
            navigate("/");
            break;
          default:
            break;
        }
      }
    );

    return () => subscription.unsubscribe();
  }, [navigate]);

  // Giriş yap
  const signIn = async (email, password) => {
    try {
      setLoading(true);
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      // Email doğrulaması kontrolü
      if (!data.user?.email_confirmed_at) {
        toast.error("Lütfen email adresinizi doğrulayın!");
        await supabase.auth.signOut();
        return { error: "Email doğrulanmamış" };
      }

      return { data, error: null }; // error: null eklendi
    } catch (error) {
      toast.error(error.message);
      return { error: error.message, data: null }; // data: null eklendi
    } finally {
      setLoading(false);
    }
  };

  // Kayıt ol
  const signUp = async (email, password, fullName) => {
    try {
      setLoading(true);
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
          },
        },
      });

      if (error) throw error;

      toast.success("Kayıt başarılı! Lütfen email adresinizi doğrulayın.");
      return { data };
    } catch (error) {
      toast.error(error.message);
      return { error: error.message };
    } finally {
      setLoading(false);
    }
  };

  // Çıkış yap
  const signOut = async () => {
    try {
      setLoading(true);
      const { error } = await supabase.auth.signOut();
      if (error) throw error;

      // Manuel olarak state'leri temizle
      setUser(null);
      setSession(null);
      setUserType("student");
      setCompanyId(null);
      setCompanyRole(null);
    } catch (error) {
      toast.error("Çıkış yapılırken hata oluştu");
    } finally {
      setLoading(false);
    }
  };

  // Şifre sıfırlama emaili gönder
  const resetPassword = async (email) => {
    try {
      setLoading(true);
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });

      if (error) throw error;

      toast.success("Şifre sıfırlama linki email adresinize gönderildi!");
      return { success: true };
    } catch (error) {
      toast.error(error.message);
      return { error: error.message };
    } finally {
      setLoading(false);
    }
  };

  // Şifreyi güncelle
  const updatePassword = async (newPassword) => {
    try {
      setLoading(true);
      const { error } = await supabase.auth.updateUser({
        password: newPassword,
      });

      if (error) throw error;

      toast.success("Şifreniz başarıyla güncellendi!");
      return { success: true };
    } catch (error) {
      toast.error(error.message);
      return { error: error.message };
    } finally {
      setLoading(false);
    }
  };

  // Profil bilgilerini güncelle
  const updateProfile = async (updates) => {
    try {
      setLoading(true);
      const { error } = await supabase.auth.updateUser({
        data: updates,
      });

      if (error) throw error;

      toast.success("Profil bilgileri güncellendi!");
      return { success: true };
    } catch (error) {
      toast.error(error.message);
      return { error: error.message };
    } finally {
      setLoading(false);
    }
  };

  // Session'ı manuel olarak yenile
  const refreshSession = async () => {
    try {
      const { data: { session }, error } = await supabase.auth.getSession();
      if (error) throw error;

      setSession(session);
      setUser(session?.user ?? null);

      // Session yoksa kullanıcı silinmiş olabilir
      if (!session) {
        navigate("/");
      }

      return { session };
    } catch (error) {
      console.error("Session yenileme hatası:", error);
      setUser(null);
      setSession(null);
      setUserType("student");
      setCompanyId(null);
      setCompanyRole(null);
      navigate("/");
      return { error };
    }
  };

  // Context değerleri
  const value = {
    user,
    session,
    loading,
    signIn,
    signUp,
    signOut,
    resetPassword,
    updatePassword,
    updateProfile,
    refreshSession,
    isAuthenticated: !!user,
    // Yeni eklenenler:
    userType,
    companyId,
    companyRole,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};