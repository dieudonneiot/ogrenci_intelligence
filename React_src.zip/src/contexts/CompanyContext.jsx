import { createContext, useContext, useEffect, useState } from "react";
import { useAuth } from "./AuthContext";
import supabase from "../utils/supabaseClient";

const CompanyContext = createContext({});

export const useCompany = () => {
  const context = useContext(CompanyContext);
  if (!context) {
    throw new Error("useCompany must be used within CompanyProvider");
  }
  return context;
};

export const CompanyProvider = ({ children }) => {
  const { companyId, userType } = useAuth();
  const [company, setCompany] = useState(null);
  const [stats, setStats] = useState({
    totalJobs: 0,
    activeJobs: 0,
    totalApplications: 0,
    pendingApplications: 0,
    totalInternships: 0,
    activeInternships: 0
  });
  const [loading, setLoading] = useState(true);

  // Şirket bilgilerini getir
  useEffect(() => {
    if (!companyId || userType !== "company") {
      setCompany(null);
      setLoading(false);
      return;
    }

    fetchCompanyData();
  }, [companyId, userType]);

  const fetchCompanyData = async () => {
    setLoading(true);
    try {
      // Şirket bilgileri
      const { data: companyData } = await supabase
        .from("companies")
        .select("*")
        .eq("id", companyId)
        .single();

      setCompany(companyData);

      // İstatistikleri getir
      await fetchStats();
    } catch (error) {
      console.error("Company data fetch error:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      // İş ilanları
      const { data: jobs } = await supabase
        .from("jobs")
        .select("id, is_active")
        .eq("company_id", companyId);

      const jobIds = jobs?.map(j => j.id) || [];
      const activeJobsCount = jobs?.filter(j => j.is_active).length || 0;

      // İş başvuruları
      let totalApplications = 0;
      let pendingApplications = 0;
      
      if (jobIds.length > 0) {
        const { count: totalApps } = await supabase
          .from("job_applications")
          .select("id", { count: "exact", head: true })
          .in("job_id", jobIds);

        const { count: pendingApps } = await supabase
          .from("job_applications")
          .select("id", { count: "exact", head: true })
          .in("job_id", jobIds)
          .eq("status", "pending");

        totalApplications = totalApps || 0;
        pendingApplications = pendingApps || 0;
      }

      // Staj ilanları
      const { data: internships } = await supabase
        .from("internships")
        .select("id, is_active")
        .eq("company_id", companyId);

      const activeInternshipsCount = internships?.filter(i => i.is_active).length || 0;

      setStats({
        totalJobs: jobs?.length || 0,
        activeJobs: activeJobsCount,
        totalApplications,
        pendingApplications,
        totalInternships: internships?.length || 0,
        activeInternships: activeInternshipsCount
      });
    } catch (error) {
      console.error("Stats fetch error:", error);
    }
  };

  // İlan oluşturma
  const createJob = async (jobData) => {
    const { data, error } = await supabase
      .from("jobs")
      .insert({
        ...jobData,
        company_id: companyId,
        created_by: supabase.auth.user()?.id,
        is_active: true
      })
      .select()
      .single();

    if (!error) {
      await fetchStats(); // İstatistikleri güncelle
    }

    return { data, error };
  };

  // İlan güncelleme
  const updateJob = async (jobId, updates) => {
    const { data, error } = await supabase
      .from("jobs")
      .update(updates)
      .eq("id", jobId)
      .eq("company_id", companyId)
      .select()
      .single();

    if (!error) {
      await fetchStats();
    }

    return { data, error };
  };

  // İlan silme (soft delete)
  const deleteJob = async (jobId) => {
    const { error } = await supabase
      .from("jobs")
      .update({ is_active: false })
      .eq("id", jobId)
      .eq("company_id", companyId);

    if (!error) {
      await fetchStats();
    }

    return { error };
  };

  // Başvuru durumu güncelleme
  const updateApplicationStatus = async (applicationId, status) => {
    const { data, error } = await supabase
      .from("job_applications")
      .update({ status })
      .eq("id", applicationId)
      .select()
      .single();

    if (!error) {
      await fetchStats();
    }

    return { data, error };
  };

  const value = {
    company,
    stats,
    loading,
    fetchCompanyData,
    fetchStats,
    createJob,
    updateJob,
    deleteJob,
    updateApplicationStatus
  };

  return (
    <CompanyContext.Provider value={value}>
      {children}
    </CompanyContext.Provider>
  );
};