// src/pages/About.jsx

import { 
  Target, 
  Users, 
  Award, 
  Heart,
  Zap,
  TrendingUp
} from "lucide-react";

export default function About() {
  const values = [
    {
      icon: Target,
      title: "Misyonumuz",
      description: "Öğrencilerin kariyerlerini şekillendirmelerine yardımcı olmak, onları sektörle buluşturmak ve potansiyellerini keşfetmelerini sağlamak."
    },
    {
      icon: Heart,
      title: "Değerlerimiz",
      description: "Eşitlik, fırsat yaratma, sürekli öğrenme ve gelişim. Her öğrencinin başarılı olabileceğine inanıyoruz."
    },
    {
      icon: Zap,
      title: "Vizyonumuz",
      description: "Türkiye'nin en büyük öğrenci kariyer platformu olmak ve her yıl binlerce öğrencinin hayallerine ulaşmasına katkı sağlamak."
    }
  ];

  const stats = [
    { number: "10,000+", label: "Aktif Öğrenci" },
    { number: "500+", label: "Partner Şirket" },
    { number: "1,000+", label: "Staj İmkanı" },
    { number: "50+", label: "Online Kurs" }
  ];

  return (
    <div className="max-w-6xl mx-auto py-12">
      {/* Hero Section */}
      <div className="text-center mb-16">
        <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
          Hakkımızda
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Öğrenciler ve işverenler arasında köprü kurarak, gençlerin kariyer yolculuğunda 
          yanlarında olan bir platformuz.
        </p>
      </div>

      {/* Story Section */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 mb-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Hikayemiz</h2>
            <div className="space-y-4 text-gray-600">
              <p>
                2023 yılında, üniversite öğrencilerinin yaşadığı staj bulma zorluğunu 
                ve mezuniyet sonrası iş arama sürecindeki belirsizlikleri gözlemleyerek 
                yola çıktık.
              </p>
              <p>
                Amacımız, öğrencilerin sadece iş ve staj bulmasını sağlamak değil, aynı 
                zamanda kendilerini geliştirmelerine olanak tanıyacak bir ekosistem 
                yaratmaktı. Puan sistemi, online kurslar ve mentörlük programları ile 
                öğrencilerin sürekli gelişimini teşvik ediyoruz.
              </p>
              <p>
                Bugün, binlerce öğrenci platformumuz üzerinden hayallerindeki kariyere 
                adım atıyor. Her başarı hikayesi, bizim için yeni bir motivasyon kaynağı.
              </p>
            </div>
          </div>
          <div className="bg-gradient-to-br from-purple-100 to-indigo-100 rounded-xl p-8">
            <div className="grid grid-cols-2 gap-6">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <p className="text-3xl font-bold text-purple-600">{stat.number}</p>
                  <p className="text-gray-700">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Values Section */}
      <div className="mb-12">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
          Değerlerimiz
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {values.map((value, index) => {
            const Icon = value.icon;
            return (
              <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon className="w-8 h-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold mb-3">{value.title}</h3>
                <p className="text-gray-600">{value.description}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Team Section */}
      <div className="bg-gray-50 rounded-xl p-8 mb-12">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-8">
          Ekibimiz
        </h2>
        <p className="text-center text-gray-600 max-w-3xl mx-auto mb-12">
          Öğrencilerin kariyerlerine değer katmak için tutkuyla çalışan, 
          deneyimli ve genç bir ekibiz.
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {[1, 2, 3, 4].map((member) => (
            <div key={member} className="text-center">
              <div className="w-24 h-24 bg-purple-200 rounded-full mx-auto mb-4"></div>
              <h4 className="font-semibold">İsim Soyisim</h4>
              <p className="text-sm text-gray-600">Pozisyon</p>
            </div>
          ))}
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-8">
          Neden Biz?
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="flex items-start space-x-4">
            <Users className="w-8 h-8 text-purple-600 flex-shrink-0" />
            <div>
              <h3 className="text-lg font-semibold mb-2">Geniş Network</h3>
              <p className="text-gray-600">
                500'den fazla partner şirket ve binlerce aktif öğrenci ile 
                Türkiye'nin en geniş öğrenci kariyer ağı.
              </p>
            </div>
          </div>
          <div className="flex items-start space-x-4">
            <Award className="w-8 h-8 text-purple-600 flex-shrink-0" />
            <div>
              <h3 className="text-lg font-semibold mb-2">Ödül Sistemi</h3>
              <p className="text-gray-600">
                Aktiviteleriniz karşılığında puan kazanın, bu puanları 
                gerçek ödüllerle değiştirin.
              </p>
            </div>
          </div>
          <div className="flex items-start space-x-4">
            <TrendingUp className="w-8 h-8 text-purple-600 flex-shrink-0" />
            <div>
              <h3 className="text-lg font-semibold mb-2">Kariyer Gelişimi</h3>
              <p className="text-gray-600">
                Online kurslar, mentörlük programları ve kariyer etkinlikleri 
                ile sürekli gelişiminizi destekliyoruz.
              </p>
            </div>
          </div>
          <div className="flex items-start space-x-4">
            <Heart className="w-8 h-8 text-purple-600 flex-shrink-0" />
            <div>
              <h3 className="text-lg font-semibold mb-2">Öğrenci Dostu</h3>
              <p className="text-gray-600">
                Tamamen ücretsiz platform, öğrenci ihtiyaçlarına göre 
                tasarlanmış arayüz ve özellikler.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}