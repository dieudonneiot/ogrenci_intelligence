import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { supabase } from "../utils/supabaseClient";
import { 
  Briefcase,
  BookOpen,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Calendar,
  Building,
  MapPin,
  Filter,
  Search,
  ChevronRight
} from "lucide-react";

export default function Applications() {
  const { user } = useAuth();
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");

  useEffect(() => {
    if (user) {
      fetchApplications();
    }
  }, [user, activeTab]);

  const fetchApplications = async () => {
    setLoading(true);
    
    try {
      let allApplications = [];

      // İş başvuruları
      if (activeTab === "all" || activeTab === "jobs") {
        const { data: jobApps } = await supabase
          .from("job_applications")
          .select(`
            *,
            job:jobs(*)
          `)
          .eq("user_id", user.id)
          .order("applied_at", { ascending: false });

        if (jobApps) {
          allApplications = [...allApplications, ...jobApps.map(app => ({
            ...app,
            type: "job",
            title: app.job?.title,
            company: app.job?.company,
            location: app.job?.location
          }))];
        }
      }

      // Staj başvuruları
      if (activeTab === "all" || activeTab === "internships") {
        const { data: internshipApps } = await supabase
          .from("internship_applications")
          .select(`
            *,
            internship:internships(*)
          `)
          .eq("user_id", user.id)
          .order("applied_at", { ascending: false });

        if (internshipApps) {
          allApplications = [...allApplications, ...internshipApps.map(app => ({
            ...app,
            type: "internship",
            title: app.internship?.title,
            company: app.internship?.company,
            location: app.internship?.location
          }))];
        }
      }

      // Kurs kayıtları
      if (activeTab === "all" || activeTab === "courses") {
        const { data: courseEnrollments } = await supabase
          .from("course_enrollments")
          .select(`
            *,
            course:courses(*)
          `)
          .eq("user_id", user.id)
          .order("enrolled_at", { ascending: false });

        if (courseEnrollments) {
          allApplications = [...allApplications, ...courseEnrollments.map(enrollment => ({
            ...enrollment,
            type: "course",
            title: enrollment.course?.title,
            instructor: enrollment.course?.instructor,
            status: enrollment.completed ? "completed" : "active",
            applied_at: enrollment.enrolled_at
          }))];
        }
      }

      // Tarihe göre sırala
      allApplications.sort((a, b) => new Date(b.applied_at) - new Date(a.applied_at));
      setApplications(allApplications);
    } catch (error) {
      console.error("Başvurular alınamadı:", error);
    }
    
    setLoading(false);
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      pending: { color: "bg-yellow-100 text-yellow-800", icon: Clock, text: "Beklemede" },
      accepted: { color: "bg-green-100 text-green-800", icon: CheckCircle, text: "Kabul Edildi" },
      rejected: { color: "bg-red-100 text-red-800", icon: XCircle, text: "Reddedildi" },
      active: { color: "bg-blue-100 text-blue-800", icon: AlertCircle, text: "Devam Ediyor" },
      completed: { color: "bg-purple-100 text-purple-800", icon: CheckCircle, text: "Tamamlandı" }
    };

    const config = statusConfig[status] || statusConfig.pending;
    const Icon = config.icon;

    return (
      <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${config.color}`}>
        <Icon className="w-4 h-4 mr-1" />
        {config.text}
      </span>
    );
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case "job":
        return <Briefcase className="w-5 h-5 text-blue-600" />;
      case "internship":
        return <Building className="w-5 h-5 text-green-600" />;
      case "course":
        return <BookOpen className="w-5 h-5 text-purple-600" />;
      default:
        return <Briefcase className="w-5 h-5 text-gray-600" />;
    }
  };

  const filteredApplications = applications.filter(app => {
    const matchesSearch = app.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         app.company?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || app.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const tabs = [
    { id: "all", label: "Tümü", count: applications.length },
    { id: "jobs", label: "İş İlanları", count: applications.filter(a => a.type === "job").length },
    { id: "internships", label: "Stajlar", count: applications.filter(a => a.type === "internship").length },
    { id: "courses", label: "Kurslar", count: applications.filter(a => a.type === "course").length }
  ];

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto py-8">
      {/* Başlık */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Başvurularım</h1>
        <p className="text-gray-600">Tüm başvuru ve kayıtlarınızı buradan takip edebilirsiniz.</p>
      </div>

      {/* İstatistikler */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Toplam Başvuru</p>
              <p className="text-2xl font-bold text-gray-900">{applications.length}</p>
            </div>
            <Briefcase className="w-8 h-8 text-gray-400" />
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Beklemede</p>
              <p className="text-2xl font-bold text-yellow-600">
                {applications.filter(a => a.status === "pending").length}
              </p>
            </div>
            <Clock className="w-8 h-8 text-yellow-400" />
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Kabul Edildi</p>
              <p className="text-2xl font-bold text-green-600">
                {applications.filter(a => a.status === "accepted").length}
              </p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-400" />
          </div>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Aktif</p>
              <p className="text-2xl font-bold text-blue-600">
                {applications.filter(a => a.status === "active").length}
              </p>
            </div>
            <AlertCircle className="w-8 h-8 text-blue-400" />
          </div>
        </div>
      </div>

      {/* Sekmeler ve Filtreler */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-6">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6" aria-label="Tabs">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? "border-purple-600 text-purple-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                {tab.label}
                {tab.count > 0 && (
                  <span className="ml-2 bg-gray-100 text-gray-600 py-0.5 px-2 rounded-full text-xs">
                    {tab.count}
                  </span>
                )}
              </button>
            ))}
          </nav>
        </div>

        {/* Arama ve Filtre */}
        <div className="p-6 flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Başvuru ara..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
          </div>
          <div className="relative">
            <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="pl-10 pr-8 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent appearance-none bg-white"
            >
              <option value="all">Tüm Durumlar</option>
              <option value="pending">Beklemede</option>
              <option value="accepted">Kabul Edildi</option>
              <option value="rejected">Reddedildi</option>
              <option value="active">Aktif</option>
              <option value="completed">Tamamlandı</option>
            </select>
          </div>
        </div>
      </div>

      {/* Başvuru Listesi */}
      <div className="space-y-4">
        {filteredApplications.length === 0 ? (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
            <Briefcase className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Henüz başvurunuz bulunmuyor.</p>
            <div className="mt-4 space-x-4">
              <Link to="/jobs" className="text-purple-600 hover:text-purple-700 font-medium">
                İş İlanlarına Göz At
              </Link>
              <span className="text-gray-400">•</span>
              <Link to="/internships" className="text-purple-600 hover:text-purple-700 font-medium">
                Stajları Keşfet
              </Link>
              <span className="text-gray-400">•</span>
              <Link to="/courses" className="text-purple-600 hover:text-purple-700 font-medium">
                Kurslara Katıl
              </Link>
            </div>
          </div>
        ) : (
          filteredApplications.map((application) => (
            <div key={application.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                    {getTypeIcon(application.type)}
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">
                      {application.title}
                    </h3>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      {application.company && (
                        <div className="flex items-center">
                          <Building className="w-4 h-4 mr-1" />
                          {application.company}
                        </div>
                      )}
                      {application.location && (
                        <div className="flex items-center">
                          <MapPin className="w-4 h-4 mr-1" />
                          {application.location}
                        </div>
                      )}
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 mr-1" />
                        {new Date(application.applied_at).toLocaleDateString("tr-TR")}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  {getStatusBadge(application.status)}
                  <Link
                    to={`/${application.type}s/${application.type === "course" ? application.course_id : application.type === "job" ? application.job_id : application.internship_id}`}
                    className="text-purple-600 hover:text-purple-700"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </Link>
                </div>
              </div>
              
              {application.progress !== undefined && (
                <div className="mt-4">
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-gray-600">İlerleme</span>
                    <span className="font-medium">{application.progress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-purple-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${application.progress}%` }}
                    ></div>
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}