import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import supabase from '../../utils/supabaseClient';
import { toast } from 'react-hot-toast';
import { 
  Eye, EyeOff, Building2, Mail, Lock, ArrowRight, 
  Briefcase, Users, TrendingUp, Award, Phone, 
  MapPin, FileText, Loader2
} from 'lucide-react';

const SECTORS = [
  "Yazılım", "Finans", "Eğitim", "Sağlık", "Üretim", "Danışmanlık", "E-ticaret", "Turizm", "Diğer"
];

const CITIES = [
  "İstanbul", "Ankara", "İzmir", "Bursa", "Antalya", "Adana", "Konya", "Gaziantep", "Kayseri", "Diğer"
];

export default function CompanyAuth() {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { user, userType, signIn } = useAuth();

  useEffect(() => {
    if (user) {
      if (userType === 'company') {
        navigate('/company/dashboard', { replace: true });
      } else {
        // Öğrenci hesabı ile giriş yapmış
        toast.error('Lütfen önce çıkış yapın ve işletme hesabınız ile giriş yapın');
        navigate('/dashboard', { replace: true });
      }
    }
  }, [user, userType, navigate]);

  const [loginForm, setLoginForm] = useState({
    email: '',
    password: ''
  });

  const [registerForm, setRegisterForm] = useState({
    email: '',
    password: '',
    company_name: '',
    sector: '',
    tax_number: '',
    phone: '',
    city: '',
    address: ''
  });

  const handleLoginChange = (e) => {
    setLoginForm({
      ...loginForm,
      [e.target.name]: e.target.value
    });
  };

  const handleRegisterChange = (e) => {
    setRegisterForm({
      ...registerForm,
      [e.target.name]: e.target.value
    });
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    
    if (!loginForm.email || !loginForm.password) {
      toast.error('Lütfen tüm alanları doldurun');
      return;
    }

    setLoading(true);
    try {
      // Normal giriş yap
      const { error } = await signIn(loginForm.email, loginForm.password);
      
      if (error) {
        console.error('Giriş hatası:', error);
        toast.error('Giriş başarısız: ' + error);
        setLoading(false);
        return;
      }

      // Başarılı giriş sonrası kullanıcının şirket yetkisi var mı kontrol et
      const { data: { user } } = await supabase.auth.getUser();
      
      if (user) {
        const { data: companyUser } = await supabase
          .from('company_users')
          .select('company_id, role')
          .eq('user_id', user.id)
          .maybeSingle();

        if (!companyUser) {
          await supabase.auth.signOut();
          toast.error('Bu hesap bir işletme hesabı değil');
          setLoading(false);
          return;
        }

        toast.success('Giriş başarılı!');
        navigate('/company/dashboard');
      }
    } catch (error) {
      console.error('Giriş hatası:', error);
      toast.error('Bir hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    
    const { email, password, company_name, sector, tax_number, phone, city, address } = registerForm;
    
    if (!email || !password || !company_name || !sector || !tax_number || !phone || !city) {
      toast.error('Lütfen tüm zorunlu alanları doldurun');
      return;
    }

    if (password.length < 6) {
      toast.error('Şifre en az 6 karakter olmalıdır');
      return;
    }

    setLoading(true);
    try {
      // 1. Vergi numarası kontrolü
      const { data: existingCompany } = await supabase
        .from('companies')
        .select('id')
        .eq('tax_number', tax_number)
        .maybeSingle();

      if (existingCompany) {
        toast.error('Bu vergi numarası ile kayıtlı bir şirket zaten var');
        setLoading(false);
        return;
      }

      // 2. Kullanıcı kaydı
      const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/company/dashboard`,
          data: {
            full_name: company_name,
            user_type: 'company'
          }
        }
      });

      if (signUpError) {
        console.error('Kayıt hatası:', signUpError);
        toast.error('Kayıt başarısız: ' + signUpError.message);
        setLoading(false);
        return;
      }

      if (!signUpData.user) {
        toast.error('Kullanıcı oluşturulamadı');
        setLoading(false);
        return;
      }

      // 3. Şirket kaydı
      const { data: company, error: companyError } = await supabase
        .from('companies')
        .insert({
          name: company_name,
          sector,
          tax_number,
          phone,
          city,
          address: address || null,
          verified: false,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .select();

      // select() array döndürür, single() kullanmayalım
      if (companyError) {
        console.error('Şirket kayıt hatası:', companyError);
        
        // Detaylı hata kontrolü
        if (companyError.code === '42501') {
          toast.error('Güvenlik politikası hatası. RLS politikalarını kontrol edin.');
        } else if (companyError.code === '23505') {
          toast.error('Bu vergi numarası zaten kayıtlı.');
        } else {
          toast.error('Şirket kaydı hatası: ' + companyError.message);
        }
        
        // Kullanıcıyı sil
        try {
          await supabase.auth.admin.deleteUser(signUpData.user.id);
        } catch (deleteError) {
          console.error('Kullanıcı silme hatası:', deleteError);
        }
        
        setLoading(false);
        return;
      }

      // Array'den ilk elemanı al
      const createdCompany = company?.[0];
      
      if (!createdCompany) {
        console.error('Şirket oluşturuldu ama veri döndürülmedi');
        toast.error('Şirket kaydı tamamlanamadı');
        setLoading(false);
        return;
      }

      // 4. company_users tablosuna kayıt
      const { error: userLinkError } = await supabase
        .from('company_users')
        .insert({
          company_id: createdCompany.id,
          user_id: signUpData.user.id,
          role: 'owner',
          permissions: ['all'],
          created_at: new Date().toISOString()
        });

      if (userLinkError) {
        console.error('Kullanıcı bağlantı hatası:', userLinkError);
        toast.error('Kullanıcı-şirket bağlantısı oluşturulamadı');
        setLoading(false);
        return;
      }

      toast.success('Kayıt başarılı! Lütfen email adresinizi doğrulayın.');
      setIsLogin(true);
    } catch (error) {
      console.error('Beklenmeyen hata:', error);
      toast.error('Bir hata oluştu: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const features = [
    { icon: Briefcase, title: 'İlan Yönetimi', desc: 'İş ve staj ilanlarınızı kolayca yönetin' },
    { icon: Users, title: 'Başvuru Takibi', desc: 'Tüm başvuruları tek panelden inceleyin' },
    { icon: TrendingUp, title: 'Detaylı Analizler', desc: 'İlan performanslarını takip edin' },
    { icon: Award, title: 'Yetenekleri Keşfedin', desc: 'En uygun adayları bulun' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-blue-900 flex">
      {/* Sol Panel */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 to-purple-600/20 backdrop-blur-sm" />
        <div className="relative z-10 flex flex-col justify-center p-12 text-white">
          <div className="mb-12">
            <Building2 className="w-16 h-16 mb-6 text-blue-400" />
            <h1 className="text-4xl font-bold mb-4">
              İşletme Yönetim Paneli
            </h1>
            <p className="text-xl text-gray-300">
              Geleceğin yetenekleriyle buluşun
            </p>
          </div>

          <div className="space-y-6">
            {features.map((feature, idx) => (
              <div key={idx} className="flex items-start space-x-4 bg-white/10 backdrop-blur-md rounded-xl p-4 border border-white/20">
                <div className="bg-gradient-to-br from-blue-500 to-purple-500 p-3 rounded-lg">
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">{feature.title}</h3>
                  <p className="text-gray-300 text-sm">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Sağ Panel - Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          <div className="bg-white/10 backdrop-blur-md rounded-2xl shadow-2xl p-8 border border-white/20">
            <div className="text-center mb-8">
              <div className="bg-gradient-to-br from-blue-500 to-purple-600 w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Building2 className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-white mb-2">
                {isLogin ? 'İşletme Girişi' : 'İşletme Kaydı'}
              </h2>
              <p className="text-gray-300">
                {isLogin ? 'Hesabınıza giriş yapın' : 'Yeni işletme hesabı oluşturun'}
              </p>
            </div>

            <form onSubmit={isLogin ? handleLogin : handleRegister}>
              {isLogin ? (
                // Giriş Formu
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-300 block mb-2">
                      E-posta Adresi
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="email"
                        name="email"
                        value={loginForm.email}
                        onChange={handleLoginChange}
                        className="w-full bg-white/10 border border-white/20 rounded-lg py-3 px-10 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent backdrop-blur-md"
                        placeholder="ornek@sirket.com"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-300 block mb-2">
                      Şifre
                    </label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type={showPassword ? 'text' : 'password'}
                        name="password"
                        value={loginForm.password}
                        onChange={handleLoginChange}
                        className="w-full bg-white/10 border border-white/20 rounded-lg py-3 px-10 pr-12 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent backdrop-blur-md"
                        placeholder="••••••••"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
                      >
                        {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                // Kayıt Formu
                <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
                  <div>
                    <label className="text-sm font-medium text-gray-300 block mb-2">
                      Şirket Adı *
                    </label>
                    <input
                      type="text"
                      name="company_name"
                      value={registerForm.company_name}
                      onChange={handleRegisterChange}
                      className="w-full bg-white/10 border border-white/20 rounded-lg py-3 px-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Şirket adınız"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-gray-300 block mb-2">
                        Sektör *
                      </label>
                      <select
                        name="sector"
                        value={registerForm.sector}
                        onChange={handleRegisterChange}
                        className="w-full bg-white/10 border border-white/20 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      >
                        <option value="" className="bg-gray-800">Seçiniz</option>
                        {SECTORS.map(sector => (
                          <option key={sector} value={sector} className="bg-gray-800">{sector}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-sm font-medium text-gray-300 block mb-2">
                        Şehir *
                      </label>
                      <select
                        name="city"
                        value={registerForm.city}
                        onChange={handleRegisterChange}
                        className="w-full bg-white/10 border border-white/20 rounded-lg py-3 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      >
                        <option value="" className="bg-gray-800">Seçiniz</option>
                        {CITIES.map(city => (
                          <option key={city} value={city} className="bg-gray-800">{city}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-300 block mb-2">
                      Vergi Numarası *
                    </label>
                    <input
                      type="text"
                      name="tax_number"
                      value={registerForm.tax_number}
                      onChange={handleRegisterChange}
                      className="w-full bg-white/10 border border-white/20 rounded-lg py-3 px-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Vergi numaranız"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-300 block mb-2">
                      E-posta Adresi *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={registerForm.email}
                      onChange={handleRegisterChange}
                      className="w-full bg-white/10 border border-white/20 rounded-lg py-3 px-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="ornek@sirket.com"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-300 block mb-2">
                      Şifre *
                    </label>
                    <input
                      type={showPassword ? 'text' : 'password'}
                      name="password"
                      value={registerForm.password}
                      onChange={handleRegisterChange}
                      className="w-full bg-white/10 border border-white/20 rounded-lg py-3 px-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="En az 6 karakter"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-300 block mb-2">
                      Telefon *
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={registerForm.phone}
                      onChange={handleRegisterChange}
                      className="w-full bg-white/10 border border-white/20 rounded-lg py-3 px-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="0532 XXX XX XX"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-300 block mb-2">
                      Adres
                    </label>
                    <textarea
                      name="address"
                      value={registerForm.address}
                      onChange={handleRegisterChange}
                      rows="2"
                      className="w-full bg-white/10 border border-white/20 rounded-lg py-3 px-4 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                      placeholder="Şirket adresi (opsiyonel)"
                    />
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold py-3 rounded-lg hover:shadow-lg transform hover:scale-[1.02] transition-all duration-200 flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed mt-6"
              >
                {loading ? (
                  <Loader2 className="w-6 h-6 animate-spin" />
                ) : (
                  <>
                    <span>{isLogin ? 'Giriş Yap' : 'Kayıt Ol'}</span>
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </button>
            </form>

            <div className="mt-6 text-center">
              <p className="text-gray-300">
                {isLogin ? "Hesabınız yok mu?" : "Zaten hesabınız var mı?"}
                <button
                  type="button"
                  onClick={() => setIsLogin(!isLogin)}
                  className="ml-2 text-blue-400 hover:text-blue-300 font-semibold transition-colors"
                >
                  {isLogin ? 'Kayıt Ol' : 'Giriş Yap'}
                </button>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}