import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { Mail, RefreshCw, CheckCircle, Clock, ArrowRight } from "lucide-react";
import { supabase } from "../../utils/supabaseClient";
import toast from "react-hot-toast";

export default function EmailVerification() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [resending, setResending] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [checking, setChecking] = useState(false);

  // Email doğrulandı mı kontrol et
  const checkEmailVerification = async () => {
    setChecking(true);
    const { data: { user: updatedUser } } = await supabase.auth.getUser();
    
    if (updatedUser?.email_confirmed_at) {
      toast.success("Email adresiniz doğrulandı!");
      navigate("/profile");
    } else {
      toast.error("Email henüz doğrulanmamış");
    }
    setChecking(false);
  };

  // Geri sayım için useEffect
  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  // Email'i tekrar gönder
  const resendVerificationEmail = async () => {
    setResending(true);
    
    try {
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email: user?.email,
      });

      if (error) throw error;
      
      toast.success("Doğrulama emaili tekrar gönderildi!");
      setCountdown(60); // 60 saniye bekleme süresi
    } catch (error) {
      toast.error("Email gönderilirken hata oluştu");
    }
    
    setResending(false);
  };

  // Kullanıcı yoksa login'e yönlendir
  if (!user) {
    navigate("/login");
    return null;
  }

  return (
    <div className="flex justify-center items-center min-h-[80vh] px-4 py-8">
      <div className="w-full max-w-lg">
        <div className="bg-white p-8 rounded-2xl shadow-lg border border-gray-100">
          {/* Başlık ve İkon */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-amber-100 rounded-full mb-4">
              <Mail className="w-10 h-10 text-amber-600" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">
              Email Doğrulama Bekleniyor
            </h2>
            <p className="text-gray-600">
              Hesabınızı aktifleştirmek için email adresinizi doğrulamanız gerekiyor
            </p>
          </div>

          {/* Email Bilgisi */}
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 mb-6">
            <p className="text-sm text-purple-800 text-center">
              Doğrulama linki <span className="font-semibold">{user.email}</span> adresine gönderildi
            </p>
          </div>

          {/* Adımlar */}
          <div className="space-y-4 mb-8">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                <span className="text-sm font-semibold text-purple-600">1</span>
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Email kutunuzu kontrol edin</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Doğrulama emaili birkaç dakika içinde ulaşacaktır
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                <span className="text-sm font-semibold text-purple-600">2</span>
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Doğrulama linkine tıklayın</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Email içindeki linke tıklayarak hesabınızı doğrulayın
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                <span className="text-sm font-semibold text-purple-600">3</span>
              </div>
              <div>
                <h3 className="font-medium text-gray-900">Platforma giriş yapın</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Doğrulama sonrası tüm özelliklere erişebilirsiniz
                </p>
              </div>
            </div>
          </div>

          {/* Aksiyonlar */}
          <div className="space-y-3">
            {/* Email'i Kontrol Et Butonu */}
            <button
              onClick={checkEmailVerification}
              disabled={checking}
              className="w-full bg-purple-600 text-white py-3 rounded-lg font-medium hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center"
            >
              {checking ? (
                <>
                  <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                  Kontrol ediliyor...
                </>
              ) : (
                <>
                  <CheckCircle className="w-5 h-5 mr-2" />
                  Email'imi Doğruladım
                </>
              )}
            </button>

            {/* Tekrar Gönder Butonu */}
            <button
              onClick={resendVerificationEmail}
              disabled={resending || countdown > 0}
              className="w-full bg-gray-100 text-gray-700 py-3 rounded-lg font-medium hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center"
            >
              {resending ? (
                <>
                  <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                  Gönderiliyor...
                </>
              ) : countdown > 0 ? (
                <>
                  <Clock className="w-5 h-5 mr-2" />
                  Tekrar gönder ({countdown}s)
                </>
              ) : (
                <>
                  <RefreshCw className="w-5 h-5 mr-2" />
                  Email'i Tekrar Gönder
                </>
              )}
            </button>
          </div>

          {/* Uyarı */}
          <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <p className="text-sm text-amber-800">
              <strong>Email gelmedi mi?</strong> Spam/gereksiz klasörünü kontrol edin veya farklı bir email adresi ile kayıt olun.
            </p>
          </div>

          {/* Çıkış Yap Linki */}
          <div className="mt-6 text-center">
            <Link
              to="/login"
              className="text-gray-600 hover:text-gray-700 text-sm"
            >
              Farklı bir hesapla giriş yap
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}