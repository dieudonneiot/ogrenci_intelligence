import { useState, useEffect, useRef } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { supabase } from "../utils/supabaseClient";
import { addPoints, POINT_VALUES } from "../services/pointsService";
import toast from "react-hot-toast";
import {
  Clock,
  Users,
  Star,
  Award,
  CheckCircle,
  PlayCircle,
  BookOpen,
  Calendar,
  ArrowLeft,
  Heart,
  Share2,
  BarChart,
  AlertCircle
} from "lucide-react";

export default function CourseDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();

  const [course, setCourse] = useState(null);
  const [loading, setLoading] = useState(true);
  const [enrolling, setEnrolling] = useState(false);
  const [isEnrolled, setIsEnrolled] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [isFavorited, setIsFavorited] = useState(false);
  const [progress, setProgress] = useState(0);
  const [videoWatched, setVideoWatched] = useState(false);
  const [showVideo, setShowVideo] = useState(false);
  const [completing, setCompleting] = useState(false);
  const [enrollmentCount, setEnrollmentCount] = useState(0);
  const [enrollment, setEnrollment] = useState(null);
  const videoRef = useRef(null);

  useEffect(() => {
    fetchCourseDetails();
    // eslint-disable-next-line
  }, [id, user]);

  const fetchCourseDetails = async () => {
    setLoading(true);

    try {
      // Kurs detaylarını getir
      const { data: courseData, error: courseError } = await supabase
        .from("courses")
        .select("*")
        .eq("id", id)
        .single();

      if (courseError) {
        toast.error("Kurs bulunamadı");
        navigate("/courses");
        return;
      }

      setCourse(courseData);

      // Kayıtlı öğrenci sayısı
      const { count: enrolledCount } = await supabase
        .from("course_enrollments")
        .select("*", { count: "exact", head: true })
        .eq("course_id", id);

      setEnrollmentCount(enrolledCount || 0);

      // Kullanıcı kayıtlı mı kontrol et
      if (user) {
        const { data: enrollmentData } = await supabase
          .from("course_enrollments")
          .select("*")
          .eq("course_id", id)
          .eq("user_id", user.id)
          .single();

        if (enrollmentData) {
          setIsEnrolled(true);
          setProgress(enrollmentData.progress || 0);
          setEnrollment(enrollmentData);
        }

        // Kurs tamamlanmış mı?
        const { data: completedData } = await supabase
          .from("completed_courses")
          .select("id")
          .eq("course_id", id)
          .eq("user_id", user.id)
          .single();

        setIsCompleted(!!completedData);

        // Favori mi kontrol et
        const { data: favoriteData } = await supabase
          .from("favorites")
          .select("id")
          .eq("course_id", id)
          .eq("user_id", user.id)
          .single();

        setIsFavorited(!!favoriteData);
      }
    } catch (error) {
      toast.error("Kurs bulunamadı");
      navigate("/courses");
    }

    setLoading(false);
  };

  // Progress güncelleme fonksiyonu
  const updateProgress = async (newProgress) => {
    setProgress(newProgress);
    const { error } = await supabase
      .from('course_enrollments')
      .update({ progress: newProgress })
      .eq('user_id', user.id)
      .eq('course_id', id);
    if (error) {
      console.error('Progress güncelleme hatası:', error);
    }
  };

  // Video izleme progress güncellemesi
  const handleVideoProgress = async () => {
    if (!videoWatched && progress < 80) {
      setVideoWatched(true);
      const newProgress = Math.min(progress + 60, 80);
      setProgress(newProgress);
      await supabase
        .from('course_enrollments')
        .update({ progress: newProgress })
        .eq('user_id', user.id)
        .eq('course_id', id);
      toast.success("Video izlendi olarak işaretlendi");
    }
  };

  // Modül tamamlama simülasyonu (opsiyonel)
  const handleModuleComplete = async (moduleId, moduleIndex) => {
    const progressPerModule = 20;
    const newProgress = Math.min((moduleIndex + 1) * progressPerModule, 100);
    await updateProgress(newProgress);
    if (moduleIndex >= 2) {
      await addPoints(
        user.id,
        'course',
        'quiz_success',
        POINT_VALUES.QUIZ_SUCCESS,
        `"${course.title}" - ${courseModules[moduleIndex].title} quiz başarısı`,
        { course_id: id, module_id: moduleId }
      );
      toast.success(`Quiz tamamlandı! +${POINT_VALUES.QUIZ_SUCCESS} puan`);
    }
  };

  // Kursa kayıt olma fonksiyonu - güncellendi
  const handleEnroll = async () => {
    if (!user) {
      toast.error("Kursa kayıt olmak için giriş yapmalısınız");
      navigate("/login");
      return;
    }
    setEnrolling(true);

    try {
      // Kayıt ekle
      const { error } = await supabase
        .from("course_enrollments")
        .insert({
          user_id: user.id,
          course_id: id,
          progress: 0
        });

      if (error) throw error;

      // Puan ekle
      await addPoints(
        user.id,
        "course",
        "enrollment",
        POINT_VALUES.COURSE_ENROLLMENT,
        `"${course.title}" kursuna kayıt oldunuz`,
        { course_id: id, course_title: course.title }
      );

      toast.success(`Kursa başarıyla kaydoldunuz! +${POINT_VALUES.COURSE_ENROLLMENT} puan kazandınız!`);
      setIsEnrolled(true);
      setEnrollmentCount(prev => prev + 1);
    } catch (error) {
      if (error.code === "23505") {
        toast.error("Bu kursa zaten kayıtlısınız!");
      } else {
        toast.error("Kayıt sırasında bir hata oluştu!");
      }
    } finally {
      setEnrolling(false);
    }
  };

  // Kursu tamamlama fonksiyonu - completing state eklendi
  const handleCompleteCourse = async () => {
    setCompleting(true);
    try {
      // Önce kursu tamamlanmış olarak işaretle
      const { error: completeError } = await supabase
        .from("completed_courses")
        .insert({
          user_id: user.id,
          course_id: id
        });

      if (completeError) {
        if (completeError.code === "23505") {
          toast.error("Bu kursu zaten tamamlamışsınız!");
          setCompleting(false);
          return;
        }
        throw completeError;
      }

      // Progress'i %100 yap
      await supabase
        .from("course_enrollments")
        .update({ progress: 100 })
        .eq("user_id", user.id)
        .eq("course_id", id);

      // Puan ekle
      await addPoints(
        user.id,
        "course",
        "completion",
        POINT_VALUES.COURSE_COMPLETION,
        `"${course.title}" kursunu tamamladınız`,
        { course_id: id, course_title: course.title }
      );

      // Sertifika puanı da ekle
      await addPoints(
        user.id,
        "course",
        "certificate",
        POINT_VALUES.CERTIFICATE,
        `"${course.title}" kursu sertifikası kazandınız`,
        { course_id: id, course_title: course.title }
      );

      toast.success(`Tebrikler! Kursu tamamladınız! +${POINT_VALUES.COURSE_COMPLETION + POINT_VALUES.CERTIFICATE} puan kazandınız!`);
      setIsCompleted(true);
      setProgress(100);
    } catch (error) {
      console.error('Kurs tamamlama hatası:', error);
      toast.error("Kurs tamamlanırken bir hata oluştu!");
    } finally {
      setCompleting(false);
    }
  };

  const handleFavorite = async () => {
    if (!user) {
      toast.error("Favorilere eklemek için giriş yapmalısınız");
      return;
    }

    try {
      if (isFavorited) {
        const { error } = await supabase
          .from("favorites")
          .delete()
          .eq("course_id", id)
          .eq("user_id", user.id);

        if (error) throw error;
        setIsFavorited(false);
        toast.success("Favorilerden kaldırıldı");
      } else {
        const { error } = await supabase
          .from("favorites")
          .insert({
            course_id: id,
            user_id: user.id,
            type: "course"
          });

        if (error) throw error;
        setIsFavorited(true);
        toast.success("Favorilere eklendi");
      }
    } catch (error) {
      toast.error("İşlem başarısız");
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (!course) return null;

  // Modül ilerleme durumunu progress'e göre ayarla
  const courseModules = [
    { id: 1, title: "Giriş ve Kurulum", duration: "15 dk", completed: progress >= 20 },
    { id: 2, title: "Temel Kavramlar", duration: "30 dk", completed: progress >= 40 },
    { id: 3, title: "İleri Seviye Konular", duration: "45 dk", completed: progress >= 60 },
    { id: 4, title: "Proje Uygulaması", duration: "60 dk", completed: progress >= 80 },
    { id: 5, title: "Final Sınavı", duration: "30 dk", completed: progress === 100 }
  ];

  return (
    <div className="max-w-7xl mx-auto py-8">
      {/* Geri Dön */}
      <Link
        to="/courses"
        className="inline-flex items-center text-gray-600 hover:text-gray-900 mb-6"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Kurslara Dön
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sol Kolon - Kurs Detayları */}
        <div className="lg:col-span-2">
          {/* Kurs Başlığı ve Bilgileri */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 mb-6">
            <div className="flex items-start justify-between mb-6">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-4">
                  {course.title}
                </h1>
                <p className="text-lg text-gray-600 mb-6">
                  {course.description}
                </p>
              </div>

              <div className="flex space-x-2">
                <button
                  onClick={handleFavorite}
                  className={`p-2 rounded-lg transition-colors ${
                    isFavorited
                      ? "bg-red-100 text-red-600 hover:bg-red-200"
                      : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                  }`}
                >
                  <Heart className={`w-5 h-5 ${isFavorited ? "fill-current" : ""}`} />
                </button>
                <button className="p-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200">
                  <Share2 className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Kurs İstatistikleri */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <Clock className="w-6 h-6 text-gray-600 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Süre</p>
                <p className="font-semibold">{course.duration || "4 Hafta"}</p>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <Users className="w-6 h-6 text-gray-600 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Öğrenci</p>
                <p className="font-semibold">{enrollmentCount}</p>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <Star className="w-6 h-6 text-gray-600 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Puan</p>
                <p className="font-semibold">{course.rating || "4.8"}/5</p>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <Award className="w-6 h-6 text-gray-600 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Seviye</p>
                <p className="font-semibold">{course.level || "Başlangıç"}</p>
              </div>
            </div>

            {/* İlerleme Durumu (Kayıtlıysa) */}
            {isEnrolled && (
              <div className="mb-6 p-4 bg-purple-50 rounded-lg border border-purple-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-purple-900 font-medium">İlerleme Durumu</span>
                  <span className="text-purple-700 font-semibold">{progress}%</span>
                </div>
                <div className="w-full bg-purple-200 rounded-full h-3">
                  <div
                    className="bg-purple-600 h-3 rounded-full transition-all duration-300"
                    style={{ width: `${progress}%` }}
                  ></div>
                </div>
                {isCompleted && (
                  <div className="mt-3 flex items-center text-green-700">
                    <CheckCircle className="w-5 h-5 mr-2" />
                    <span className="font-medium">Kurs tamamlandı!</span>
                  </div>
                )}
              </div>
            )}

            {/* Video izleme butonu */}
            {isEnrolled && !showVideo && course.video_url && (
              <div className="mb-6 p-6 bg-purple-50 rounded-lg border-2 border-purple-200 text-center">
                <PlayCircle className="w-12 h-12 text-purple-600 mx-auto mb-3" />
                <h3 className="text-lg font-semibold text-purple-900 mb-2">
                  Kursa Başlamaya Hazır mısınız?
                </h3>
                <p className="text-purple-700 mb-4">
                  Videoyu izleyerek kursa başlayın ve puan kazanmaya başlayın!
                </p>
                <button
                  onClick={() => setShowVideo(true)}
                  className="bg-purple-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors inline-flex items-center"
                >
                  <PlayCircle className="w-5 h-5 mr-2" />
                  Videoyu İzle
                </button>
              </div>
            )}

            {/* Video İzleme Alanı */}
            {isEnrolled && showVideo && course.video_url && (
              <div className="mb-6">
                <div className="aspect-video bg-black rounded-lg overflow-hidden">
                  <iframe
                    ref={videoRef}
                    src={`${course.video_url}?enablejsapi=1&rel=0`}
                    title={course.title}
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="w-full h-full"
                    onLoad={() => {
                      if (progress < 20) updateProgress(20);
                    }}
                  />
                </div>
                <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-lg">
                  <p className="text-amber-800 text-sm flex items-center">
                    <AlertCircle className="w-4 h-4 mr-2" />
                    Videoyu sonuna kadar izledikten sonra aşağıdaki "Kursu Tamamla" butonuna tıklayın.
                  </p>
                </div>
                {!isCompleted && (
                  <div className="mt-4 flex items-center justify-between">
                    <button
                      onClick={handleVideoProgress}
                      className="text-purple-600 hover:text-purple-700 text-sm underline"
                      disabled={videoWatched}
                    >
                      {videoWatched ? "Video izlendi olarak işaretlendi" : "Videoyu izledim olarak işaretle"}
                    </button>
                    {videoWatched && (
                      <button
                        onClick={handleCompleteCourse}
                        disabled={completing}
                        className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 flex items-center"
                      >
                        {completing ? (
                          "Tamamlanıyor..."
                        ) : (
                          <>
                            <Award className="w-5 h-5 mr-2" />
                            Kursu Tamamla (+{POINT_VALUES.COURSE_COMPLETION + POINT_VALUES.CERTIFICATE} Puan)
                          </>
                        )}
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Kurs İçeriği */}
            <div>
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Kurs İçeriği</h2>
              <div className="space-y-3">
                {courseModules.map((module, index) => (
                  <div
                    key={module.id}
                    className={`flex items-center justify-between p-4 rounded-lg border ${
                      module.completed
                        ? "bg-green-50 border-green-200"
                        : "bg-gray-50 border-gray-200"
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <span className="text-gray-500 font-medium">{index + 1}</span>
                      {module.completed ? (
                        <CheckCircle className="w-5 h-5 text-green-600" />
                      ) : (
                        <button
                          className="p-0 m-0 bg-transparent border-none"
                          onClick={() => handleModuleComplete(module.id, index)}
                          disabled={!isEnrolled || module.completed}
                          title="Modülü tamamla"
                        >
                          <PlayCircle className="w-5 h-5 text-gray-400" />
                        </button>
                      )}
                      <span className={`font-medium ${
                        module.completed ? "text-green-900" : "text-gray-700"
                      }`}>
                        {module.title}
                      </span>
                    </div>
                    <span className="text-sm text-gray-500">{module.duration}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Eğitmen Bilgisi */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Eğitmen</h2>
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center">
                <span className="text-xl font-semibold text-purple-600">
                  {course.instructor?.[0] || "E"}
                </span>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">{course.instructor || "Eğitmen Adı"}</h3>
                <p className="text-gray-600">Senior Developer</p>
                <div className="flex items-center mt-1">
                  <Star className="w-4 h-4 text-yellow-500 fill-current" />
                  <span className="text-sm text-gray-600 ml-1">4.9 (127 değerlendirme)</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sağ Kolon - Kayıt Kartı */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 sticky top-24">
            {/* Kurs Görseli */}
            <div className="aspect-video bg-gradient-to-br from-purple-500 to-indigo-600 rounded-lg mb-6 flex items-center justify-center">
              <BookOpen className="w-16 h-16 text-white opacity-50" />
            </div>

            {/* Fiyat ve Puan */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <span className="text-3xl font-bold text-gray-900">Ücretsiz</span>
                <div className="text-right">
                  <p className="text-sm text-gray-600">Kazanılacak</p>
                  <p className="text-lg font-semibold text-purple-600">
                    +{POINT_VALUES.COURSE_COMPLETION + POINT_VALUES.CERTIFICATE} Puan
                  </p>
                </div>
              </div>
            </div>

            {/* Kayıt/Devam Butonu ve puanlı butonlar */}
            <div className="mt-8 flex flex-col sm:flex-row gap-4">
              {!isEnrolled ? (
                <button
                  onClick={handleEnroll}
                  disabled={enrolling}
                  className="flex-1 bg-purple-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center"
                >
                  {enrolling ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                      Kaydediliyor...
                    </>
                  ) : (
                    <>
                      <BookOpen className="w-5 h-5 mr-2" />
                      Kursa Kaydol (+{POINT_VALUES.COURSE_ENROLLMENT} puan)
                    </>
                  )}
                </button>
              ) : (
                <>
                  {!isCompleted ? (
                    <>
                      <button
                        className="flex-1 bg-gray-200 text-gray-700 px-6 py-3 rounded-lg font-semibold cursor-not-allowed"
                        disabled
                      >
                        <CheckCircle className="w-5 h-5 mr-2 inline" />
                        Kayıtlısınız
                      </button>
                      {progress >= 80 && (
                        <button
                          onClick={handleCompleteCourse}
                          disabled={completing}
                          className="flex-1 bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors flex items-center justify-center"
                        >
                          <Award className="w-5 h-5 mr-2" />
                          {completing
                            ? "Tamamlanıyor..."
                            : `Kursu Tamamla (+${POINT_VALUES.COURSE_COMPLETION + POINT_VALUES.CERTIFICATE} puan)`}
                        </button>
                      )}
                    </>
                  ) : (
                    <div className="flex-1 bg-green-100 text-green-700 px-6 py-3 rounded-lg font-semibold text-center">
                      <CheckCircle className="w-5 h-5 mr-2 inline" />
                      Kurs Tamamlandı
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Kurs Özellikleri */}
            <div className="mt-6 space-y-3">
              <div className="flex items-center text-gray-600">
                <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                <span className="text-sm">Ömür boyu erişim</span>
              </div>
              <div className="flex items-center text-gray-600">
                <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                <span className="text-sm">Tamamlama sertifikası</span>
              </div>
              <div className="flex items-center text-gray-600">
                <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                <span className="text-sm">Pratik projeler</span>
              </div>
              <div className="flex items-center text-gray-600">
                <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                <span className="text-sm">Mentör desteği</span>
              </div>
            </div>

            {/* Başlangıç Tarihi */}
            <div className="mt-6 p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center text-gray-700">
                <Calendar className="w-5 h-5 mr-2" />
                <div>
                  <p className="text-sm font-medium">Sonraki Dönem</p>
                  <p className="text-xs text-gray-600">1 Şubat 2024</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}