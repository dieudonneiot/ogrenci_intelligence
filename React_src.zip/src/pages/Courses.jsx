import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { supabase } from "../utils/supabaseClient";
import { 
  BookOpen, 
  Star, 
  PlayCircle, 
  Search,
  Filter,
  Clock,
  Users,
  Award,
  ChevronRight,
  Heart,
  CheckCircle
} from "lucide-react";
import toast from "react-hot-toast";

export default function Courses() {
  const { user } = useAuth();
  const [courses, setCourses] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [loading, setLoading] = useState(true);
  const [department, setDepartment] = useState("");
  const [search, setSearch] = useState("");
  const [completedCourses, setCompletedCourses] = useState(new Set());
  const [enrolledCourses, setEnrolledCourses] = useState(new Set());
  const [favoriteCourses, setFavoriteCourses] = useState(new Set());
  const [selectedCategory, setSelectedCategory] = useState("all");

  const categories = [
    { value: "all", label: "Tümü" },
    { value: "programming", label: "Programlama" },
    { value: "web", label: "Web Geliştirme" },
    { value: "mobile", label: "Mobil" },
    { value: "data", label: "Veri Bilimi" },
    { value: "ai", label: "Yapay Zeka" },
    { value: "design", label: "Tasarım" }
  ];

  useEffect(() => {
    fetchCourses();
  }, [user]);

  const fetchCourses = async () => {
    if (!user) {
      toast.error("Lütfen giriş yapın.");
      setLoading(false);
      return;
    }

    setLoading(true);

    try {
      // Kullanıcı profili
      const { data: profile } = await supabase
        .from("profiles")
        .select("department")
        .eq("id", user.id)
        .single();

      if (!profile?.department) {
        toast.error("Bölüm bilgisi bulunamadı. Lütfen profilinizi güncelleyin.");
        setLoading(false);
        return;
      }

      setDepartment(profile.department);

      // Kursları getir
      const { data: coursesData, error: coursesError } = await supabase
        .from("courses")
        .select("*")
        .eq("department", profile.department);

      if (coursesError) {
        console.error("Kurslar yüklenirken hata:", coursesError);
        throw coursesError;
      }

      console.log("Gelen kurslar:", coursesData);

      // Eğer kurs yoksa mock data ekleyelim (test için)
      if (!coursesData || coursesData.length === 0) {
        toast.warning("Bölümünüze ait kurs bulunamadı.");
        setCourses([]);
        setFiltered([]);
        setLoading(false);
        return;
      }

      // Tamamlanan kurslar
      const { data: completedData } = await supabase
        .from("completed_courses")
        .select("course_id")
        .eq("user_id", user.id);

      if (completedData) {
        setCompletedCourses(new Set(completedData.map(c => c.course_id)));
      }

      // Kayıtlı kurslar
      const { data: enrolledData } = await supabase
        .from("course_enrollments")
        .select("course_id")
        .eq("user_id", user.id);

      if (enrolledData) {
        setEnrolledCourses(new Set(enrolledData.map(c => c.course_id)));
      }

      // Favori kurslar
      const { data: favoriteData } = await supabase
        .from("favorites")
        .select("course_id")
        .eq("user_id", user.id)
        .eq("type", "course");

      if (favoriteData) {
        setFavoriteCourses(new Set(favoriteData.map(f => f.course_id)));
      }

      // Ortalama puanları hesapla (basit şekilde)
      const coursesWithStats = coursesData.map(course => ({
        ...course,
        average_rating: course.rating || 0,
        total_ratings: course.rating_count || 0,
        enrolled_count: course.enrolled_count || 0
      }));

      setCourses(coursesWithStats);
      setFiltered(coursesWithStats);
    } catch (error) {
      console.error("Kurslar yüklenirken hata:", error);
      toast.error("Kurslar yüklenemedi.");
    }

    setLoading(false);
  };

  useEffect(() => {
    let filteredData = courses;

    // Kategori filtresi
    if (selectedCategory !== "all") {
      filteredData = filteredData.filter(course => 
        course.category === selectedCategory
      );
    }

    // Arama filtresi
    filteredData = filteredData.filter(course =>
      course.title.toLowerCase().includes(search.toLowerCase()) ||
      course.description?.toLowerCase().includes(search.toLowerCase())
    );

    setFiltered(filteredData);
  }, [search, selectedCategory, courses]);

  const toggleFavorite = async (courseId) => {
    try {
      if (favoriteCourses.has(courseId)) {
        await supabase
          .from("favorites")
          .delete()
          .eq("course_id", courseId)
          .eq("user_id", user.id);
        
        setFavoriteCourses(prev => {
          const newSet = new Set(prev);
          newSet.delete(courseId);
          return newSet;
        });
        toast.success("Favorilerden kaldırıldı");
      } else {
        await supabase
          .from("favorites")
          .insert({
            user_id: user.id,
            course_id: courseId,
            type: "course"
          });
        
        setFavoriteCourses(prev => new Set([...prev, courseId]));
        toast.success("Favorilere eklendi");
      }
    } catch (error) {
      toast.error("İşlem başarısız");
    }
  };

  const getCourseStatus = (courseId) => {
    if (completedCourses.has(courseId)) return "completed";
    if (enrolledCourses.has(courseId)) return "enrolled";
    return "new";
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "completed":
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <CheckCircle className="w-3 h-3 mr-1" />
            Tamamlandı
          </span>
        );
      case "enrolled":
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            <Clock className="w-3 h-3 mr-1" />
            Devam Ediyor
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="max-w-7xl mx-auto py-8">
      {/* Başlık ve Arama */}
      <div className="text-center mb-10">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          {department} Kursları
        </h1>
        <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
          Bölümünüze özel hazırlanmış kurslarla kendinizi geliştirin ve kariyerinize yön verin.
        </p>
        
        {/* Arama ve Filtreler */}
        <div className="flex flex-col md:flex-row gap-4 max-w-4xl mx-auto">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Kurs ara..."
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
          </div>
          
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          >
            {categories.map(cat => (
              <option key={cat.value} value={cat.value}>{cat.label}</option>
            ))}
          </select>
        </div>
      </div>

      {/* İstatistikler */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Toplam Kurs</p>
              <p className="text-2xl font-bold text-gray-900">{courses.length}</p>
            </div>
            <BookOpen className="w-8 h-8 text-purple-600" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Devam Eden</p>
              <p className="text-2xl font-bold text-blue-600">{enrolledCourses.size - completedCourses.size}</p>
            </div>
            <Clock className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Tamamlanan</p>
              <p className="text-2xl font-bold text-green-600">{completedCourses.size}</p>
            </div>
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Kazanılan Puan</p>
              <p className="text-2xl font-bold text-yellow-600">{completedCourses.size * 50}</p>
            </div>
            <Award className="w-8 h-8 text-yellow-600" />
          </div>
        </div>
      </div>

      {/* Kurs Listesi */}
      {loading ? (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12">
          <BookOpen className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">Aradığınız kriterlere uygun kurs bulunamadı.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((course) => {
            const status = getCourseStatus(course.id);
            const isFavorite = favoriteCourses.has(course.id);
            
            return (
              <div
                key={course.id}
                className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow"
              >
                {/* Kurs Görseli */}
                <div className="aspect-video bg-gradient-to-br from-purple-500 to-indigo-600 relative">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <BookOpen className="w-16 h-16 text-white opacity-50" />
                  </div>
                  {/* Favori Butonu */}
                  <button
                    onClick={() => toggleFavorite(course.id)}
                    className="absolute top-4 right-4 p-2 bg-white/90 backdrop-blur rounded-lg hover:bg-white transition-colors"
                  >
                    <Heart 
                      className={`w-5 h-5 ${
                        isFavorite ? "fill-red-500 text-red-500" : "text-gray-600"
                      }`} 
                    />
                  </button>
                  {/* Durum Badge */}
                  {status !== "new" && (
                    <div className="absolute top-4 left-4">
                      {getStatusBadge(status)}
                    </div>
                  )}
                </div>

                {/* Kurs Bilgileri */}
                <div className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    {course.title}
                  </h3>
                  <p className="text-sm text-gray-600 line-clamp-2 mb-4">
                    {course.description}
                  </p>

                  {/* İstatistikler */}
                  <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                    <div className="flex items-center">
                      <Star className="w-4 h-4 text-yellow-500 mr-1" />
                      <span>
                        {course.average_rating > 0 
                          ? course.average_rating.toFixed(1) 
                          : "Henüz değerlendirilmedi"}
                      </span>
                      {course.total_ratings > 0 && (
                        <span className="ml-1">({course.total_ratings})</span>
                      )}
                    </div>
                    <div className="flex items-center">
                      <Users className="w-4 h-4 mr-1" />
                      <span>{course.enrolled_count} öğrenci</span>
                    </div>
                  </div>

                  {/* Eğitmen */}
                  {course.instructor && (
                    <p className="text-sm text-gray-600 mb-4">
                      Eğitmen: <span className="font-medium">{course.instructor}</span>
                    </p>
                  )}

                  {/* Aksiyon Butonu */}
                  <Link
                    to={`/courses/${course.id}`}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      width: '100%',
                      padding: '8px 16px',
                      borderRadius: '8px',
                      fontWeight: '500',
                      transition: 'all 0.2s',
                      textDecoration: 'none',
                      backgroundColor: '#7c3aed',
                      color: '#ffffff',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = '#6d28d9';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = '#7c3aed';
                    }}
                  >
                    {status === "completed" ? "Tekrar İzle" : 
                     status === "enrolled" ? "Devam Et" : 
                     "Kursa Başla"}
                    <ChevronRight className="w-4 h-4 ml-1" style={{ color: 'inherit' }} />
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}