// src/pages/Dashboard.jsx

import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { supabase } from "../utils/supabaseClient";
import { 
  getUserTotalPoints, 
  getUserActivityLogs, 
  checkDailyLogin,
  checkWeeklyStreak 
} from "../services/pointsService";
import { 
  BookOpen, 
  Briefcase, 
  Trophy, 
  TrendingUp,
  Clock,
  Award,
  Target,
  Activity
} from "lucide-react";
import toast from "react-hot-toast";

export default function Dashboard() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalPoints: 0,
    coursesCompleted: 0,
    activeApplications: 0,
    departmentRank: null
  });
  const [recentActivities, setRecentActivities] = useState([]);
  const [enrolledCourses, setEnrolledCourses] = useState([]);

  useEffect(() => {
    if (user) {
      loadDashboardData();
      checkLoginBonuses();
    }
  }, [user]);

  const checkLoginBonuses = async () => {
    try {
      // Günlük giriş kontrolü
      const { alreadyLoggedIn } = await checkDailyLogin(user.id);
      if (!alreadyLoggedIn) {
        toast.success('Günlük giriş bonusu kazandınız! +2 puan', {
          id: 'daily-login', // Aynı id ile sadece bir kez gösterir
          duration: 5000
        });
        
        // Dashboard verilerini yenile (puan güncellemesi için)
        await loadDashboardData();
      }

      // Haftalık seri kontrolü
      const { streakAwarded } = await checkWeeklyStreak(user.id);
      if (streakAwarded) {
        toast.success('7 günlük seri tamamlandı! +15 puan', {
          id: 'weekly-streak',
          duration: 5000
        });
        
        // Dashboard verilerini yenile
        await loadDashboardData();
      }
    } catch (error) {
      console.error('Login bonus kontrolü hatası:', error);
    }
  };

  const loadDashboardData = async () => {
    setLoading(true);
    try {
      // Paralel olarak tüm verileri çek
      const [
        totalPoints,
        activities,
        completedCourses,
        applications,
        enrollments,
        departmentRank
      ] = await Promise.all([
        getUserTotalPoints(user.id),
        getUserActivityLogs(user.id, 10),
        getCompletedCoursesCount(),
        getActiveApplicationsCount(),
        getEnrolledCourses(),
        getDepartmentRank()
      ]);

      setStats({
        totalPoints,
        coursesCompleted: completedCourses,
        activeApplications: applications,
        departmentRank
      });

      setRecentActivities(activities);
      setEnrolledCourses(enrollments);
    } catch (error) {
      console.error('Dashboard verileri yüklenirken hata:', error);
      toast.error('Veriler yüklenirken bir hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  const getCompletedCoursesCount = async () => {
    const { count } = await supabase
      .from('completed_courses')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id);
    return count || 0;
  };

  const getActiveApplicationsCount = async () => {
    const { data: jobApps } = await supabase
      .from('job_applications')
      .select('id')
      .eq('user_id', user.id)
      .eq('status', 'pending');

    const { data: internshipApps } = await supabase
      .from('internship_applications')
      .select('id')
      .eq('user_id', user.id)
      .eq('status', 'pending');

    return (jobApps?.length || 0) + (internshipApps?.length || 0);
  };

  const getEnrolledCourses = async () => {
    const { data, error } = await supabase
      .from('course_enrollments')
      .select(`
        id,
        progress,
        enrolled_at,
        courses (
          id,
          title,
          description,
          duration,
          level
        )
      `)
      .eq('user_id', user.id)
      .order('enrolled_at', { ascending: false })
      .limit(3);

    if (error) {
      console.error('Kayıtlı kurslar alınamadı:', error);
      return [];
    }

    return data || [];
  };

  const getDepartmentRank = async () => {
    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('department')
        .eq('id', user.id)
        .single();

      if (!profile?.department) return null;

      const { data } = await supabase
        .from('department_leaderboard')
        .select('rank_in_department')
        .eq('user_id', user.id)
        .eq('department', profile.department)
        .single();

      return data?.rank_in_department || null;
    } catch (error) {
      console.error('Bölüm sıralaması alınamadı:', error);
      return null;
    }
  };

  const getActivityIcon = (category) => {
    const icons = {
      'course': BookOpen,
      'job': Briefcase,
      'internship': Briefcase,
      'achievement': Trophy,
      'platform': Activity
    };
    const Icon = icons[category] || Activity;
    return <Icon className="w-5 h-5" />;
  };

  const getActivityColor = (category) => {
    const colors = {
      'course': 'text-blue-600 bg-blue-100',
      'job': 'text-purple-600 bg-purple-100',
      'internship': 'text-green-600 bg-green-100',
      'achievement': 'text-yellow-600 bg-yellow-100',
      'platform': 'text-gray-600 bg-gray-100'
    };
    return colors[category] || 'text-gray-600 bg-gray-100';
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      {/* Hoşgeldin Mesajı */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Hoş Geldin, {user.user_metadata?.full_name || user.email?.split('@')[0]}! 👋
        </h1>
        <p className="text-gray-600">
          Bugün kariyerine yön verecek yeni fırsatlar seni bekliyor.
        </p>
      </div>

      {/* İstatistik Kartları */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <Trophy className="w-6 h-6 text-purple-600" />
            </div>
            <TrendingUp className="w-5 h-5 text-green-500" />
          </div>
          <h3 className="text-2xl font-bold text-gray-900">{stats.totalPoints}</h3>
          <p className="text-gray-600 text-sm">Toplam Puan</p>
          {stats.departmentRank && (
            <p className="text-xs text-purple-600 mt-1">
              Bölüm sıralaması: {stats.departmentRank}.
            </p>
          )}
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-blue-600" />
            </div>
          </div>
          <h3 className="text-2xl font-bold text-gray-900">{stats.coursesCompleted}</h3>
          <p className="text-gray-600 text-sm">Tamamlanan Kurs</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <Briefcase className="w-6 h-6 text-green-600" />
            </div>
          </div>
          <h3 className="text-2xl font-bold text-gray-900">{stats.activeApplications}</h3>
          <p className="text-gray-600 text-sm">Aktif Başvuru</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
              <Target className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
          <h3 className="text-2xl font-bold text-gray-900">{enrolledCourses.length}</h3>
          <p className="text-gray-600 text-sm">Devam Eden Kurs</p>
        </div>
      </div>

      {/* Puan Durumu Widget'ı - YENİ */}
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-xl p-6 text-white mb-8">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="flex items-center space-x-6 mb-4 md:mb-0">
            <Trophy className="w-16 h-16 text-purple-200" />
            <div>
              <h3 className="text-xl font-bold mb-2">Puan Durumun</h3>
              <div className="flex items-baseline space-x-2">
                <p className="text-3xl font-bold">{stats.totalPoints}</p>
                <span className="text-purple-200">Puan</span>
              </div>
              {stats.departmentRank && (
                <p className="text-purple-200 mt-1">
                  Bölüm sıralaması: <span className="font-semibold text-white">{stats.departmentRank}.</span>
                </p>
              )}
            </div>
          </div>
          
          {/* Butonlar */}
          <div className="flex flex-col w-full md:w-auto gap-3 md:flex-row md:gap-3">
            <Link 
              to="/leaderboard" 
              className="w-full md:w-auto bg-yellow-400 text-gray-900 font-bold px-6 py-3 rounded-lg shadow-lg hover:bg-yellow-300 transition-all flex items-center justify-center text-base"
            >
              <Award className="w-5 h-5 mr-2" />
              Sıralamayı Gör
            </Link>
            <Link 
              to="/points-system" 
              className="w-full md:w-auto bg-white text-purple-700 font-bold px-6 py-3 rounded-lg shadow-lg hover:bg-purple-100 transition-all flex items-center justify-center text-base"
            >
              <Target className="w-5 h-5 mr-2" />
              Nasıl Puan Kazanırım?
            </Link>
          </div>
        </div>
        
        {/* Mini İlerleme Göstergesi */}
        <div className="mt-6 pt-6 border-t border-purple-400/30">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <p className="text-purple-200 text-sm">Bugün</p>
              <p className="text-xl font-semibold">+{recentActivities.filter(a => 
                new Date(a.created_at).toDateString() === new Date().toDateString()
              ).reduce((sum, a) => sum + (a.points || 0), 0)} puan</p>
            </div>
            <div>
              <p className="text-purple-200 text-sm">Bu Hafta</p>
              <p className="text-xl font-semibold">+{recentActivities.filter(a => {
                const activityDate = new Date(a.created_at);
                const oneWeekAgo = new Date();
                oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
                return activityDate >= oneWeekAgo;
              }).reduce((sum, a) => sum + (a.points || 0), 0)} puan</p>
            </div>
            <div>
              <p className="text-purple-200 text-sm">Kurs Tamamlama</p>
              <p className="text-xl font-semibold">{stats.coursesCompleted}</p>
            </div>
            <div>
              <p className="text-purple-200 text-sm">Sonraki Hedef</p>
              <p className="text-xl font-semibold">{
                stats.totalPoints < 100 ? '100' :
                stats.totalPoints < 500 ? '500' :
                stats.totalPoints < 1000 ? '1000' :
                stats.totalPoints < 5000 ? '5000' : '10000'
              } puan</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sol Kolon - Devam Eden Kurslar */}
        <div className="lg:col-span-2 space-y-6">
          {/* Devam Eden Kurslar */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900 flex items-center">
                <BookOpen className="w-6 h-6 text-blue-600 mr-2" />
                Devam Eden Kurslarım
              </h2>
              <Link 
                to="/courses" 
                className="text-purple-600 hover:text-purple-700 text-sm font-medium"
              >
                Tümünü Gör →
              </Link>
            </div>

            {enrolledCourses.length > 0 ? (
              <div className="space-y-4">
                {enrolledCourses.map((enrollment) => (
                  <div key={enrollment.id} className="border border-gray-200 rounded-lg p-4 hover:border-purple-300 transition-colors">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold text-gray-900">
                        {enrollment.courses.title}
                      </h3>
                      <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">
                        {enrollment.courses.level}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                      {enrollment.courses.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-xs text-gray-500">
                        <span className="flex items-center">
                          <Clock className="w-3 h-3 mr-1" />
                          {enrollment.courses.duration}
                        </span>
                      </div>
                      <div className="w-32">
                        <div className="bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full transition-all"
                            style={{ width: `${enrollment.progress || 0}%` }}
                          />
                        </div>
                        <span className="text-xs text-gray-600 mt-1">
                          %{enrollment.progress || 0} tamamlandı
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <BookOpen className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">Henüz kayıtlı kursunuz yok.</p>
                <Link 
                  to="/courses" 
                  className="text-purple-600 hover:text-purple-700 text-sm font-medium mt-2 inline-block"
                >
                  Kursları Keşfet →
                </Link>
              </div>
            )}
          </div>
        </div>

        {/* Sağ Kolon - Son Aktiviteler */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 sticky top-4">
            <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
              <Activity className="w-6 h-6 text-purple-600 mr-2" />
              Son Aktiviteler
            </h2>

            {recentActivities.length > 0 ? (
              <div className="space-y-4 max-h-96 overflow-y-auto custom-scrollbar">
                {recentActivities.map((activity) => (
                  <div key={activity.id} className="flex items-start space-x-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${getActivityColor(activity.category)}`}>
                      {getActivityIcon(activity.category)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900">
                        {activity.action}
                      </p>
                      <div className="flex items-center justify-between mt-1">
                        <p className="text-xs text-gray-500">
                          {new Date(activity.created_at).toLocaleDateString('tr-TR')}
                        </p>
                        {activity.points > 0 && (
                          <span className="text-xs font-medium text-green-600">
                            +{activity.points} puan
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Activity className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500 text-sm">Henüz aktivite yok.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}