import { useState, useEffect } from "react";
import { useAuth } from "../contexts/AuthContext";
import { supabase } from "../utils/supabaseClient";
import { Database, Table, AlertCircle, CheckCircle } from "lucide-react";

export default function DatabaseDebug() {
  const { user } = useAuth();
  const [tables, setTables] = useState({});
  const [loading, setLoading] = useState(true);
  const [userProfile, setUserProfile] = useState(null);

  useEffect(() => {
    checkDatabase();
  }, [user]);

  const checkDatabase = async () => {
    if (!user) {
      setLoading(false);
      return;
    }

    const results = {};

    // 1. Kullanıcı profili kontrolü
    try {
      const { data: profile, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .single();

      if (profile) {
        setUserProfile(profile);
        results.profiles = { 
          success: true, 
          count: 1, 
          data: profile,
          message: `Profil bulundu - Bölüm: ${profile.department || "Belirtilmemiş"}`
        };
      } else {
        results.profiles = { 
          success: false, 
          error: error?.message || "Profil bulunamadı" 
        };
      }
    } catch (error) {
      results.profiles = { success: false, error: error.message };
    }

    // 2. Courses tablosu kontrolü
    try {
      const { data: courses, error, count } = await supabase
        .from("courses")
        .select("*", { count: "exact" });

      if (error) throw error;

      results.courses = { 
        success: true, 
        count: count || courses?.length || 0,
        sample: courses?.slice(0, 3),
        columns: courses?.length > 0 ? Object.keys(courses[0]) : []
      };

      // Bölüme göre kurs kontrolü
      if (userProfile?.department) {
        const { data: deptCourses, count: deptCount } = await supabase
          .from("courses")
          .select("*", { count: "exact" })
          .eq("department", userProfile.department);

        results.courses.departmentCount = deptCount || deptCourses?.length || 0;
      }
    } catch (error) {
      results.courses = { success: false, error: error.message };
    }

    // 3. Internships tablosu kontrolü
    try {
      const { data: internships, error, count } = await supabase
        .from("internships")
        .select("*", { count: "exact" });

      if (error) throw error;

      results.internships = { 
        success: true, 
        count: count || internships?.length || 0,
        sample: internships?.slice(0, 3),
        columns: internships?.length > 0 ? Object.keys(internships[0]) : []
      };

      // Bölüme göre staj kontrolü
      if (userProfile?.department) {
        const { data: deptInternships, count: deptCount } = await supabase
          .from("internships")
          .select("*", { count: "exact" })
          .eq("department", userProfile.department);

        results.internships.departmentCount = deptCount || deptInternships?.length || 0;
      }
    } catch (error) {
      results.internships = { success: false, error: error.message };
    }

    // 4. Jobs tablosu kontrolü
    try {
      const { data: jobs, error, count } = await supabase
        .from("jobs")
        .select("*", { count: "exact" });

      if (error) throw error;

      results.jobs = { 
        success: true, 
        count: count || jobs?.length || 0,
        sample: jobs?.slice(0, 3),
        columns: jobs?.length > 0 ? Object.keys(jobs[0]) : []
      };

      // Bölüme göre iş kontrolü
      if (userProfile?.department) {
        const { data: deptJobs, count: deptCount } = await supabase
          .from("jobs")
          .select("*", { count: "exact" })
          .eq("department", userProfile.department);

        const { data: partTimeJobs, count: ptCount } = await supabase
          .from("jobs")
          .select("*", { count: "exact" })
          .eq("type", "part-time");

        results.jobs.departmentCount = deptCount || deptJobs?.length || 0;
        results.jobs.partTimeCount = ptCount || partTimeJobs?.length || 0;
      }
    } catch (error) {
      results.jobs = { success: false, error: error.message };
    }

    setTables(results);
    setLoading(false);
  };

  if (!user) {
    return (
      <div className="max-w-4xl mx-auto py-8">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6">
          <p className="text-red-800">Lütfen giriş yapın.</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center">
          <Database className="w-8 h-8 mr-3 text-purple-600" />
          Veritabanı Kontrol Paneli
        </h1>
        <p className="text-gray-600">Supabase tablolarının durumunu kontrol edin</p>
      </div>

      {/* Kullanıcı Bilgileri */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
        <h2 className="text-lg font-semibold mb-4 flex items-center">
          <Table className="w-5 h-5 mr-2 text-gray-600" />
          Kullanıcı Bilgileri
        </h2>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="font-medium">User ID:</span> {user.id}
          </div>
          <div>
            <span className="font-medium">Email:</span> {user.email}
          </div>
          {userProfile && (
            <>
              <div>
                <span className="font-medium">Bölüm:</span> {userProfile.department || "Belirtilmemiş"}
              </div>
              <div>
                <span className="font-medium">Sınıf:</span> {userProfile.year || "Belirtilmemiş"}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Tablo Durumları */}
      {Object.entries(tables).map(([tableName, result]) => (
        <div key={tableName} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold flex items-center">
              <Table className="w-5 h-5 mr-2 text-gray-600" />
              {tableName} Tablosu
            </h2>
            {result.success ? (
              <CheckCircle className="w-6 h-6 text-green-500" />
            ) : (
              <AlertCircle className="w-6 h-6 text-red-500" />
            )}
          </div>

          {result.success ? (
            <div className="space-y-3">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                <div className="bg-gray-50 p-3 rounded">
                  <span className="font-medium">Toplam Kayıt:</span> {result.count}
                </div>
                {result.departmentCount !== undefined && (
                  <div className="bg-purple-50 p-3 rounded">
                    <span className="font-medium">Bölüm Kayıtları:</span> {result.departmentCount}
                  </div>
                )}
                {result.partTimeCount !== undefined && (
                  <div className="bg-blue-50 p-3 rounded">
                    <span className="font-medium">Part-Time:</span> {result.partTimeCount}
                  </div>
                )}
              </div>

              {result.columns && result.columns.length > 0 && (
                <div className="mt-4">
                  <p className="text-sm font-medium mb-2">Tablo Kolonları:</p>
                  <div className="flex flex-wrap gap-2">
                    {result.columns.map(col => (
                      <span key={col} className="px-2 py-1 bg-gray-100 text-xs rounded">
                        {col}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {result.sample && result.sample.length > 0 && (
                <div className="mt-4">
                  <p className="text-sm font-medium mb-2">Örnek Kayıtlar:</p>
                  <div className="overflow-x-auto">
                    <pre className="text-xs bg-gray-50 p-3 rounded overflow-auto">
                      {JSON.stringify(result.sample, null, 2)}
                    </pre>
                  </div>
                </div>
              )}

              {result.message && (
                <p className="text-sm text-green-600 mt-2">{result.message}</p>
              )}
            </div>
          ) : (
            <div className="bg-red-50 p-4 rounded">
              <p className="text-red-800 text-sm">
                <strong>Hata:</strong> {result.error}
              </p>
            </div>
          )}
        </div>
      ))}

      {/* Öneriler */}
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-6">
        <h3 className="font-semibold text-amber-900 mb-3 flex items-center">
          <AlertCircle className="w-5 h-5 mr-2" />
          Kontrol Edilecekler:
        </h3>
        <ul className="space-y-2 text-sm text-amber-800">
          <li>• Profil tablosunda department alanı dolu mu?</li>
          <li>• courses, internships ve jobs tablolarında department kolonları var mı?</li>
          <li>• Tablolarda kayıt var mı? Yoksa örnek veri eklenmeli.</li>
          <li>• RLS (Row Level Security) politikaları aktif mi?</li>
          <li>• Kullanıcının bölümüne uygun kayıtlar var mı?</li>
        </ul>
      </div>
    </div>
  );
}