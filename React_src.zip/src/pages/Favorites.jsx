import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { supabase } from "../utils/supabaseClient";
import toast from "react-hot-toast";
import { 
  Heart,
  BookOpen,
  Briefcase,
  Building,
  MapPin,
  Clock,
  Users,
  Star,
  Trash2,
  Filter,
  Grid,
  List
} from "lucide-react";

export default function Favorites() {
  const { user } = useAuth();
  const [favorites, setFavorites] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("all");
  const [viewMode, setViewMode] = useState("grid");
  const [removing, setRemoving] = useState(null);

  useEffect(() => {
    if (user) {
      fetchFavorites();
    }
  }, [user, activeTab]);

  const fetchFavorites = async () => {
    setLoading(true);
    
    try {
      let query = supabase
        .from("favorites")
        .select("*")
        .eq("user_id", user.id);

      if (activeTab !== "all") {
        query = query.eq("type", activeTab);
      }

      const { data: favoritesData, error } = await query;

      if (error) throw error;

      // Her favori için detay bilgilerini çek
      const detailedFavorites = await Promise.all(
        favoritesData.map(async (fav) => {
          let details = null;
          
          if (fav.type === "course" && fav.course_id) {
            const { data } = await supabase
              .from("courses")
              .select("*")
              .eq("id", fav.course_id)
              .single();
            details = data;
          } else if (fav.type === "job" && fav.job_id) {
            const { data } = await supabase
              .from("jobs")
              .select("*")
              .eq("id", fav.job_id)
              .single();
            details = data;
          } else if (fav.type === "internship" && fav.internship_id) {
            const { data } = await supabase
              .from("internships")
              .select("*")
              .eq("id", fav.internship_id)
              .single();
            details = data;
          }

          return {
            ...fav,
            details
          };
        })
      );

      setFavorites(detailedFavorites.filter(fav => fav.details));
    } catch (error) {
      console.error("Favoriler alınamadı:", error);
      toast.error("Favoriler yüklenirken hata oluştu");
    }
    
    setLoading(false);
  };

  const removeFavorite = async (favoriteId, type) => {
    setRemoving(favoriteId);
    
    try {
      const { error } = await supabase
        .from("favorites")
        .delete()
        .eq("id", favoriteId);

      if (error) throw error;

      setFavorites(favorites.filter(fav => fav.id !== favoriteId));
      toast.success("Favorilerden kaldırıldı");
    } catch (error) {
      toast.error("İşlem başarısız");
    }
    
    setRemoving(null);
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case "course":
        return <BookOpen className="w-5 h-5 text-purple-600" />;
      case "job":
        return <Briefcase className="w-5 h-5 text-blue-600" />;
      case "internship":
        return <Building className="w-5 h-5 text-green-600" />;
      default:
        return <Heart className="w-5 h-5 text-gray-600" />;
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case "course":
        return "bg-purple-100 text-purple-700";
      case "job":
        return "bg-blue-100 text-blue-700";
      case "internship":
        return "bg-green-100 text-green-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  const getDetailLink = (fav) => {
    switch (fav.type) {
      case "course":
        return `/courses/${fav.course_id}`;
      case "job":
        return `/jobs/${fav.job_id}`;
      case "internship":
        return `/internships/${fav.internship_id}`;
      default:
        return "#";
    }
  };

  const tabs = [
    { id: "all", label: "Tümü", count: favorites.length },
    { id: "course", label: "Kurslar", count: favorites.filter(f => f.type === "course").length },
    { id: "job", label: "İş İlanları", count: favorites.filter(f => f.type === "job").length },
    { id: "internship", label: "Stajlar", count: favorites.filter(f => f.type === "internship").length }
  ];

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto py-8">
      {/* Başlık */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center">
          <Heart className="w-8 h-8 text-red-500 mr-3 fill-current" />
          Favorilerim
        </h1>
        <p className="text-gray-600">Beğendiğiniz içerikleri buradan takip edebilirsiniz.</p>
      </div>

      {/* Sekmeler ve Görünüm Seçenekleri */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-6">
        <div className="border-b border-gray-200 px-6">
          <div className="flex items-center justify-between">
            <nav className="flex space-x-8" aria-label="Tabs">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? "border-purple-600 text-purple-600"
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  }`}
                >
                  {tab.label}
                  {tab.count > 0 && (
                    <span className="ml-2 bg-gray-100 text-gray-600 py-0.5 px-2 rounded-full text-xs">
                      {tab.count}
                    </span>
                  )}
                </button>
              ))}
            </nav>
            
            {/* Görünüm Değiştirme */}
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setViewMode("grid")}
                className={`p-2 rounded-lg ${
                  viewMode === "grid" 
                    ? "bg-purple-100 text-purple-600" 
                    : "text-gray-400 hover:text-gray-600"
                }`}
              >
                <Grid className="w-5 h-5" />
              </button>
              <button
                onClick={() => setViewMode("list")}
                className={`p-2 rounded-lg ${
                  viewMode === "list" 
                    ? "bg-purple-100 text-purple-600" 
                    : "text-gray-400 hover:text-gray-600"
                }`}
              >
                <List className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Favoriler Listesi */}
      {favorites.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
          <Heart className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600 mb-4">Henüz favoriniz bulunmuyor.</p>
          <div className="space-x-4">
            <Link to="/courses" className="text-purple-600 hover:text-purple-700 font-medium">
              Kursları Keşfet
            </Link>
            <span className="text-gray-400">•</span>
            <Link to="/jobs" className="text-purple-600 hover:text-purple-700 font-medium">
              İş İlanlarına Göz At
            </Link>
            <span className="text-gray-400">•</span>
            <Link to="/internships" className="text-purple-600 hover:text-purple-700 font-medium">
              Stajları İncele
            </Link>
          </div>
        </div>
      ) : viewMode === "grid" ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {favorites.map((favorite) => (
            <div key={favorite.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow">
              {/* Kart Başlığı */}
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                      {getTypeIcon(favorite.type)}
                    </div>
                    <div>
                      <span className={`text-xs font-medium px-2 py-1 rounded-full ${getTypeColor(favorite.type)}`}>
                        {favorite.type === "course" ? "Kurs" : 
                         favorite.type === "job" ? "İş İlanı" : "Staj"}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => removeFavorite(favorite.id, favorite.type)}
                    disabled={removing === favorite.id}
                    className="text-gray-400 hover:text-red-500 transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>

                {/* İçerik Detayları */}
                <h3 className="font-semibold text-gray-900 mb-2">
                  {favorite.details?.title}
                </h3>
                
                {favorite.type === "course" && (
                  <div className="space-y-2 text-sm text-gray-600">
                    <div className="flex items-center">
                      <Users className="w-4 h-4 mr-2" />
                      <span>{favorite.details?.enrolled_count || 0} öğrenci</span>
                    </div>
                    <div className="flex items-center">
                      <Star className="w-4 h-4 mr-2 text-yellow-500 fill-current" />
                      <span>{favorite.details?.rating || "4.5"}/5</span>
                    </div>
                  </div>
                )}

                {(favorite.type === "job" || favorite.type === "internship") && (
                  <div className="space-y-2 text-sm text-gray-600">
                    <div className="flex items-center">
                      <Building className="w-4 h-4 mr-2" />
                      <span>{favorite.details?.company}</span>
                    </div>
                    <div className="flex items-center">
                      <MapPin className="w-4 h-4 mr-2" />
                      <span>{favorite.details?.location}</span>
                    </div>
                  </div>
                )}

                <Link
                  to={getDetailLink(favorite)}
                  className="mt-4 inline-flex items-center text-purple-600 hover:text-purple-700 font-medium text-sm"
                >
                  Detayları Gör →
                </Link>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-4">
          {favorites.map((favorite) => (
            <div key={favorite.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                    {getTypeIcon(favorite.type)}
                  </div>
                  <div>
                    <div className="flex items-center space-x-2 mb-1">
                      <h3 className="font-semibold text-gray-900">
                        {favorite.details?.title}
                      </h3>
                      <span className={`text-xs font-medium px-2 py-1 rounded-full ${getTypeColor(favorite.type)}`}>
                        {favorite.type === "course" ? "Kurs" : 
                         favorite.type === "job" ? "İş İlanı" : "Staj"}
                      </span>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      {favorite.type === "course" ? (
                        <>
                          <span>{favorite.details?.instructor}</span>
                          <span>•</span>
                          <span>{favorite.details?.duration || "4 Hafta"}</span>
                        </>
                      ) : (
                        <>
                          <span>{favorite.details?.company}</span>
                          <span>•</span>
                          <span>{favorite.details?.location}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Link
                    to={getDetailLink(favorite)}
                    className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors text-sm font-medium"
                  >
                    Detayları Gör
                  </Link>
                  <button
                    onClick={() => removeFavorite(favorite.id, favorite.type)}
                    disabled={removing === favorite.id}
                    className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}