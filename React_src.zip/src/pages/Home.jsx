import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import {
  GraduationCap,
  Briefcase,
  ClipboardList,
  Users,
  Star,
  Target,
  BarChart2,
  HeartHandshake,
  User,
  LogOut,
} from "lucide-react";
import HowItWorks from "@/components/HowItWorks";
import { supabase } from "@/utils/supabaseClient";

export default function Home() {
  const [session, setSession] = useState(null);

  useEffect(() => {
    const fetchSession = async () => {
      const { data } = await supabase.auth.getSession();
      setSession(data?.session);
    };

    fetchSession();

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => {
      listener?.subscription.unsubscribe();
    };
  }, []);

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-purple-50 py-16 px-6 md:px-16">
      
      {/* Hero Bölümü */}
      <motion.section
        className="max-w-5xl mx-auto text-center bg-gradient-to-br from-purple-700 via-indigo-700 to-blue-800 rounded-3xl p-8 sm:p-12 md:p-16 shadow-lg"
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9 }}
      >
        <h1 className="text-white text-3xl sm:text-4xl md:text-6xl font-extrabold mb-6 tracking-tight leading-snug">
          Üniversite Hayatını Güçlendir, <br /> Kariyerine Hızla Yön Ver!
        </h1>
        <p className="text-indigo-200 text-base sm:text-lg md:text-2xl mb-10 leading-relaxed max-w-3xl mx-auto">
          Alanına özel kurslar, stajlar ve iş ilanları ile geleceğine sağlam adımlarla ilerle.
        </p>

        <div className="flex flex-col sm:flex-row justify-center items-center gap-4 sm:gap-6">
          {!session ? (
            <>
              <Link
                to="/register"
                className="bg-yellow-400 text-gray-900 font-bold hover:bg-yellow-500 shadow-xl rounded-xl px-10 py-4 text-base sm:text-lg transition transform hover:scale-105"
              >
                Kayıt Ol
              </Link>
              <Link
                to="/login"
                className="bg-yellow-400 text-gray-900 font-bold hover:bg-yellow-500 shadow-xl rounded-xl px-10 py-4 text-base sm:text-lg transition transform hover:scale-105"
              >
                Giriş Yap
              </Link>
            </>
          ) : (
            <>
              <Link
                to="/profile"
                className="bg-green-400 text-gray-900 font-bold hover:bg-green-500 shadow-xl rounded-xl px-10 py-4 text-base sm:text-lg transition transform hover:scale-105 flex items-center gap-2"
              >
                <User size={18} /> Profil
              </Link>
              <button
                onClick={handleLogout}
                className="bg-red-400 text-white font-bold hover:bg-red-500 shadow-xl rounded-xl px-10 py-4 text-base sm:text-lg transition transform hover:scale-105 flex items-center gap-2"
              >
                <LogOut size={18} /> Çıkış Yap
              </button>
            </>
          )}
        </div>
      </motion.section>

      {/* Avantajlar / Özellikler */}
      <motion.section
        className="mt-24 max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-10 text-center"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={{
          hidden: { opacity: 0, y: 30 },
          visible: { opacity: 1, y: 0, transition: { staggerChildren: 0.3 } },
        }}
      >
        {[
          {
            icon: <GraduationCap size={48} className="mx-auto text-purple-600" />,
            title: "Alanına Özel İçerikler",
            description: "Bölümüne uygun kurslar, stajlar ve iş ilanlarıyla odaklanmış öğrenme.",
          },
          {
            icon: <Briefcase size={48} className="mx-auto text-purple-600" />,
            title: "Kariyerine Yön Ver",
            description: "Kişiselleştirilmiş kariyer rehberliği ve fırsatlarla desteklen.",
          },
          {
            icon: <ClipboardList size={48} className="mx-auto text-purple-600" />,
            title: "Kolay ve Hızlı Kullanım",
            description: "Modern tasarım ve kullanıcı dostu arayüz ile zamandan tasarruf et.",
          },
        ].map(({ icon, title, description }, i) => (
          <motion.div
            key={i}
            className="bg-white rounded-3xl shadow-lg p-10 flex flex-col items-center"
            variants={{
              hidden: { opacity: 0, y: 20 },
              visible: { opacity: 1, y: 0 },
            }}
          >
            {icon}
            <h3 className="mt-6 text-2xl font-semibold text-purple-800">{title}</h3>
            <p className="mt-4 text-gray-600 max-w-xs">{description}</p>
          </motion.div>
        ))}
      </motion.section>

      {/* Öğrenciye Faydalar */}
      <motion.section
        className="mt-32 max-w-6xl mx-auto"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={{ hidden: {}, visible: { transition: { staggerChildren: 0.2 } } }}
      >
        <h2 className="text-3xl md:text-4xl font-bold text-center text-purple-900 mb-12">Öğrenciler İçin Faydalar</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {[
            {
              icon: <Target size={44} className="text-purple-600 mx-auto" />,
              title: "Hedef Odaklı İçerik",
              description: "Alanına uygun fırsatlarla zaman kaybetmeden hedefe ulaş.",
            },
            {
              icon: <Star size={44} className="text-purple-600 mx-auto" />,
              title: "Rekabet Avantajı",
              description: "Özgeçmişini güçlendirecek fırsatlara herkesten önce ulaş.",
            },
            {
              icon: <BarChart2 size={44} className="text-purple-600 mx-auto" />,
              title: "Gelişim Takibi",
              description: "İlerleyişini takip et, eksiklerini zamanında fark et.",
            },
          ].map(({ icon, title, description }, i) => (
            <motion.div
              key={i}
              className="bg-white rounded-3xl shadow-md p-8 text-center"
              variants={{ hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } }}
            >
              {icon}
              <h3 className="mt-4 text-xl font-semibold text-purple-800">{title}</h3>
              <p className="mt-2 text-gray-600">{description}</p>
            </motion.div>
          ))}
        </div>
      </motion.section>

      {/* İşletmelere Faydalar */}
      <motion.section
        className="mt-32 max-w-6xl mx-auto"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={{ hidden: {}, visible: { transition: { staggerChildren: 0.2 } } }}
      >
        <h2 className="text-3xl md:text-4xl font-bold text-center text-purple-900 mb-12">İşletmeler İçin Faydalar</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {[
            {
              icon: <Users size={44} className="text-purple-600 mx-auto" />,
              title: "Genç Yeteneklere Erişim",
              description: "Motivasyonu yüksek, alanına ilgili öğrencilere ulaşın.",
            },
            {
              icon: <HeartHandshake size={44} className="text-purple-600 mx-auto" />,
              title: "İşbirliği Olanakları",
              description: "Projelerinizde üniversite öğrencileriyle birlikte çalışın.",
            },
            {
              icon: <BarChart2 size={44} className="text-purple-600 mx-auto" />,
              title: "Veriye Dayalı Seçim",
              description: "Profil verileriyle doğru kişiyi kolayca belirleyin.",
            },
          ].map(({ icon, title, description }, i) => (
            <motion.div
              key={i}
              className="bg-white rounded-3xl shadow-md p-8 text-center"
              variants={{ hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } }}
            >
              {icon}
              <h3 className="mt-4 text-xl font-semibold text-purple-800">{title}</h3>
              <p className="mt-2 text-gray-600">{description}</p>
            </motion.div>
          ))}
        </div>
      </motion.section>

      {/* Nasıl Çalışır */}
      <div className="mt-32">
        <HowItWorks />
      </div>
    </div>
  );
}