// src/pages/HowItWorks.jsx

import { Link } from "react-router-dom";
import { 
  UserPlus, 
  BookOpen, 
  Briefcase, 
  Trophy, 
  Gift,
  CheckCircle,
  ArrowRight
} from "lucide-react";

export default function HowItWorks() {
  const steps = [
    {
      icon: UserPlus,
      title: "1. Üye Ol",
      description: "Hızlı ve ücretsiz kayıt ol, profilini tamamla",
      color: "bg-blue-100 text-blue-600"
    },
    {
      icon: BookOpen,
      title: "2. Kurs Al",
      description: "İlgi alanına göre kursları keşfet ve kaydol",
      color: "bg-green-100 text-green-600"
    },
    {
      icon: Briefcase,
      title: "3. Staj/İş Bul",
      description: "Sana uygun staj ve iş ilanlarına başvur",
      color: "bg-purple-100 text-purple-600"
    },
    {
      icon: Trophy,
      title: "4. Puan Kazan",
      description: "Her aktivitende puan kazan, sıralamada yüksel",
      color: "bg-yellow-100 text-yellow-600"
    },
    {
      icon: Gift,
      title: "5. Ödül Kazan",
      description: "Puanlarını harika ödüllerle değiştir",
      color: "bg-red-100 text-red-600"
    }
  ];

  return (
    <div className="max-w-6xl mx-auto py-12">
      {/* Hero Section */}
      <div className="text-center mb-16">
        <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
          Nasıl Çalışır?
        </h1>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
          Kariyerine yön verirken puan kazan, ödüller kazan! 
          Platform kullanımı çok basit, hemen başla.
        </p>
      </div>

      {/* Steps */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-16">
        {steps.map((step, index) => {
          const Icon = step.icon;
          return (
            <div key={index} className="text-center">
              <div className={`w-20 h-20 mx-auto rounded-full ${step.color} flex items-center justify-center mb-4`}>
                <Icon className="w-10 h-10" />
              </div>
              <h3 className="font-semibold text-lg mb-2">{step.title}</h3>
              <p className="text-gray-600 text-sm">{step.description}</p>
              {index < steps.length - 1 && (
                <ArrowRight className="hidden lg:block w-6 h-6 text-gray-400 mx-auto mt-4 -mr-4 transform translate-x-full -translate-y-16" />
              )}
            </div>
          );
        })}
      </div>

      {/* Detailed Steps */}
      <div className="space-y-12">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Detaylı Adımlar</h2>
          
          <div className="space-y-8">
            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="font-bold text-purple-600">1</span>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Üyelik ve Profil</h3>
                <p className="text-gray-600 mb-3">
                  E-posta adresinle hızlıca üye ol. Profilini doldurarak hangi bölümde 
                  okuduğunu, ilgi alanlarını belirt. Profil tamamlama bonusu olarak 
                  <span className="font-semibold text-purple-600"> +20 puan</span> kazan!
                </p>
                <ul className="list-disc list-inside text-gray-600 space-y-1">
                  <li>Ad-soyad ve bölüm bilgilerini ekle</li>
                  <li>İlgi alanlarını seç</li>
                  <li>Kariyer hedeflerini belirt</li>
                </ul>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="font-bold text-purple-600">2</span>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Eğitimler ve Kurslar</h3>
                <p className="text-gray-600 mb-3">
                  Bölümüne ve ilgi alanlarına uygun kursları keşfet. Her kurs kaydında 
                  <span className="font-semibold text-purple-600"> +10 puan</span>, 
                  tamamladığında <span className="font-semibold text-purple-600"> +50 puan</span> kazan!
                </p>
                <ul className="list-disc list-inside text-gray-600 space-y-1">
                  <li>Video içerikli eğitimler</li>
                  <li>Pratik projeler ve ödevler</li>
                  <li>Sertifika kazanma fırsatı</li>
                </ul>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="font-bold text-purple-600">3</span>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Staj ve İş Başvuruları</h3>
                <p className="text-gray-600 mb-3">
                  Sektördeki önde gelen firmalardan gelen staj ve iş ilanlarına başvur. 
                  Her başvuruda <span className="font-semibold text-purple-600"> +5 puan</span>, 
                  kabul edildiğinde ekstra puanlar kazan!
                </p>
                <ul className="list-disc list-inside text-gray-600 space-y-1">
                  <li>Bölümüne özel ilanlar</li>
                  <li>Uzaktan ve yerinde çalışma seçenekleri</li>
                  <li>İşveren değerlendirmeleriyle ekstra puan</li>
                </ul>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="font-bold text-purple-600">4</span>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Puan Sistemi</h3>
                <p className="text-gray-600 mb-3">
                  Her gün giriş yap, aktivitelerini tamamla ve puan kazan. Bölüm ve 
                  genel sıralamada üst sıralara çık!
                </p>
                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-sm text-gray-600">Günlük Giriş</p>
                    <p className="font-semibold text-purple-600">+2 puan</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-sm text-gray-600">Haftalık Seri</p>
                    <p className="font-semibold text-purple-600">+15 puan</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-sm text-gray-600">Staj Tamamlama</p>
                    <p className="font-semibold text-purple-600">+100 puan</p>
                  </div>
                  <div className="bg-gray-50 p-3 rounded-lg">
                    <p className="text-sm text-gray-600">İlk 10'a Girme</p>
                    <p className="font-semibold text-purple-600">+50 puan</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="font-bold text-purple-600">5</span>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Ödüller</h3>
                <p className="text-gray-600 mb-3">
                  Biriktirdiğin puanları harika ödüllerle değiştir! Teknoloji ürünleri, 
                  eğitim paketleri, yurt dışı gezileri ve daha fazlası seni bekliyor.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <div className="border border-gray-200 rounded-lg p-4">
                    <h4 className="font-semibold mb-2">🎓 Eğitim Paketleri</h4>
                    <p className="text-sm text-gray-600">1000 puandan başlayan ödüller</p>
                  </div>
                  <div className="border border-gray-200 rounded-lg p-4">
                    <h4 className="font-semibold mb-2">💻 Teknoloji Ürünleri</h4>
                    <p className="text-sm text-gray-600">3000 puandan başlayan ödüller</p>
                  </div>
                  <div className="border border-gray-200 rounded-lg p-4">
                    <h4 className="font-semibold mb-2">✈️ Yurt Dışı Gezileri</h4>
                    <p className="text-sm text-gray-600">5000 puandan başlayan ödüller</p>
                  </div>
                  <div className="border border-gray-200 rounded-lg p-4">
                    <h4 className="font-semibold mb-2">🏢 Staj Garantisi</h4>
                    <p className="text-sm text-gray-600">1500 puandan başlayan ödüller</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-xl p-8 text-white text-center">
          <h2 className="text-3xl font-bold mb-4">Hazır mısın?</h2>
          <p className="text-xl mb-6 text-purple-100">
            Hemen üye ol, kariyerine yön vermeye başla!
          </p>
          <Link 
            to="/register" 
            className="inline-flex items-center bg-white text-purple-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
          >
            Ücretsiz Kayıt Ol
            <ArrowRight className="w-5 h-5 ml-2" />
          </Link>
        </div>
      </div>
    </div>
  );
}