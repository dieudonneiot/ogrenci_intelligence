import { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { supabase } from "../utils/supabaseClient";
import { addPoints, POINT_VALUES } from "../services/pointsService";
import { trackInternshipView } from "../services/reportService";
import toast from "react-hot-toast";
import { 
  Briefcase,
  MapPin,
  Clock,
  Calendar,
  Users,
  Building,
  ArrowLeft,
  Heart,
  Share2,
  CheckCircle,
  AlertCircle,
  Send,
  Star,
  Award,
  BookOpen,
  Coffee
} from "lucide-react";

// İlk başvuru kontrol fonksiyonu
const checkFirstApplication = async (userId) => {
  const { count } = await supabase
    .from("internship_applications")
    .select("id", { count: "exact", head: true })
    .eq("user_id", userId);
  return (count === 0);
};

export default function InternshipDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [internship, setInternship] = useState(null);
  const [loading, setLoading] = useState(true);
  const [applying, setApplying] = useState(false);
  const [hasApplied, setHasApplied] = useState(false);
  const [isFavorited, setIsFavorited] = useState(false);
  const [motivation, setMotivation] = useState("");
  const [showApplicationForm, setShowApplicationForm] = useState(false);

  useEffect(() => {
    fetchInternshipDetails();
    // eslint-disable-next-line
  }, [id, user]);

  // Yeni useEffect ekle
  useEffect(() => {
    if (id && internship) {
      trackInternshipView(id, user?.id);
    }
  }, [id, internship, user]);

  const fetchInternshipDetails = async () => {
    setLoading(true);
    
    try {
      // Staj detaylarını getir
      const { data: internshipData, error: internshipError } = await supabase
        .from("internships")
        .select("*")
        .eq("id", id)
        .single();

      if (internshipError) {
        console.error("Staj hatası:", internshipError);
        throw internshipError;
      }

      if (!internshipData) {
        toast.error("Staj bulunamadı");
        navigate("/internships");
        return;
      }

      setInternship(internshipData);

      // Kullanıcı başvurmuş mu kontrol et
      if (user) {
        const { data: applicationData } = await supabase
          .from("internship_applications")
          .select("id, status")
          .eq("internship_id", id)
          .eq("user_id", user.id)
          .single();

        setHasApplied(!!applicationData);

        // Favori mi kontrol et
        const { data: favoriteData } = await supabase
          .from("favorites")
          .select("id")
          .eq("internship_id", id)
          .eq("user_id", user.id)
          .single();

        setIsFavorited(!!favoriteData);
      }
    } catch (error) {
      console.error("Staj detayları alınamadı:", error);
      toast.error("Staj bulunamadı");
      navigate("/internships");
    }
    
    setLoading(false);
  };

  const handleApply = async () => {
    if (!user) {
      toast.error("Başvuru yapmak için giriş yapmalısınız");
      navigate("/login");
      return;
    }

    setApplying(true);
    
    try {
      const { error } = await supabase
        .from("internship_applications")
        .insert({
          internship_id: id,
          user_id: user.id,
          motivation_letter: motivation,
          status: "pending",
          applied_at: new Date().toISOString()
        });

      if (error) throw error;
      
      setHasApplied(true);
      setShowApplicationForm(false);
      toast.success("Başvurunuz başarıyla gönderildi!");

      // İlk başvuru kontrolü ve puan
      const isFirstApplication = await checkFirstApplication(user.id);
      if (isFirstApplication) {
        await addPoints(
          user.id,
          'platform',
          'first_application',
          POINT_VALUES.FIRST_APPLICATION,
          'İlk başvurunuzu yaptınız!'
        );
      }

      // Normal başvuru puanı
      await addPoints(
        user.id,
        'internship',
        'application',
        POINT_VALUES.INTERNSHIP_APPLICATION,
        `${internship.title} stajına başvuru`
      );
    } catch (error) {
      toast.error("Başvuru sırasında hata oluştu");
    }
    
    setApplying(false);
  };

  const handleFavorite = async () => {
    if (!user) {
      toast.error("Favorilere eklemek için giriş yapmalısınız");
      return;
    }

    try {
      if (isFavorited) {
        const { error } = await supabase
          .from("favorites")
          .delete()
          .eq("internship_id", id)
          .eq("user_id", user.id);

        if (error) throw error;
        setIsFavorited(false);
        toast.success("Favorilerden kaldırıldı");
      } else {
        const { error } = await supabase
          .from("favorites")
          .insert({
            internship_id: id,
            user_id: user.id,
            type: "internship"
          });

        if (error) throw error;
        setIsFavorited(true);
        toast.success("Favorilere eklendi");
      }
    } catch (error) {
      toast.error("İşlem başarısız");
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (!internship) return null;

  // Mock data
  const benefits = [
    { icon: Award, title: "Sertifika", desc: "Başarılı tamamlama sertifikası" },
    { icon: BookOpen, title: "Eğitim", desc: "Mentör desteği ve eğitimler" },
    { icon: Coffee, title: "Sosyal İmkanlar", desc: "Yemek ve ulaşım desteği" },
    { icon: Star, title: "Puan Kazanımı", desc: "+100 platform puanı" }
  ];

  const requirements = [
    "Bilgisayar Mühendisliği veya ilgili bölümlerde 3. veya 4. sınıf öğrencisi olmak",
    "Minimum 3 ay boyunca haftada en az 3 gün staj yapabilecek olmak",
    "React.js, Node.js veya benzeri teknolojilerde temel bilgiye sahip olmak",
    "İngilizce okuma ve yazma becerisine sahip olmak",
    "Takım çalışmasına uyumlu ve öğrenmeye açık olmak"
  ];

  return (
    <div className="max-w-7xl mx-auto py-8">
      {/* Geri Dön */}
      <Link 
        to="/internships" 
        className="inline-flex items-center text-gray-600 hover:text-gray-900 mb-6"
      >
        <ArrowLeft className="w-5 h-5 mr-2" />
        Stajlara Dön
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sol Kolon - Staj Detayları */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
            {/* Başlık ve Şirket Bilgisi */}
            <div className="flex items-start justify-between mb-6">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h1 className="text-3xl font-bold text-gray-900">
                    {internship.title}
                  </h1>
                  <span className="px-3 py-1 bg-green-100 text-green-700 text-sm font-medium rounded-full">
                    Aktif
                  </span>
                </div>
                <div className="flex items-center space-x-4 text-gray-600">
                  <div className="flex items-center">
                    <Building className="w-5 h-5 mr-2" />
                    <span className="font-medium">{internship.company || "Tech Startup"}</span>
                  </div>
                  <div className="flex items-center">
                    <MapPin className="w-5 h-5 mr-2" />
                    <span>{internship.location || "İstanbul, Türkiye"}</span>
                  </div>
                </div>
              </div>
              
              <div className="flex space-x-2">
                <button
                  onClick={handleFavorite}
                  className={`p-2 rounded-lg transition-colors ${
                    isFavorited 
                      ? "bg-red-100 text-red-600 hover:bg-red-200" 
                      : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                  }`}
                >
                  <Heart className={`w-5 h-5 ${isFavorited ? "fill-current" : ""}`} />
                </button>
                <button className="p-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200">
                  <Share2 className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Staj Detay Kartları */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              <div className="bg-purple-50 rounded-lg p-4 text-center">
                <Clock className="w-6 h-6 text-purple-600 mx-auto mb-2" />
                <p className="text-sm text-gray-600 mb-1">Süre</p>
                <p className="font-semibold text-yellow-700">+100 Puan</p>
              </div>
            </div>

            {/* Staj Açıklaması */}
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Staj Programı Hakkında</h2>
              <p className="text-gray-600 leading-relaxed">
                {internship.description || "Bu staj programı, öğrencilere gerçek iş ortamında deneyim kazandırmayı hedeflemektedir. Katılımcılar, deneyimli mentörler eşliğinde gerçek projelerde çalışma fırsatı bulacak ve sektörün dinamiklerini yakından tanıyacaklardır. Program süresince teknik becerilerini geliştirmenin yanı sıra, takım çalışması ve proje yönetimi konularında da deneyim kazanacaklardır."}
              </p>
            </div>

            {/* Kazanımlar */}
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Staj Kazanımları</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {benefits.map((benefit, index) => {
                  const Icon = benefit.icon;
                  return (
                    <div key={index} className="flex items-start space-x-3 p-4 bg-gray-50 rounded-lg">
                      <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center flex-shrink-0">
                        <Icon className="w-5 h-5 text-purple-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">{benefit.title}</h4>
                        <p className="text-sm text-gray-600 mt-1">{benefit.desc}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Aranan Nitelikler */}
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Aranan Nitelikler</h2>
              <ul className="space-y-2">
                {requirements.map((req, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-600">{req}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Staj Süreci */}
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Staj Süreci</h2>
              <div className="space-y-4">
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="font-semibold text-purple-600">1</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Başvuru ve Değerlendirme</h4>
                    <p className="text-sm text-gray-600 mt-1">Online başvuru ve mülakat süreci</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="font-semibold text-purple-600">2</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Oryantasyon ve Eğitim</h4>
                    <p className="text-sm text-gray-600 mt-1">İlk hafta temel eğitimler ve oryantasyon</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="font-semibold text-purple-600">3</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Proje Çalışmaları</h4>
                    <p className="text-sm text-gray-600 mt-1">Gerçek projelerde aktif rol alma</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="font-semibold text-purple-600">4</span>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Değerlendirme ve Sertifika</h4>
                    <p className="text-sm text-gray-600 mt-1">Performans değerlendirmesi ve sertifika töreni</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Başvuru Formu */}
            {showApplicationForm && !hasApplied && (
              <div className="mt-8 p-6 bg-purple-50 rounded-lg border border-purple-200">
                <h3 className="text-lg font-semibold text-purple-900 mb-4">Staj Başvuru Formu</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Motivasyon Mektubu
                    </label>
                    <textarea
                      value={motivation}
                      onChange={(e) => setMotivation(e.target.value)}
                      rows={5}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      placeholder="Bu staj programına neden katılmak istiyorsunuz? Kendinizden ve hedeflerinizden bahsedin..."
                      required
                    />
                    <p className="text-xs text-gray-500 mt-1">Minimum 100 karakter</p>
                  </div>
                  
                  <div className="flex space-x-3">
                    <button
                      onClick={handleApply}
                      disabled={applying || motivation.length < 100}
                      className="flex-1 bg-purple-600 text-white py-3 rounded-lg font-medium hover:bg-purple-700 disabled:opacity-50 transition-colors flex items-center justify-center"
                    >
                      {applying ? (
                        "Gönderiliyor..."
                      ) : (
                        <>
                          <Send className="w-5 h-5 mr-2" />
                          Başvuruyu Gönder
                        </>
                      )}
                    </button>
                    <button
                      onClick={() => setShowApplicationForm(false)}
                      className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                    >
                      İptal
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Sağ Kolon - Başvuru ve Şirket Bilgisi */}
        <div className="lg:col-span-1">
          {/* Başvuru Kartı */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6 sticky top-24">
            {hasApplied ? (
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Başvurunuz Alındı!</h3>
                <p className="text-gray-600 text-sm mb-4">
                  Staj başvurunuz değerlendirme aşamasında. En kısa sürede size dönüş yapılacaktır.
                </p>
                <Link
                  to="/applications"
                  className="text-purple-600 hover:text-purple-700 font-medium text-sm"
                >
                  Başvurularımı Görüntüle →
                </Link>
              </div>
            ) : (
              <>
                <div className="text-center mb-6">
                  <div className="text-3xl font-bold text-purple-600 mb-1">+100 Puan</div>
                  <p className="text-sm text-gray-600">Stajı tamamladığınızda kazanacaksınız</p>
                </div>
                
                <button
                  onClick={() => setShowApplicationForm(true)}
                  className="w-full bg-purple-600 text-white py-3 rounded-lg font-medium hover:bg-purple-700 transition-colors flex items-center justify-center mb-4"
                >
                  <Briefcase className="w-5 h-5 mr-2" />
                  Staja Başvur
                </button>
                
                <div className="p-4 bg-amber-50 rounded-lg border border-amber-200">
                  <div className="flex items-start space-x-2">
                    <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-sm text-amber-800 font-medium">Sınırlı Kontenjan!</p>
                      <p className="text-xs text-amber-700 mt-1">
                        5 kontenjanın 3'ü dolu
                      </p>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Şirket Bilgileri */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">İşletme Hakkında</h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-center p-8 bg-gradient-to-br from-purple-100 to-indigo-100 rounded-lg">
                <Building className="w-16 h-16 text-purple-600" />
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-900">{internship.company || "Tech Startup"}</h4>
                <p className="text-sm text-gray-600 mt-1">Yazılım ve Teknoloji</p>
                <div className="flex items-center mt-2">
                  <Star className="w-4 h-4 text-yellow-500 fill-current" />
                  <Star className="w-4 h-4 text-yellow-500 fill-current" />
                  <Star className="w-4 h-4 text-yellow-500 fill-current" />
                  <Star className="w-4 h-4 text-yellow-500 fill-current" />
                  <Star className="w-4 h-4 text-gray-300" />
                  <span className="text-sm text-gray-600 ml-2">4.2 (18 değerlendirme)</span>
                </div>
              </div>
              
              <p className="text-sm text-gray-600 leading-relaxed">
                Tech Startup, 2018 yılında kurulmuş, hızla büyüyen bir teknoloji şirketidir. 
                SaaS çözümleri ve mobil uygulamalar geliştirmektedir.
              </p>
              
              <div className="pt-4 border-t">
                <h4 className="font-medium text-gray-900 mb-2">Stajyer Yorumları</h4>
                <div className="space-y-2">
                  <p className="text-sm text-gray-600 italic">
                    "Harika bir öğrenme ortamı. Mentörler çok yardımcı ve gerçek projeler üzerinde çalışmak çok değerli bir deneyim."
                  </p>
                  <p className="text-xs text-gray-500">- Ahmet K., Yazılım Stajyeri (2023)</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}