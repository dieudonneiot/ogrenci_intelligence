import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { supabase } from "../utils/supabaseClient";
import { 
  Briefcase, 
  Calendar,
  MapPin,
  Building,
  Clock,
  Users,
  Search,
  Filter,
  Heart,
  ChevronRight,
  DollarSign,
  Target
} from "lucide-react";
import toast from "react-hot-toast";

export default function Internships() {
  const { user } = useAuth();
  const [internships, setInternships] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [loading, setLoading] = useState(true);
  const [department, setDepartment] = useState("");
  const [search, setSearch] = useState("");
  const [appliedInternships, setAppliedInternships] = useState(new Set());
  const [favoriteInternships, setFavoriteInternships] = useState(new Set());
  const [selectedLocation, setSelectedLocation] = useState("all");
  const [selectedDuration, setSelectedDuration] = useState("all");

  const locations = [
    { value: "all", label: "Tüm Lokasyonlar" },
    { value: "istanbul", label: "İstanbul" },
    { value: "ankara", label: "Ankara" },
    { value: "izmir", label: "İzmir" },
    { value: "remote", label: "Uzaktan" }
  ];

  const durations = [
    { value: "all", label: "Tüm Süreler" },
    { value: "1-3", label: "1-3 Ay" },
    { value: "3-6", label: "3-6 Ay" },
    { value: "6+", label: "6+ Ay" }
  ];

  useEffect(() => {
    fetchInternships();
  }, [user]);

  const fetchInternships = async () => {
    if (!user) {
      toast.error("Lütfen giriş yapın.");
      setLoading(false);
      return;
    }

    setLoading(true);

    try {
      // Kullanıcı profili
      const { data: profile } = await supabase
        .from("profiles")
        .select("department")
        .eq("id", user.id)
        .single();

      if (!profile?.department) {
        toast.error("Bölüm bilgisi bulunamadı. Lütfen profilinizi güncelleyin.");
        setLoading(false);
        return;
      }

      setDepartment(profile.department);

      // Stajları getir
      const { data: internshipsData, error } = await supabase
        .from("internships")
        .select("*")
        .eq("department", profile.department);

      if (error) {
        console.error("Stajlar yüklenirken hata:", error);
        throw error;
      }

      console.log("Gelen stajlar:", internshipsData);

      // Eğer staj yoksa uyarı ver
      if (!internshipsData || internshipsData.length === 0) {
        toast.warning("Bölümünüze ait staj ilanı bulunamadı.");
        setInternships([]);
        setFiltered([]);
        setLoading(false);
        return;
      }

      // Başvurulan stajlar
      const { data: applicationsData } = await supabase
        .from("internship_applications")
        .select("internship_id")
        .eq("user_id", user.id);

      if (applicationsData) {
        setAppliedInternships(new Set(applicationsData.map(a => a.internship_id)));
      }

      // Favori stajlar
      const { data: favoriteData } = await supabase
        .from("favorites")
        .select("internship_id")
        .eq("user_id", user.id)
        .eq("type", "internship");

      if (favoriteData) {
        setFavoriteInternships(new Set(favoriteData.map(f => f.internship_id)));
      }

      // Başvuru sayılarını hesapla
      const internshipsWithStats = internshipsData.map(internship => ({
        ...internship,
        application_count: 0,
        user_application_status: null
      }));

      setInternships(internshipsWithStats);
      setFiltered(internshipsWithStats);
    } catch (error) {
      console.error("Stajlar yüklenirken hata:", error);
      toast.error("Stajlar yüklenemedi.");
    }

    setLoading(false);
  };

  useEffect(() => {
    let filteredData = internships;

    // Lokasyon filtresi
    if (selectedLocation !== "all") {
      filteredData = filteredData.filter(internship => {
        if (selectedLocation === "remote") {
          return internship.is_remote;
        }
        return internship.location?.toLowerCase().includes(selectedLocation);
      });
    }

    // Süre filtresi
    if (selectedDuration !== "all") {
      filteredData = filteredData.filter(internship => {
        const duration = internship.duration_months || 3;
        switch (selectedDuration) {
          case "1-3":
            return duration >= 1 && duration <= 3;
          case "3-6":
            return duration > 3 && duration <= 6;
          case "6+":
            return duration > 6;
          default:
            return true;
        }
      });
    }

    // Arama filtresi
    filteredData = filteredData.filter(internship =>
      internship.title.toLowerCase().includes(search.toLowerCase()) ||
      internship.company_name?.toLowerCase().includes(search.toLowerCase()) ||
      internship.description?.toLowerCase().includes(search.toLowerCase())
    );

    setFiltered(filteredData);
  }, [search, selectedLocation, selectedDuration, internships]);

  const toggleFavorite = async (internshipId) => {
    try {
      if (favoriteInternships.has(internshipId)) {
        await supabase
          .from("favorites")
          .delete()
          .eq("internship_id", internshipId)
          .eq("user_id", user.id);
        
        setFavoriteInternships(prev => {
          const newSet = new Set(prev);
          newSet.delete(internshipId);
          return newSet;
        });
        toast.success("Favorilerden kaldırıldı");
      } else {
        await supabase
          .from("favorites")
          .insert({
            user_id: user.id,
            internship_id: internshipId,
            type: "internship"
          });
        
        setFavoriteInternships(prev => new Set([...prev, internshipId]));
        toast.success("Favorilere eklendi");
      }
    } catch (error) {
      toast.error("İşlem başarısız");
    }
  };

  const formatDate = (dateStr) => {
    if (!dateStr) return "Belirtilmemiş";
    return new Date(dateStr).toLocaleDateString("tr-TR", {
      day: "numeric",
      month: "long",
      year: "numeric"
    });
  };

  const getApplicationBadge = (status) => {
    const badges = {
      pending: { color: "bg-yellow-100 text-yellow-800", text: "Beklemede" },
      accepted: { color: "bg-green-100 text-green-800", text: "Kabul Edildi" },
      rejected: { color: "bg-red-100 text-red-800", text: "Reddedildi" }
    };
    const badge = badges[status];
    if (!badge) return null;

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${badge.color}`}>
        {badge.text}
      </span>
    );
  };

  return (
    <div className="max-w-7xl mx-auto py-8">
      {/* Başlık ve Arama */}
      <div className="text-center mb-10">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          {department} Staj İlanları
        </h1>
        <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
          Sektörün önde gelen şirketlerinde staj yaparak deneyim kazanın ve kariyerinize güçlü bir başlangıç yapın.
        </p>
        
        {/* Arama ve Filtreler */}
        <div className="flex flex-col md:flex-row gap-4 max-w-4xl mx-auto">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Staj veya şirket ara..."
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
          </div>
          
          <select
            value={selectedLocation}
            onChange={(e) => setSelectedLocation(e.target.value)}
            className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          >
            {locations.map(loc => (
              <option key={loc.value} value={loc.value}>{loc.label}</option>
            ))}
          </select>
          
          <select
            value={selectedDuration}
            onChange={(e) => setSelectedDuration(e.target.value)}
            className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          >
            {durations.map(dur => (
              <option key={dur.value} value={dur.value}>{dur.label}</option>
            ))}
          </select>
        </div>
      </div>

      {/* İstatistikler */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Aktif İlanlar</p>
              <p className="text-2xl font-bold text-gray-900">{internships.length}</p>
            </div>
            <Briefcase className="w-8 h-8 text-purple-600" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Başvurulan</p>
              <p className="text-2xl font-bold text-blue-600">{appliedInternships.size}</p>
            </div>
            <Target className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Ortalama Süre</p>
              <p className="text-2xl font-bold text-gray-900">3-6 Ay</p>
            </div>
            <Clock className="w-8 h-8 text-gray-600" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Kazanılacak Puan</p>
              <p className="text-2xl font-bold text-yellow-600">+100</p>
            </div>
            <Users className="w-8 h-8 text-yellow-600" />
          </div>
        </div>
      </div>

      {/* Staj Listesi */}
      {loading ? (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12">
          <Briefcase className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">Aradığınız kriterlere uygun staj ilanı bulunamadı.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filtered.map((internship) => {
            const hasApplied = appliedInternships.has(internship.id);
            const isFavorite = favoriteInternships.has(internship.id);
            
            return (
              <div
                key={internship.id}
                className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold text-gray-900">
                        {internship.title}
                      </h3>
                      {internship.user_application_status && (
                        getApplicationBadge(internship.user_application_status)
                      )}
                    </div>
                    <div className="flex items-center text-sm text-gray-600 mb-3">
                      <Building className="w-4 h-4 mr-2" />
                      <span className="font-medium">{internship.company_name}</span>
                    </div>
                  </div>
                  
                  {/* Favori Butonu */}
                  <button
                    onClick={() => toggleFavorite(internship.id)}
                    className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <Heart 
                      className={`w-5 h-5 ${
                        isFavorite ? "fill-red-500 text-red-500" : "text-gray-400"
                      }`} 
                    />
                  </button>
                </div>

                {/* Açıklama */}
                <p className="text-sm text-gray-600 line-clamp-2 mb-4">
                  {internship.description}
                </p>

                {/* Detaylar */}
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="flex items-center text-sm text-gray-500">
                    <MapPin className="w-4 h-4 mr-1" />
                    <span>{internship.location || "Belirtilmemiş"}</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock className="w-4 h-4 mr-1" />
                    <span>{internship.duration_months || 3} ay</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Calendar className="w-4 h-4 mr-1" />
                    <span>Başlangıç: {formatDate(internship.start_date)}</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Users className="w-4 h-4 mr-1" />
                    <span>{internship.quota || 1} kontenjan</span>
                  </div>
                </div>

                {/* Başvuru İstatistikleri */}
                {internship.application_count > 0 && (
                  <p className="text-xs text-gray-500 mb-4">
                    {internship.application_count} kişi başvurdu
                  </p>
                )}

                {/* Aksiyon Butonu */}
                <Link
                  to={`/internships/${internship.id}`}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: '100%',
                    padding: '8px 16px',
                    borderRadius: '8px',
                    fontWeight: '500',
                    transition: 'all 0.2s',
                    textDecoration: 'none',
                    backgroundColor: hasApplied ? '#f3f4f6' : '#7c3aed',
                    color: hasApplied ? '#374151' : '#ffffff',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = hasApplied ? '#e5e7eb' : '#6d28d9';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = hasApplied ? '#f3f4f6' : '#7c3aed';
                  }}
                >
                  {hasApplied ? "Başvuru Detayları" : "Detayları Gör"}
                  <ChevronRight className="w-4 h-4 ml-1" style={{ color: 'inherit' }} />
                </Link>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}