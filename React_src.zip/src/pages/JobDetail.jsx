import { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { supabase } from "../utils/supabaseClient";
import { addPoints, POINT_VALUES } from "../services/pointsService";
import { trackJobView } from "../services/reportService";
import toast from "react-hot-toast";
import { 
  Briefcase,
  MapPin,
  Clock,
  DollarSign,
  Calendar,
  Users,
  Building,
  ArrowLeft,
  Heart,
  Share2,
  CheckCircle,
  AlertCircle,
  Send,
  FileText,
  Globe,
  GraduationCap,
  XCircle
} from "lucide-react";

// İlk başvuru kontrol fonksiyonu
const checkFirstApplication = async (userId) => {
  const { count } = await supabase
    .from("job_applications")
    .select("id", { count: "exact", head: true })
    .eq("user_id", userId);
  return (count === 0);
};

export default function JobDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [applying, setApplying] = useState(false);
  const [hasApplied, setHasApplied] = useState(false);
  const [isFavorited, setIsFavorited] = useState(false);
  const [coverLetter, setCoverLetter] = useState("");
  const [showApplicationForm, setShowApplicationForm] = useState(false);
  const [userProfile, setUserProfile] = useState(null);

  useEffect(() => {
    fetchJobDetails();
    if (user) {
      fetchUserProfile();
    }
    // eslint-disable-next-line
  }, [id, user]);

  // Görüntüleme takibi için yeni useEffect ekleyin
  useEffect(() => {
    if (id && job) {
      // İlan yüklendikten sonra görüntülemeyi kaydet
      trackJobView(id, user?.id);
    }
  }, [id, job, user]);

  const fetchUserProfile = async () => {
    try {
      const { data, error } = await supabase
        .from("profiles")
        .select("year, department")
        .eq("id", user.id)
        .single();

      if (error) throw error;
      setUserProfile(data);
    } catch (error) {
      console.error("Profil bilgileri alınamadı:", error);
    }
  };

  const fetchJobDetails = async () => {
    setLoading(true);
    
    try {
      // İş ilanı detaylarını getir
      const { data: jobData, error: jobError } = await supabase
        .from("jobs")
        .select("*")
        .eq("id", id)
        .single();

      if (jobError) {
        console.error("İş ilanı hatası:", jobError);
        throw jobError;
      }

      if (!jobData) {
        toast.error("İş ilanı bulunamadı");
        navigate("/jobs");
        return;
      }

      setJob(jobData);

      // Kullanıcı başvurmuş mu kontrol et
      if (user) {
        const { data: applicationData } = await supabase
          .from("job_applications")
          .select("id, status")
          .eq("job_id", id)
          .eq("user_id", user.id)
          .single();

        setHasApplied(!!applicationData);

        // Favori mi kontrol et
        const { data: favoriteData } = await supabase
          .from("favorites")
          .select("id")
          .eq("job_id", id)
          .eq("user_id", user.id)
          .single();

        setIsFavorited(!!favoriteData);
      }
    } catch (error) {
      console.error("İş ilanı detayları alınamadı:", error);
      toast.error("İlan bulunamadı");
      navigate("/jobs");
    }
    
    setLoading(false);
  };

  // Başvuru yapabilir mi kontrolü
  const canApply = () => {
    if (!userProfile) return false;
    
    // Eğer iş tipi "departmental" (full-time) ise sadece 4. sınıf ve üzeri başvurabilir
    if (job.type === "departmental") {
      return userProfile.year >= 4;
    }
    
    // Part-time işlere herkes başvurabilir
    return true;
  };

  // Sınıf gereksinimleri kontrolü
  const getYearRequirement = () => {
    if (!job) return null;
    
    if (job.type === "departmental") {
      return "4. sınıf ve üzeri";
    } else if (job.min_year && job.max_year) {
      return `${job.min_year}. - ${job.max_year}. sınıf`;
    } else if (job.min_year) {
      return `${job.min_year}. sınıf ve üzeri`;
    } else if (job.max_year) {
      return `En fazla ${job.max_year}. sınıf`;
    }
    
    return "Tüm sınıflar";
  };

  const handleApply = async () => {
    if (!user) {
      toast.error("Başvuru yapmak için giriş yapmalısınız");
      navigate("/login");
      return;
    }

    if (!canApply()) {
      toast.error("Bu ilana başvuru yapmak için uygun sınıfta değilsiniz");
      return;
    }

    setApplying(true);
    
    try {
      const { error } = await supabase
        .from("job_applications")
        .insert({
          job_id: id,
          user_id: user.id,
          cover_letter: coverLetter,
          status: "pending",
          applied_at: new Date().toISOString()
        });

      if (error) throw error;
      
      setHasApplied(true);
      setShowApplicationForm(false);
      toast.success("Başvurunuz başarıyla gönderildi!");

      // İlk başvuru kontrolü ve puan
      const isFirstApplication = await checkFirstApplication(user.id);
      if (isFirstApplication) {
        await addPoints(
          user.id,
          'platform',
          'first_application',
          POINT_VALUES.FIRST_APPLICATION,
          'İlk başvurunuzu yaptınız!'
        );
      }

      // Normal başvuru puanı
      await addPoints(
        user.id,
        'job',
        'application',
        POINT_VALUES.JOB_APPLICATION,
        `${job.title} iş ilanına başvuru`
      );
    } catch (error) {
      toast.error("Başvuru sırasında hata oluştu");
    }
    
    setApplying(false);
  };

  const handleFavorite = async () => {
    if (!user) {
      toast.error("Favorilere eklemek için giriş yapmalısınız");
      return;
    }

    try {
      if (isFavorited) {
        const { error } = await supabase
          .from("favorites")
          .delete()
          .eq("job_id", id)
          .eq("user_id", user.id);

        if (error) throw error;
        setIsFavorited(false);
        toast.success("Favorilerden kaldırıldı");
      } else {
        const { error } = await supabase
          .from("favorites")
          .insert({
            job_id: id,
            user_id: user.id,
            type: "job"
          });

        if (error) throw error;
        setIsFavorited(true);
        toast.success("Favorilere eklendi");
      }
    } catch (error) {
      toast.error("İşlem başarısız");
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  if (!job) return null;

  // Mock data - gerçek uygulamada API'den gelecek
  const jobRequirements = [
    `Üniversitelerin ilgili bölümlerinde ${getYearRequirement()} öğrencisi olmak`,
    "Haftada minimum 3 gün çalışabilecek olmak",
    "React.js ve JavaScript konularında temel bilgiye sahip olmak",
    "Takım çalışmasına yatkın olmak",
    "Öğrenmeye açık ve istekli olmak"
  ];

  const jobResponsibilities = [
    "Web uygulamaları geliştirme süreçlerine destek vermek",
    "Kod kalitesi ve test süreçlerine katkıda bulunmak",
    "Teknik dokümantasyon hazırlamak",
    "Takım toplantılarına katılmak ve fikir üretmek",
    "Yeni teknolojileri araştırmak ve uygulamak"
  ];

  return (
    <div className="max-w-7xl mx-auto py-8">
      {/* Geri Dön */}
      <Link 
        to="/jobs" 
        className="inline-flex items-center text-gray-600 hover:text-gray-900 mb-6"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        İş İlanlarına Dön
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sol Kolon - İlan Detayları */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
            {/* Başlık ve Şirket Bilgisi */}
            <div className="flex items-start justify-between mb-6">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">
                  {job.title}
                </h1>
                <div className="flex items-center space-x-4 text-gray-600">
                  <div className="flex items-center">
                    <Building className="w-5 h-5 mr-2" />
                    <span className="font-medium">{job.company || "ABC Teknoloji"}</span>
                  </div>
                  <div className="flex items-center">
                    <MapPin className="w-5 h-5 mr-2" />
                    <span>{job.location || "İstanbul, Türkiye"}</span>
                  </div>
                </div>
              </div>
              
              <div className="flex space-x-2">
                <button
                  onClick={handleFavorite}
                  className={`p-2 rounded-lg transition-colors ${
                    isFavorited 
                      ? "bg-red-100 text-red-600 hover:bg-red-200" 
                      : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                  }`}
                >
                  <Heart className={`w-5 h-5 ${isFavorited ? "fill-current" : ""}`} />
                </button>
                <button className="p-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200">
                  <Share2 className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* İlan Detayları */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8 pb-8 border-b">
              <div>
                <div className="flex items-center text-gray-600 mb-1">
                  <Briefcase className="w-4 h-4 mr-2" />
                  <span className="text-sm">Pozisyon</span>
                </div>
                <p className="font-semibold">{job.type === "departmental" ? "Full-time" : "Part-time"}</p>
              </div>
              <div>
                <div className="flex items-center text-gray-600 mb-1">
                  <GraduationCap className="w-4 h-4 mr-2" />
                  <span className="text-sm">Sınıf Gereksinimi</span>
                </div>
                <p className="font-semibold">{getYearRequirement()}</p>
              </div>
              <div>
                <div className="flex items-center text-gray-600 mb-1">
                  <DollarSign className="w-4 h-4 mr-2" />
                  <span className="text-sm">Maaş</span>
                </div>
                <p className="font-semibold">{job.salary || "Rekabetçi"}</p>
              </div>
              <div>
                <div className="flex items-center text-gray-600 mb-1">
                  <Calendar className="w-4 h-4 mr-2" />
                  <span className="text-sm">Son Başvuru</span>
                </div>
                <p className="font-semibold">{job.deadline ? new Date(job.deadline).toLocaleDateString('tr-TR') : "Belirtilmemiş"}</p>
              </div>
            </div>

            {/* İş Tanımı */}
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">İş Tanımı</h2>
              <p className="text-gray-600 leading-relaxed">
                {job.description || "Dinamik ve yenilikçi ekibimize katılacak, yazılım geliştirme süreçlerimizde aktif rol alacak yetenekli stajyer arkadaşlar arıyoruz. Bu pozisyon, gerçek projelerde çalışma ve sektör deneyimi kazanma fırsatı sunmaktadır."}
              </p>
            </div>

            {/* Gereksinimler */}
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Aranan Nitelikler</h2>
              <ul className="space-y-2">
                {jobRequirements.map((req, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-600">{req}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Sorumluluklar */}
            <div className="mb-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">İş Tanımı ve Sorumluluklar</h2>
              <ul className="space-y-2">
                {jobResponsibilities.map((resp, index) => (
                  <li key={index} className="flex items-start">
                    <div className="w-2 h-2 bg-purple-600 rounded-full mr-3 mt-2 flex-shrink-0"></div>
                    <span className="text-gray-600">{resp}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Başvuru Formu */}
            {showApplicationForm && !hasApplied && (
              <div className="mt-8 p-6 bg-purple-50 rounded-lg border border-purple-200">
                <h3 className="text-lg font-semibold text-purple-900 mb-4">Başvuru Formu</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Ön Yazı (Opsiyonel)
                    </label>
                    <textarea
                      value={coverLetter}
                      onChange={(e) => setCoverLetter(e.target.value)}
                      rows={4}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      placeholder="Neden bu pozisyon için uygun olduğunuzu düşünüyorsunuz?"
                    />
                  </div>
                  
                  <div className="flex space-x-3">
                    <button
                      onClick={handleApply}
                      disabled={applying || !canApply()}
                      className="flex-1 bg-purple-600 text-white py-3 rounded-lg font-medium hover:bg-purple-700 disabled:opacity-50 transition-colors flex items-center justify-center"
                    >
                      {applying ? (
                        "Gönderiliyor..."
                      ) : (
                        <>
                          <Send className="w-5 h-5 mr-2" />
                          Başvuruyu Gönder
                        </>
                      )}
                    </button>
                    <button
                      onClick={() => setShowApplicationForm(false)}
                      className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
                    >
                      İptal
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Sağ Kolon - Şirket Bilgisi ve Başvuru */}
        <div className="lg:col-span-1">
          {/* Başvuru Kartı */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6 sticky top-24">
            {hasApplied ? (
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Başvurunuz Alındı!</h3>
                <p className="text-gray-600 text-sm mb-4">
                  Başvurunuz değerlendirme sürecinde. Size en kısa sürede dönüş yapılacaktır.
                </p>
                <Link
                  to="/applications"
                  className="text-purple-600 hover:text-purple-700 font-medium text-sm"
                >
                  Başvurularımı Görüntüle →
                </Link>
              </div>
            ) : !canApply() && userProfile ? (
              <div className="text-center">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <XCircle className="w-8 h-8 text-red-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Başvuru Yapamazsınız</h3>
                <p className="text-gray-600 text-sm mb-4">
                  Bu ilan {getYearRequirement()} öğrencileri için açıktır. 
                  Siz şu anda {userProfile.year}. sınıf öğrencisisiniz.
                </p>
                {job.type === "departmental" && (
                  <p className="text-xs text-gray-500">
                    Full-time pozisyonlara sadece son sınıf öğrencileri başvurabilir.
                  </p>
                )}
              </div>
            ) : (
              <>
                <button
                  onClick={() => setShowApplicationForm(true)}
                  disabled={!canApply()}
                  className="w-full bg-purple-600 text-white py-3 rounded-lg font-medium hover:bg-purple-700 transition-colors flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Briefcase className="w-5 h-5 mr-2" />
                  Hemen Başvur
                </button>
                
                {job.deadline && (
                  <div className="mt-4 p-4 bg-amber-50 rounded-lg border border-amber-200">
                    <div className="flex items-start space-x-2">
                      <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm text-amber-800 font-medium">
                          Son başvuru: {new Date(job.deadline).toLocaleDateString('tr-TR')}
                        </p>
                        <p className="text-xs text-amber-700 mt-1">
                          Fırsatı kaçırmayın!
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </>
            )}

            {/* Sınıf Uyarısı */}
            {userProfile && canApply() && (
              <div className="mt-4 p-3 bg-green-50 rounded-lg border border-green-200">
                <div className="flex items-start space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-green-700">
                    {userProfile.year}. sınıf öğrencisi olarak bu ilana başvurabilirsiniz.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Şirket Bilgileri */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Şirket Hakkında</h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-center p-8 bg-gray-50 rounded-lg">
                <Building className="w-16 h-16 text-gray-400" />
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-900">{job.company || "ABC Teknoloji"}</h4>
                <p className="text-sm text-gray-600 mt-1">Yazılım ve Teknoloji</p>
              </div>
              
              <div className="space-y-2 text-sm">
                <div className="flex items-center text-gray-600">
                  <Users className="w-4 h-4 mr-2" />
                  <span>100-500 çalışan</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <MapPin className="w-4 h-4 mr-2" />
                  <span>{job.location || "İstanbul, Türkiye"}</span>
                </div>
                {job.is_remote && (
                  <div className="flex items-center text-gray-600">
                    <Globe className="w-4 h-4 mr-2" />
                    <span className="text-purple-600 font-medium">Uzaktan çalışma imkanı</span>
                  </div>
                )}
                {job.contact_email && (
                  <div className="flex items-center text-gray-600">
                    <Mail className="w-4 h-4 mr-2" />
                    <a href={`mailto:${job.contact_email}`} className="text-purple-600 hover:text-purple-700">
                      {job.contact_email}
                    </a>
                  </div>
                )}
              </div>
              
              <p className="text-sm text-gray-600 leading-relaxed">
                ABC Teknoloji, 2010 yılından bu yana yazılım sektöründe faaliyet gösteren, 
                yenilikçi çözümler üreten bir teknoloji şirketidir.
              </p>

              {job.benefits && (
                <div className="mt-4 pt-4 border-t">
                  <h5 className="font-medium text-gray-900 mb-2">Sağlanan İmkanlar</h5>
                  <p className="text-sm text-gray-600">{job.benefits}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}