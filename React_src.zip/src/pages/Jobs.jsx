import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
import { supabase } from "../utils/supabaseClient";
import { 
  Briefcase,
  MapPin,
  Coffee,
  Building,
  Clock,
  DollarSign,
  Search,
  Filter,
  Heart,
  ChevronRight,
  Users,
  GraduationCap,
  TrendingUp
} from "lucide-react";
import toast from "react-hot-toast";

export default function Jobs() {
  const { user } = useAuth();
  const [allJobs, setAllJobs] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [loading, setLoading] = useState(true);
  const [department, setDepartment] = useState("");
  const [search, setSearch] = useState("");
  const [appliedJobs, setAppliedJobs] = useState(new Set());
  const [favoriteJobs, setFavoriteJobs] = useState(new Set());
  const [selectedType, setSelectedType] = useState("all");
  const [selectedLocation, setSelectedLocation] = useState("all");
  const [isEligible, setIsEligible] = useState(false);

  const jobTypes = [
    { value: "all", label: "Tüm İlanlar" },
    { value: "departmental", label: "Bölüm İlanları" },
    { value: "part-time", label: "Part-Time" },
    { value: "full-time", label: "Full-Time" }
  ];

  const locations = [
    { value: "all", label: "Tüm Lokasyonlar" },
    { value: "istanbul", label: "İstanbul" },
    { value: "ankara", label: "Ankara" },
    { value: "izmir", label: "İzmir" },
    { value: "remote", label: "Uzaktan" }
  ];

  useEffect(() => {
    fetchJobs();
  }, [user]);

  const fetchJobs = async () => {
    if (!user) {
      toast.error("Lütfen giriş yapın.");
      setLoading(false);
      return;
    }

    setLoading(true);

    try {
      // Kullanıcı profili
      const { data: profile } = await supabase
        .from("profiles")
        .select("department, year")
        .eq("id", user.id)
        .single();

      if (!profile?.department) {
        toast.error("Bölüm bilgisi bulunamadı. Lütfen profilinizi güncelleyin.");
        setLoading(false);
        return;
      }

      setDepartment(profile.department);
      // Son sınıf kontrolü (4. sınıf ve üzeri)
      setIsEligible(profile.year >= 4);

      // Tüm işleri getir (hem bölüm hem part-time)
      const { data: jobsData, error } = await supabase
        .from("jobs")
        .select("*");

      if (error) {
        console.error("İş ilanları yüklenirken hata:", error);
        throw error;
      }

      console.log("Gelen iş ilanları:", jobsData);

      // Bölüme göre ve part-time işleri filtrele
      const filteredJobsData = jobsData?.filter(job => 
        job.department === profile.department || job.type === "part-time"
      ) || [];

      if (filteredJobsData.length === 0) {
        toast.warning("Size uygun iş ilanı bulunamadı.");
        setAllJobs([]);
        setFiltered([]);
        setLoading(false);
        return;
      }

      // Başvurulan işler
      const { data: applicationsData } = await supabase
        .from("job_applications")
        .select("job_id")
        .eq("user_id", user.id);

      if (applicationsData) {
        setAppliedJobs(new Set(applicationsData.map(a => a.job_id)));
      }

      // Favori işler
      const { data: favoriteData } = await supabase
        .from("favorites")
        .select("job_id")
        .eq("user_id", user.id)
        .eq("type", "job");

      if (favoriteData) {
        setFavoriteJobs(new Set(favoriteData.map(f => f.job_id)));
      }

      // Başvuru sayılarını hesapla
      const jobsWithStats = filteredJobsData.map(job => ({
        ...job,
        application_count: 0,
        user_application_status: null
      }));

      setAllJobs(jobsWithStats);
      setFiltered(jobsWithStats);
    } catch (error) {
      console.error("İş ilanları yüklenirken hata:", error);
      toast.error("İş ilanları yüklenemedi.");
    }

    setLoading(false);
  };

  useEffect(() => {
    let filteredData = allJobs;

    // Tip filtresi
    if (selectedType !== "all") {
      filteredData = filteredData.filter(job => job.type === selectedType);
    }

    // Lokasyon filtresi
    if (selectedLocation !== "all") {
      filteredData = filteredData.filter(job => {
        if (selectedLocation === "remote") {
          return job.is_remote;
        }
        return job.location?.toLowerCase().includes(selectedLocation);
      });
    }

    // Arama filtresi
    filteredData = filteredData.filter(job =>
      job.title.toLowerCase().includes(search.toLowerCase()) ||
      job.company?.toLowerCase().includes(search.toLowerCase()) ||
      job.description?.toLowerCase().includes(search.toLowerCase())
    );

    setFiltered(filteredData);
  }, [search, selectedType, selectedLocation, allJobs]);

  const toggleFavorite = async (jobId) => {
    try {
      if (favoriteJobs.has(jobId)) {
        await supabase
          .from("favorites")
          .delete()
          .eq("job_id", jobId)
          .eq("user_id", user.id);
        
        setFavoriteJobs(prev => {
          const newSet = new Set(prev);
          newSet.delete(jobId);
          return newSet;
        });
        toast.success("Favorilerden kaldırıldı");
      } else {
        await supabase
          .from("favorites")
          .insert({
            user_id: user.id,
            job_id: jobId,
            type: "job"
          });
        
        setFavoriteJobs(prev => new Set([...prev, jobId]));
        toast.success("Favorilere eklendi");
      }
    } catch (error) {
      toast.error("İşlem başarısız");
    }
  };

  const getApplicationBadge = (status) => {
    const badges = {
      pending: { color: "bg-yellow-100 text-yellow-800", text: "Değerlendiriliyor" },
      accepted: { color: "bg-green-100 text-green-800", text: "Kabul Edildi" },
      rejected: { color: "bg-red-100 text-red-800", text: "Reddedildi" }
    };
    const badge = badges[status];
    if (!badge) return null;

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${badge.color}`}>
        {badge.text}
      </span>
    );
  };

  const canApplyToJob = (job) => {
    // Part-time işlere herkes başvurabilir
    if (job.type === "part-time") return true;
    // Departman işlerine sadece son sınıf öğrencileri başvurabilir
    return isEligible;
  };

  const getJobTypeBadge = (type) => {
    const badges = {
      "part-time": { color: "bg-blue-100 text-blue-800", icon: Coffee, text: "Part-Time" },
      "full-time": { color: "bg-green-100 text-green-800", icon: Briefcase, text: "Full-Time" },
      "departmental": { color: "bg-purple-100 text-purple-800", icon: GraduationCap, text: "Mezuniyet" }
    };
    const badge = badges[type] || badges["full-time"];
    const Icon = badge.icon;

    return (
      <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${badge.color}`}>
        <Icon className="w-4 h-4 mr-1" />
        {badge.text}
      </span>
    );
  };

  return (
    <div className="max-w-7xl mx-auto py-8">
      {/* Başlık ve Arama */}
      <div className="text-center mb-10">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          İş İlanları
        </h1>
        <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
          {department} bölümüne uygun iş fırsatları ve part-time pozisyonları keşfedin.
        </p>
        
        {/* Uyarı - Son sınıf değilse */}
        {!isEligible && (
          <div className="max-w-2xl mx-auto mb-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
            <p className="text-amber-800 text-sm">
              <strong>Not:</strong> Mezuniyet sonrası iş ilanlarına başvurabilmek için son sınıf öğrencisi olmanız gerekmektedir. 
              Şu anda sadece part-time işlere başvurabilirsiniz.
            </p>
          </div>
        )}
        
        {/* Arama ve Filtreler */}
        <div className="flex flex-col md:flex-row gap-4 max-w-4xl mx-auto">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="İş veya şirket ara..."
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
          </div>
          
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          >
            {jobTypes.map(type => (
              <option key={type.value} value={type.value}>{type.label}</option>
            ))}
          </select>
          
          <select
            value={selectedLocation}
            onChange={(e) => setSelectedLocation(e.target.value)}
            className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          >
            {locations.map(loc => (
              <option key={loc.value} value={loc.value}>{loc.label}</option>
            ))}
          </select>
        </div>
      </div>

      {/* İstatistikler */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Toplam İlan</p>
              <p className="text-2xl font-bold text-gray-900">{allJobs.length}</p>
            </div>
            <Briefcase className="w-8 h-8 text-purple-600" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Part-Time</p>
              <p className="text-2xl font-bold text-blue-600">
                {allJobs.filter(j => j.type === "part-time").length}
              </p>
            </div>
            <Coffee className="w-8 h-8 text-blue-600" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Başvurulan</p>
              <p className="text-2xl font-bold text-green-600">{appliedJobs.size}</p>
            </div>
            <TrendingUp className="w-8 h-8 text-green-600" />
          </div>
        </div>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Kazanılacak Puan</p>
              <p className="text-2xl font-bold text-yellow-600">+5</p>
            </div>
            <Users className="w-8 h-8 text-yellow-600" />
          </div>
        </div>
      </div>

      {/* İş Listesi */}
      {loading ? (
        <div className="flex justify-center items-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12">
          <Briefcase className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">Aradığınız kriterlere uygun iş ilanı bulunamadı.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filtered.map((job) => {
            const hasApplied = appliedJobs.has(job.id);
            const isFavorite = favoriteJobs.has(job.id);
            const canApply = canApplyToJob(job);
            
            return (
              <div
                key={job.id}
                className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold text-gray-900">
                        {job.title}
                      </h3>
                      {getJobTypeBadge(job.type)}
                      {job.user_application_status && (
                        getApplicationBadge(job.user_application_status)
                      )}
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <Building className="w-4 h-4 mr-2" />
                      <span className="font-medium">{job.company}</span>
                    </div>
                  </div>
                  
                  {/* Favori Butonu */}
                  <button
                    onClick={() => toggleFavorite(job.id)}
                    className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <Heart 
                      className={`w-5 h-5 ${
                        isFavorite ? "fill-red-500 text-red-500" : "text-gray-400"
                      }`} 
                    />
                  </button>
                </div>

                {/* Açıklama */}
                <p className="text-sm text-gray-600 line-clamp-2 mb-4">
                  {job.description}
                </p>

                {/* Detaylar */}
                <div className="flex flex-wrap gap-3 mb-4 text-sm text-gray-500">
                  <div className="flex items-center">
                    <MapPin className="w-4 h-4 mr-1" />
                    <span>{job.location || "Belirtilmemiş"}</span>
                  </div>
                  {job.salary && (
                    <div className="flex items-center">
                      <DollarSign className="w-4 h-4 mr-1" />
                      <span>{job.salary}</span>
                    </div>
                  )}
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 mr-1" />
                    <span>{job.work_type || "Tam Zamanlı"}</span>
                  </div>
                </div>

                {/* Başvuru İstatistikleri */}
                {job.application_count > 0 && (
                  <p className="text-xs text-gray-500 mb-4">
                    {job.application_count} kişi başvurdu
                  </p>
                )}

                {/* Uyarı - Başvuru yapamaz */}
                {!canApply && job.type !== "part-time" && (
                  <p className="text-xs text-amber-600 mb-3">
                    Bu ilana başvurabilmek için son sınıf öğrencisi olmalısınız.
                  </p>
                )}

                {/* Aksiyon Butonu */}
                {canApply || hasApplied ? (
                  <Link
                    to={`/jobs/${job.id}`}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      width: '100%',
                      padding: '8px 16px',
                      borderRadius: '8px',
                      fontWeight: '500',
                      transition: 'all 0.2s',
                      textDecoration: 'none',
                      backgroundColor: hasApplied ? '#f3f4f6' : '#7c3aed',
                      color: hasApplied ? '#374151' : '#ffffff',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = hasApplied ? '#e5e7eb' : '#6d28d9';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = hasApplied ? '#f3f4f6' : '#7c3aed';
                    }}
                  >
                    {hasApplied ? "Başvuru Detayları" : "Detayları Gör"}
                    <ChevronRight className="w-4 h-4 ml-1" style={{ color: 'inherit' }} />
                  </Link>
                ) : (
                  <button
                    disabled
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      width: '100%',
                      padding: '8px 16px',
                      borderRadius: '8px',
                      fontWeight: '500',
                      backgroundColor: '#d1d5db',
                      color: '#6b7280',
                      cursor: 'not-allowed',
                      border: 'none',
                    }}
                  >
                    Detayları Gör
                    <ChevronRight className="w-4 h-4 ml-1" />
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}