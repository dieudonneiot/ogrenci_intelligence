// src/pages/Leaderboard.jsx

import { useState, useEffect } from "react";
import { useAuth } from "../contexts/AuthContext";
import { supabase } from "../utils/supabaseClient";
import { getDepartmentLeaderboard, getOverallLeaderboard } from "../services/pointsService";
import { 
  Trophy, 
  Users, 
  Medal, 
  TrendingUp,
  Crown,
  Award,
  Star
} from "lucide-react";

export default function Leaderboard() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overall"); // overall, department, weekly
  const [overallLeaderboard, setOverallLeaderboard] = useState([]);
  const [departmentLeaderboard, setDepartmentLeaderboard] = useState([]);
  const [userProfile, setUserProfile] = useState(null);
  const [userStats, setUserStats] = useState({
    overallRank: null,
    departmentRank: null,
    totalPoints: 0
  });

  useEffect(() => {
    loadUserProfile();
  }, [user]);

  useEffect(() => {
    if (userProfile) {
      loadLeaderboardData();
    }
  }, [activeTab, userProfile]);

  const loadUserProfile = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (error) throw error;
      setUserProfile(data);
    } catch (error) {
      console.error('Profil yüklenemedi:', error);
    }
  };

  const loadLeaderboardData = async () => {
    setLoading(true);
    try {
      if (activeTab === "overall") {
        const data = await getOverallLeaderboard(50);
        setOverallLeaderboard(data);
        
        // Kullanıcının genel sıralamasını bul
        const userRank = data.findIndex(u => u.id === user.id) + 1;
        setUserStats(prev => ({ 
          ...prev, 
          overallRank: userRank || null,
          totalPoints: data.find(u => u.id === user.id)?.total_points || 0
        }));
      } else if (activeTab === "department" && userProfile?.department) {
        const data = await getDepartmentLeaderboard(userProfile.department, 50);
        setDepartmentLeaderboard(data);
        
        // Kullanıcının bölüm sıralamasını bul
        const userDeptData = data.find(u => u.user_id === user.id);
        setUserStats(prev => ({ 
          ...prev, 
          departmentRank: userDeptData?.rank_in_department || null,
          totalPoints: userDeptData?.total_points || 0
        }));
      }
    } catch (error) {
      console.error('Liderlik tablosu yüklenemedi:', error);
    } finally {
      setLoading(false);
    }
  };

  const getRankIcon = (rank) => {
    if (rank === 1) return <Crown className="w-6 h-6 text-yellow-500" />;
    if (rank === 2) return <Medal className="w-6 h-6 text-gray-400" />;
    if (rank === 3) return <Medal className="w-6 h-6 text-orange-600" />;
    return <Star className="w-5 h-5 text-gray-400" />;
  };

  const getRankBadgeColor = (rank) => {
    if (rank === 1) return "bg-yellow-100 text-yellow-800 border-yellow-300";
    if (rank === 2) return "bg-gray-100 text-gray-800 border-gray-300";
    if (rank === 3) return "bg-orange-100 text-orange-800 border-orange-300";
    return "bg-white text-gray-700 border-gray-200";
  };

  const tabs = [
    { id: "overall", label: "Genel Sıralama", icon: Trophy },
    { id: "department", label: "Bölüm Sıralaması", icon: Users },
    { id: "weekly", label: "Haftalık", icon: TrendingUp, disabled: true }
  ];

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      {/* Başlık */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-4 flex items-center justify-center">
          <Trophy className="w-10 h-10 text-yellow-500 mr-3" />
          Liderlik Tablosu
        </h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Platformdaki en aktif ve başarılı öğrenciler arasında yerini al! 
          Puan kazanarak sıralamada yüksel ve ödüllere ulaş.
        </p>
      </div>

      {/* Kullanıcı İstatistikleri */}
      {userStats.totalPoints > 0 && (
        <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-xl p-6 text-white mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div>
              <p className="text-purple-200 text-sm mb-1">Toplam Puanın</p>
              <p className="text-3xl font-bold">{userStats.totalPoints}</p>
            </div>
            {userStats.overallRank && (
              <div>
                <p className="text-purple-200 text-sm mb-1">Genel Sıralama</p>
                <p className="text-3xl font-bold">{userStats.overallRank}.</p>
              </div>
            )}
            {userStats.departmentRank && (
              <div>
                <p className="text-purple-200 text-sm mb-1">Bölüm Sıralaması</p>
                <p className="text-3xl font-bold">{userStats.departmentRank}.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab Menü */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-6">
        <nav className="flex border-b border-gray-200">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => !tab.disabled && setActiveTab(tab.id)}
                disabled={tab.disabled}
                className={`flex-1 flex items-center justify-center px-4 py-4 text-sm font-medium border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? "border-purple-600 text-purple-600"
                    : tab.disabled
                    ? "border-transparent text-gray-400 cursor-not-allowed"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                <Icon className="w-5 h-5 mr-2" />
                {tab.label}
                {tab.disabled && (
                  <span className="ml-2 text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full">
                    Yakında
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Sıralama Listesi */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Sıra
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Öğrenci
                </th>
                {activeTab === "overall" && (
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Bölüm
                  </th>
                )}
                <th className="px-6 py-4 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Toplam Puan
                </th>
                <th className="px-6 py-4 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Seviye
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {activeTab === "overall" && overallLeaderboard.map((student) => (
                <tr 
                  key={student.id}
                  className={`${student.id === user.id ? 'bg-purple-50' : 'hover:bg-gray-50'} transition-colors`}
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      {getRankIcon(student.rank)}
                      <span className={`ml-2 text-lg font-bold ${
                        student.rank <= 3 ? 'text-gray-900' : 'text-gray-600'
                      }`}>
                        {student.rank}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                        <span className="text-purple-600 font-semibold">
                          {(student.full_name || student.email || '?')[0].toUpperCase()}
                        </span>
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-900">
                          {student.full_name || student.email?.split('@')[0] || 'Anonim'}
                          {student.id === user.id && (
                            <span className="ml-2 text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full">
                              Sen
                            </span>
                          )}
                        </p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    {student.department || 'Belirtilmemiş'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <span className="text-2xl font-bold text-purple-600">
                      {student.total_points}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${
                      getRankBadgeColor(student.rank)
                    }`}>
                      {student.total_points >= 1000 ? 'Uzman' : 
                       student.total_points >= 500 ? 'İleri' : 
                       student.total_points >= 100 ? 'Orta' : 'Başlangıç'}
                    </span>
                  </td>
                </tr>
              ))}

              {activeTab === "department" && departmentLeaderboard.map((student) => (
                <tr 
                  key={student.user_id}
                  className={`${student.user_id === user.id ? 'bg-purple-50' : 'hover:bg-gray-50'} transition-colors`}
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      {getRankIcon(student.rank_in_department)}
                      <span className={`ml-2 text-lg font-bold ${
                        student.rank_in_department <= 3 ? 'text-gray-900' : 'text-gray-600'
                      }`}>
                        {student.rank_in_department}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                        <span className="text-purple-600 font-semibold">
                          {(student.profiles?.full_name || student.profiles?.email || '?')[0].toUpperCase()}
                        </span>
                      </div>
                      <div className="ml-3">
                        <p className="text-sm font-medium text-gray-900">
                          {student.profiles?.full_name || student.profiles?.email?.split('@')[0] || 'Anonim'}
                          {student.user_id === user.id && (
                            <span className="ml-2 text-xs bg-purple-100 text-purple-700 px-2 py-0.5 rounded-full">
                              Sen
                            </span>
                          )}
                        </p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <span className="text-2xl font-bold text-purple-600">
                      {student.total_points}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-center">
                    <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${
                      getRankBadgeColor(student.rank_in_department)
                    }`}>
                      {student.total_points >= 1000 ? 'Uzman' : 
                       student.total_points >= 500 ? 'İleri' : 
                       student.total_points >= 100 ? 'Orta' : 'Başlangıç'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Bilgi Kartı */}
      <div className="mt-8 bg-gradient-to-r from-purple-50 to-indigo-50 rounded-xl p-6 border border-purple-200">
        <div className="flex items-start space-x-4">
          <Award className="w-8 h-8 text-purple-600 flex-shrink-0 mt-1" />
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Nasıl Puan Kazanabilirim?
            </h3>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>• Kurs tamamlayarak <span className="font-medium">+50 puan</span></li>
              <li>• Staj başvurusu yaparak <span className="font-medium">+5 puan</span></li>
              <li>• Stajı başarıyla tamamlayarak <span className="font-medium">+100 puan</span></li>
              <li>• Her gün giriş yaparak <span className="font-medium">+2 puan</span></li>
              <li>• 7 gün üst üste giriş yaparak <span className="font-medium">+15 puan</span></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}