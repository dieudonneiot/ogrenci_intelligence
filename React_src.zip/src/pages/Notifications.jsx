// src/pages/Notifications.jsx

import { useState, useEffect } from "react";
import { useAuth } from "../contexts/AuthContext";
import { supabase } from "../utils/supabaseClient";
import toast from "react-hot-toast";
import { 
  Bell,
  BellOff,
  CheckCircle,
  XCircle,
  Info,
  AlertCircle,
  BookOpen,
  Briefcase,
  Award,
  Calendar,
  Mail,
  Check,
  X,
  Trash2,
  Filter,
  Trophy,
  Zap
} from "lucide-react";

export default function Notifications() {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");
  const [markingRead, setMarkingRead] = useState(null);

  useEffect(() => {
    if (user) {
      fetchNotifications();
      setupRealtimeSubscription();
    }
    
    return () => {
      // Cleanup subscription
      supabase.channel('notifications').unsubscribe();
    };
  }, [user, filter]);

  const setupRealtimeSubscription = () => {
    // Real-time bildirimler için subscription
    const subscription = supabase
      .channel('notifications')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'notifications',
        filter: `user_id=eq.${user.id}`
      }, (payload) => {
        setNotifications(prev => [payload.new, ...prev]);
        toast.success('Yeni bildirim!', {
          icon: '🔔',
          duration: 4000
        });
      })
      .subscribe();
  };

  const fetchNotifications = async () => {
    setLoading(true);
    
    try {
      let query = supabase
        .from("notifications")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });

      if (filter === "unread") {
        query = query.eq("is_read", false);
      } else if (filter === "read") {
        query = query.eq("is_read", true);
      }

      const { data, error } = await query;

      if (error) throw error;

      setNotifications(data || []);
    } catch (error) {
      console.error("Bildirimler alınamadı:", error);
      toast.error("Bildirimler yüklenirken hata oluştu");
    }
    
    setLoading(false);
  };

  const markAsRead = async (notificationId) => {
    setMarkingRead(notificationId);
    
    try {
      const { error } = await supabase
        .from("notifications")
        .update({ is_read: true })
        .eq("id", notificationId);

      if (error) throw error;

      setNotifications(notifications.map(notif => 
        notif.id === notificationId 
          ? { ...notif, is_read: true }
          : notif
      ));
    } catch (error) {
      console.error("Bildirim güncellenemedi:", error);
      toast.error("İşlem başarısız");
    }
    
    setMarkingRead(null);
  };

  const markAllAsRead = async () => {
    try {
      const unreadIds = notifications
        .filter(n => !n.is_read)
        .map(n => n.id);

      if (unreadIds.length === 0) return;

      const { error } = await supabase
        .from("notifications")
        .update({ is_read: true })
        .in("id", unreadIds);

      if (error) throw error;

      setNotifications(notifications.map(notif => ({
        ...notif,
        is_read: true
      })));

      toast.success("Tüm bildirimler okundu olarak işaretlendi");
    } catch (error) {
      toast.error("İşlem başarısız");
    }
  };

  const deleteNotification = async (notificationId) => {
    try {
      const { error } = await supabase
        .from("notifications")
        .delete()
        .eq("id", notificationId);

      if (error) throw error;

      setNotifications(notifications.filter(n => n.id !== notificationId));
      toast.success("Bildirim silindi");
    } catch (error) {
      toast.error("Silme işlemi başarısız");
    }
  };

  const getNotificationIcon = (type, icon) => {
    const iconMap = {
      'trophy': <Trophy className="w-5 h-5" />,
      'award': <Award className="w-5 h-5" />,
      'check': <CheckCircle className="w-5 h-5" />,
      'book': <BookOpen className="w-5 h-5" />,
      'calendar': <Calendar className="w-5 h-5" />,
      'briefcase': <Briefcase className="w-5 h-5" />,
      'info': <Info className="w-5 h-5" />,
      'alert': <AlertCircle className="w-5 h-5" />,
      'zap': <Zap className="w-5 h-5" />
    };

    return iconMap[icon] || <Bell className="w-5 h-5" />;
  };

  const getNotificationColor = (type) => {
    const colorMap = {
      'points_earned': "bg-green-100 text-green-600",
      'course_completed': "bg-blue-100 text-blue-600",
      'application_accepted': "bg-purple-100 text-purple-600",
      'application_rejected': "bg-red-100 text-red-600",
      'new_course': "bg-indigo-100 text-indigo-600",
      'reminder': "bg-yellow-100 text-yellow-600",
      'achievement': "bg-orange-100 text-orange-600"
    };

    return colorMap[type] || "bg-gray-100 text-gray-600";
  };

  const getTimeAgo = (date) => {
    const now = new Date();
    const notifDate = new Date(date);
    const diffInHours = Math.floor((now - notifDate) / (1000 * 60 * 60));

    if (diffInHours < 1) return "Az önce";
    if (diffInHours < 24) return `${diffInHours} saat önce`;
    if (diffInHours < 48) return "Dün";
    if (diffInHours < 168) return `${Math.floor(diffInHours / 24)} gün önce`;
    return notifDate.toLocaleDateString("tr-TR");
  };

  const unreadCount = notifications.filter(n => !n.is_read).length;

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-8">
      {/* Başlık ve İstatistikler */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <Bell className="w-8 h-8 text-purple-600 mr-3" />
            Bildirimler
          </h1>
          {unreadCount > 0 && (
            <button
              onClick={markAllAsRead}
              className="text-purple-600 hover:text-purple-700 font-medium text-sm flex items-center"
            >
              <Check className="w-4 h-4 mr-1" />
              Tümünü Okundu İşaretle
            </button>
          )}
        </div>
        
        {unreadCount > 0 && (
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center mr-3">
                <Bell className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="font-medium text-purple-900">
                  {unreadCount} okunmamış bildirim
                </p>
                <p className="text-sm text-purple-700">
                  Yeni gelişmeleri kaçırmayın!
                </p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Filtre Sekmeleri */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-6">
        <div className="border-b border-gray-200 px-6">
          <nav className="flex space-x-8" aria-label="Tabs">
            <button
              onClick={() => setFilter("all")}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                filter === "all"
                  ? "border-purple-600 text-purple-600"
                  : "border-transparent text-gray-500 hover:text-gray-700"
              }`}
            >
              Tümü ({notifications.length})
            </button>
            <button
              onClick={() => setFilter("unread")}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                filter === "unread"
                  ? "border-purple-600 text-purple-600"
                  : "border-transparent text-gray-500 hover:text-gray-700"
              }`}
            >
              Okunmamış ({unreadCount})
            </button>
            <button
              onClick={() => setFilter("read")}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                filter === "read"
                  ? "border-purple-600 text-purple-600"
                  : "border-transparent text-gray-500 hover:text-gray-700"
              }`}
            >
              Okunmuş ({notifications.filter(n => n.is_read).length})
            </button>
          </nav>
        </div>
      </div>

      {/* Bildirimler Listesi */}
      {notifications.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
          <BellOff className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">
            {filter === "unread" 
              ? "Okunmamış bildiriminiz yok." 
              : filter === "read"
              ? "Okunmuş bildiriminiz yok."
              : "Henüz bildiriminiz yok."}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {notifications.map((notification) => (
            <div
              key={notification.id}
              className={`bg-white rounded-xl shadow-sm border ${
                notification.is_read ? "border-gray-200" : "border-purple-200 bg-purple-50"
              } p-6 hover:shadow-md transition-all`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4">
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                    getNotificationColor(notification.type)
                  }`}>
                    {getNotificationIcon(notification.type, notification.icon)}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 mb-1">
                      {notification.title}
                    </h3>
                    <p className="text-gray-600 text-sm mb-2">
                      {notification.message}
                    </p>
                    <div className="flex items-center space-x-4 text-xs text-gray-500">
                      <span>{getTimeAgo(notification.created_at)}</span>
                      {notification.action_url && (
                        <>
                          <span>•</span>
                          <a 
                            href={notification.action_url}
                            className="text-purple-600 hover:text-purple-700 font-medium"
                          >
                            Detayları Gör →
                          </a>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  {!notification.is_read && (
                    <button
                      onClick={() => markAsRead(notification.id)}
                      disabled={markingRead === notification.id}
                      className="p-2 text-gray-400 hover:text-green-600 transition-colors"
                      title="Okundu olarak işaretle"
                    >
                      <Check className="w-5 h-5" />
                    </button>
                  )}
                  <button
                    onClick={() => deleteNotification(notification.id)}
                    className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                    title="Sil"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}