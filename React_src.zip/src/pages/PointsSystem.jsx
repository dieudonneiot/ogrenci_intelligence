import { 
  Trophy,
  Star,
  BookOpen,
  Briefcase,
  Award,
  Clock,
  TrendingUp,
  Gift,
  Zap,
  Target,
  Users,
  CheckCircle
} from "lucide-react";

export default function PointsSystem() {
  const pointActivities = [
    {
      category: "Eğitim",
      color: "bg-purple-100 text-purple-700",
      icon: BookOpen,
      activities: [
        { action: "Kursa Kayıt", points: 10, description: "Yeni bir kursa kaydolduğunuzda" },
        { action: "Kurs Tamamlama", points: 50, description: "Kursu başarıyla bitirdiğinizde" },
        { action: "Quiz Başarısı", points: 5, description: "Quiz'de %80+ başarı gösterdiğinizde" },
        { action: "Sertifika Alma", points: 20, description: "Kurs sertifikası aldığınızda" }
      ]
    },
    {
      category: "Staj & İş",
      color: "bg-blue-100 text-blue-700",
      icon: Briefcase,
      activities: [
        { action: "Staj Başvurusu", points: 5, description: "Staj ilanına başvurduğunuzda" },
        { action: "Staj Kabulü", points: 30, description: "Staj başvurunuz kabul edildiğinde" },
        { action: "Staj Tamamlama", points: 100, description: "Stajı başarıyla tamamladığınızda" },
        { action: "İşveren Puanı", points: "10-50", description: "İşveren değerlendirmesine göre" }
      ]
    },
    {
      category: "Platform Aktivitesi",
      color: "bg-green-100 text-green-700",
      icon: Zap,
      activities: [
        { action: "Günlük Giriş", points: 2, description: "Her gün giriş yaptığınızda" },
        { action: "Haftalık Aktiflik", points: 15, description: "7 gün üst üste giriş" },
        { action: "Profil Tamamlama", points: 20, description: "Profilinizi %100 doldurduğunuzda" },
        { action: "İlk Başvuru", points: 10, description: "İlk iş/staj başvurunuzda" }
      ]
    },
    {
      category: "Başarılar",
      color: "bg-yellow-100 text-yellow-700",
      icon: Award,
      activities: [
        { action: "İlk 10'a Girme", points: 50, description: "Bölüm sıralamasında ilk 10" },
        { action: "Hızlı Öğrenen", points: 25, description: "1 ayda 3 kurs tamamlama" },
        { action: "Staj Ustası", points: 40, description: "3 farklı staj tamamlama" },
        { action: "Süper Öğrenci", points: 100, description: "1000 puan barajını geçme" }
      ]
    }
  ];

  const rewards = [
    {
      title: "Silikon Vadisi Gezisi",
      points: 5000,
      description: "1 haftalık teknoloji şirketleri turu",
      icon: "✈️",
      department: "Mühendislik ve Yazılım Bölümleri"
    },
    {
      title: "Online Sertifika Programları",
      points: 1000,
      description: "Udemy, Coursera premium üyelikleri",
      icon: "🎓",
      department: "Tüm Bölümler"
    },
    {
      title: "Mentörlük Programı",
      points: 2000,
      description: "Sektör profesyonelleriyle 1-1 mentörlük",
      icon: "👨‍🏫",
      department: "Tüm Bölümler"
    },
    {
      title: "Teknoloji Ekipmanları",
      points: 3000,
      description: "Laptop, tablet veya akıllı telefon",
      icon: "💻",
      department: "İlk 3 Sıradaki Öğrenciler"
    },
    {
      title: "Staj Garantisi",
      points: 1500,
      description: "Partner şirketlerde garantili staj",
      icon: "🏢",
      department: "Tüm Bölümler"
    },
    {
      title: "Konferans Biletleri",
      points: 800,
      description: "Ulusal ve uluslararası konferanslara katılım",
      icon: "🎟️",
      department: "İlgili Bölümler"
    }
  ];

  return (
    <div className="max-w-7xl mx-auto py-8">
      {/* Başlık */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4 flex items-center justify-center">
          <Star className="w-10 h-10 text-yellow-500 mr-3" />
          Puan Sistemi
        </h1>
        <p className="text-gray-600 max-w-3xl mx-auto text-lg">
          Öğrenci Platformu'nda aktif olarak yer alın, puan kazanın ve harika ödüllere ulaşın! 
          Puanlarınız bölümünüzdeki sıralamanızı belirler ve size özel fırsatlar sunar.
        </p>
      </div>

      {/* Puan Kazanma Yolları */}
      <div className="mb-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
          <TrendingUp className="w-8 h-8 text-green-600 mr-3" />
          Puan Kazanma Yolları
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {pointActivities.map((category, index) => {
            const Icon = category.icon;
            return (
              <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className={`inline-flex items-center px-4 py-2 rounded-lg ${category.color} mb-4`}>
                  <Icon className="w-5 h-5 mr-2" />
                  <span className="font-semibold">{category.category}</span>
                </div>
                
                <div className="space-y-3">
                  {category.activities.map((activity, idx) => (
                    <div key={idx} className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">{activity.action}</p>
                        <p className="text-sm text-gray-600">{activity.description}</p>
                      </div>
                      <div className="ml-4 flex items-center">
                        <span className="text-lg font-bold text-purple-600">+{activity.points}</span>
                        <span className="text-sm text-gray-500 ml-1">puan</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Sıralama Sistemi */}
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-xl p-8 text-white mb-12">
        <h2 className="text-2xl font-bold mb-6 flex items-center">
          <Trophy className="w-8 h-8 text-yellow-400 mr-3" />
          Sıralama Sistemi
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white/10 backdrop-blur rounded-lg p-6">
            <div className="flex items-center mb-3">
              <Users className="w-6 h-6 text-yellow-400 mr-2" />
              <h3 className="text-lg font-semibold">Bölüm Bazlı Sıralama</h3>
            </div>
            <p className="text-purple-100">
              Her bölümün kendi sıralaması vardır. Sadece kendi bölümünüzdeki öğrencilerle yarışırsınız.
            </p>
          </div>
          
          <div className="bg-white/10 backdrop-blur rounded-lg p-6">
            <div className="flex items-center mb-3">
              <Clock className="w-6 h-6 text-yellow-400 mr-2" />
              <h3 className="text-lg font-semibold">Haftalık Güncelleme</h3>
            </div>
            <p className="text-purple-100">
              Sıralamalar her hafta güncellenir. Haftalık ve toplam puanlarınız ayrı ayrı hesaplanır.
            </p>
          </div>
          
          <div className="bg-white/10 backdrop-blur rounded-lg p-6">
            <div className="flex items-center mb-3">
              <Target className="w-6 h-6 text-yellow-400 mr-2" />
              <h3 className="text-lg font-semibold">Hedef Odaklı</h3>
            </div>
            <p className="text-purple-100">
              İlk 10'a girmek özel rozetler ve ek puanlar kazandırır. Hedefinizi belirleyin!
            </p>
          </div>
        </div>
      </div>

      {/* Ödüller */}
      <div className="mb-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
          <Gift className="w-8 h-8 text-purple-600 mr-3" />
          Kazanabileceğiniz Ödüller
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {rewards.map((reward, index) => (
            <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-lg transition-shadow">
              <div className="text-4xl mb-4">{reward.icon}</div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{reward.title}</h3>
              <p className="text-gray-600 mb-4">{reward.description}</p>
              
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-2xl font-bold text-purple-600">{reward.points}</span>
                  <span className="text-sm text-gray-500 ml-1">puan</span>
                </div>
                <span className="text-xs bg-gray-100 text-gray-700 px-3 py-1 rounded-full">
                  {reward.department}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Nasıl Çalışır */}
      <div className="bg-gray-50 rounded-xl p-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Puan Sistemi Nasıl Çalışır?</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
              <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
              Puan Hesaplama
            </h3>
            <ul className="space-y-2 text-gray-600">
              <li>• Tüm aktiviteleriniz otomatik olarak puanlanır</li>
              <li>• İşveren değerlendirmeleri ek puan kazandırır</li>
              <li>• Düzenli platform kullanımı bonus puan getirir</li>
              <li>• Puanlarınız gerçek zamanlı güncellenir</li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-gray-900 mb-4 flex items-center">
              <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
              Ödül Sistemi
            </h3>
            <ul className="space-y-2 text-gray-600">
              <li>• Her dönem sonunda ödüller dağıtılır</li>
              <li>• Puanlarınızı biriktirip büyük ödüller alabilirsiniz</li>
              <li>• Bölüm birincileri özel ödüller kazanır</li>
              <li>• Ödüller gerçek ve kariyerinize katkı sağlar</li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 p-6 bg-purple-100 rounded-lg border border-purple-200">
          <p className="text-purple-900 font-medium text-center">
            💡 <strong>İpucu:</strong> Düzenli platform kullanımı ve staj performansınız en yüksek puanları kazandırır. 
            Hedeflerinizi belirleyin ve kararlılıkla ilerleyin!
          </p>
        </div>
      </div>
    </div>
  );
}