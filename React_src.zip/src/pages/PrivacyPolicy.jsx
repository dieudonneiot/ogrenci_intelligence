// src/pages/PrivacyPolicy.jsx

import { Shield, Lock, Eye, Database, UserCheck, AlertCircle } from "lucide-react";

export default function PrivacyPolicy() {
  return (
    <div className="max-w-4xl mx-auto py-12">
      {/* Hero Section */}
      <div className="text-center mb-12">
        <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Shield className="w-8 h-8 text-purple-600" />
        </div>
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Gizlilik Politikası
        </h1>
        <p className="text-gray-600">
          Son güncellenme: 1 Ocak 2024
        </p>
      </div>

      {/* Content */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 space-y-8">
        {/* Giriş */}
        <section>
          <p className="text-gray-600 leading-relaxed">
            Öğrenci Platformu olarak, kullanıcılarımızın gizliliğini korumak en önemli önceliklerimizden biridir. 
            Bu gizlilik politikası, kişisel verilerinizin nasıl toplandığını, kullanıldığını, saklandığını ve 
            korunduğunu açıklamaktadır.
          </p>
        </section>

        {/* Toplanan Bilgiler */}
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
            <Database className="w-6 h-6 text-purple-600 mr-2" />
            Toplanan Bilgiler
          </h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Kayıt Bilgileri</h3>
              <ul className="list-disc list-inside text-gray-600 space-y-1">
                <li>Ad ve soyad</li>
                <li>E-posta adresi</li>
                <li>Telefon numarası (isteğe bağlı)</li>
                <li>Üniversite ve bölüm bilgisi</li>
                <li>Mezuniyet yılı</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Kullanım Verileri</h3>
              <ul className="list-disc list-inside text-gray-600 space-y-1">
                <li>Platform üzerindeki aktiviteleriniz</li>
                <li>Tamamladığınız kurslar</li>
                <li>Başvurduğunuz iş ve staj ilanları</li>
                <li>Kazandığınız puanlar ve rozetler</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Teknik Bilgiler</h3>
              <ul className="list-disc list-inside text-gray-600 space-y-1">
                <li>IP adresi</li>
                <li>Tarayıcı türü ve versiyonu</li>
                <li>İşletim sistemi</li>
                <li>Ziyaret tarihi ve saati</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Bilgilerin Kullanımı */}
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
            <Eye className="w-6 h-6 text-purple-600 mr-2" />
            Bilgilerin Kullanımı
          </h2>
          <p className="text-gray-600 mb-3">Topladığımız bilgileri şu amaçlarla kullanırız:</p>
          <ul className="list-disc list-inside text-gray-600 space-y-2">
            <li>Size daha iyi bir kullanıcı deneyimi sunmak</li>
            <li>İlgi alanlarınıza uygun kurs ve iş önerileri yapmak</li>
            <li>Platform güvenliğini sağlamak</li>
            <li>İstatistiksel analizler yapmak</li>
            <li>Yasal yükümlülüklerimizi yerine getirmek</li>
            <li>Size bilgilendirme e-postaları göndermek (izninizle)</li>
          </ul>
        </section>

        {/* Bilgi Güvenliği */}
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
            <Lock className="w-6 h-6 text-purple-600 mr-2" />
            Bilgi Güvenliği
          </h2>
          <p className="text-gray-600 mb-3">
            Kişisel verilerinizin güvenliğini sağlamak için aşağıdaki önlemleri alıyoruz:
          </p>
          <div className="bg-purple-50 rounded-lg p-4 space-y-2">
            <p className="text-purple-900 font-medium">✓ SSL şifreleme teknolojisi</p>
            <p className="text-purple-900 font-medium">✓ Güvenli veri merkezleri</p>
            <p className="text-purple-900 font-medium">✓ Düzenli güvenlik testleri</p>
            <p className="text-purple-900 font-medium">✓ Sınırlı erişim yetkileri</p>
            <p className="text-purple-900 font-medium">✓ KVKK uyumlu veri işleme</p>
          </div>
        </section>

        {/* Üçüncü Taraflarla Paylaşım */}
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
            <UserCheck className="w-6 h-6 text-purple-600 mr-2" />
            Üçüncü Taraflarla Paylaşım
          </h2>
          <p className="text-gray-600 mb-3">
            Kişisel verilerinizi aşağıdaki durumlar dışında üçüncü taraflarla paylaşmayız:
          </p>
          <ul className="list-disc list-inside text-gray-600 space-y-2">
            <li>Açık izniniz olması durumunda</li>
            <li>Yasal zorunluluklar gerektirdiğinde</li>
            <li>Başvurduğunuz işveren firmalara (sadece başvuru bilgileri)</li>
            <li>Hizmet sağlayıcılarımıza (gizlilik sözleşmesi kapsamında)</li>
          </ul>
        </section>

        {/* Çerezler */}
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Çerezler (Cookies)</h2>
          <p className="text-gray-600 mb-3">
            Platformumuzda kullanıcı deneyimini iyileştirmek için çerezler kullanıyoruz:
          </p>
          <div className="space-y-3">
            <div className="border border-gray-200 rounded-lg p-4">
              <h4 className="font-semibold text-gray-900 mb-1">Zorunlu Çerezler</h4>
              <p className="text-sm text-gray-600">Platform işlevselliği için gerekli</p>
            </div>
            <div className="border border-gray-200 rounded-lg p-4">
              <h4 className="font-semibold text-gray-900 mb-1">Analitik Çerezler</h4>
              <p className="text-sm text-gray-600">Kullanım istatistikleri için</p>
            </div>
            <div className="border border-gray-200 rounded-lg p-4">
              <h4 className="font-semibold text-gray-900 mb-1">Tercih Çerezleri</h4>
              <p className="text-sm text-gray-600">Kişiselleştirilmiş deneyim için</p>
            </div>
          </div>
        </section>

        {/* Haklarınız */}
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Haklarınız</h2>
          <p className="text-gray-600 mb-3">KVKK kapsamında aşağıdaki haklara sahipsiniz:</p>
          <ul className="list-disc list-inside text-gray-600 space-y-2">
            <li>Kişisel verilerinizin işlenip işlenmediğini öğrenme</li>
            <li>İşlenen verileriniz hakkında bilgi talep etme</li>
            <li>İşleme amacını ve amacına uygun kullanılıp kullanılmadığını öğrenme</li>
            <li>Yanlış verilerin düzeltilmesini isteme</li>
            <li>Verilerinizin silinmesini veya yok edilmesini isteme</li>
            <li>İşlenen verilerin aktarıldığı üçüncü kişileri bilme</li>
          </ul>
        </section>

        {/* İletişim */}
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
            <AlertCircle className="w-6 h-6 text-purple-600 mr-2" />
            İletişim
          </h2>
          <p className="text-gray-600 mb-4">
            Gizlilik politikamız hakkında sorularınız veya kişisel verilerinizle ilgili 
            talepleriniz için bizimle iletişime geçebilirsiniz:
          </p>
          <div className="bg-gray-50 rounded-lg p-4">
            <p className="text-gray-700"><strong>E-posta:</strong> privacy@ogrenciplatformu.com</p>
            <p className="text-gray-700"><strong>Telefon:</strong> +90 (212) 345 67 89</p>
            <p className="text-gray-700"><strong>Adres:</strong> Teknokent, İnovasyon Cad. No:123, Beşiktaş, İstanbul</p>
          </div>
        </section>

        {/* Değişiklikler */}
        <section className="border-t pt-8">
          <p className="text-sm text-gray-600">
            Bu gizlilik politikası zaman zaman güncellenebilir. Önemli değişiklikler 
            olması durumunda size e-posta veya platform üzerinden bildirim yapılacaktır.
          </p>
        </section>
      </div>
    </div>
  );
}