import { useState, useEffect } from "react";
import { useAuth } from "../contexts/AuthContext";
import { supabase } from "../utils/supabaseClient";
import { addPoints, POINT_VALUES } from "../services/pointsService";
import { toast } from "react-hot-toast";
import { 
  User, 
  Mail, 
  BookOpen, 
  Award, 
  Calendar, 
  GraduationCap,
  Edit,
  Check,
  X
} from "lucide-react";

// Profil tamamlanma bonusu kontrol fonksiyonu
const checkProfileCompletionBonus = async (userId) => {
  const { count } = await supabase
    .from("points")
    .select("id", { count: "exact", head: true })
    .eq("user_id", userId)
    .eq("type", "platform")
    .eq("action", "profile_completion");
  return count > 0;
};

// Profil tamamlanma kontrolü ve puan ekleme
const checkProfileCompletion = async (profile, user) => {
  const fields = ['full_name', 'department', 'phone', 'year'];
  const filledFields = fields.filter(field => profile[field]);
  
  if (filledFields.length === fields.length) {
    // Daha önce verilmiş mi kontrol et
    const hasBonus = await checkProfileCompletionBonus(user.id);
    if (!hasBonus) {
      await addPoints(
        user.id,
        'platform',
        'profile_completion',
        POINT_VALUES.PROFILE_COMPLETION,
        'Profilinizi tamamladınız!'
      );
    }
  }
};

const departmentOptions = [
  "Bilgisayar Mühendisliği",
  "Elektrik-Elektronik Mühendisliği",
  "İşletme",
  "İktisat",
  "Endüstri Mühendisliği",
  "Hukuk",
  "Psikoloji",
  "İletişim",
  "Mimarlık",
  "Uluslararası İlişkiler",
  "Yazılım Mühendisliği",
  "Sigortacılık",
  "Sanat",
  "İnternet ve Ağ Teknolojileri",
  "Diğer",
];

// Tamamlanan Kurslar Komponenti
function CompletedCourses() {
  const [completedCourses, setCompletedCourses] = useState([]);
  const [coursesMap, setCoursesMap] = useState({});
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    if (!user) return;
    
    const fetchCompletedAndCourses = async () => {
      setLoading(true);

      // Kullanıcının tamamladığı kurslar
      const { data: completedData, error: completedError } = await supabase
        .from("completed_courses")
        .select("course_id, completed_at")
        .eq("user_id", user.id);

      if (completedError) {
        console.error("Tamamlanan kurslar alınamadı:", completedError);
        setCompletedCourses([]);
        setLoading(false);
        return;
      }

      setCompletedCourses(completedData || []);

      // Kurs detaylarını getir
      const courseIds = completedData?.map((c) => c.course_id) || [];
      if (courseIds.length === 0) {
        setLoading(false);
        return;
      }

      const { data: coursesData, error: coursesError } = await supabase
        .from("courses")
        .select("id, title, description")
        .in("id", courseIds);

      if (coursesError) {
        console.error("Kurs detayları alınamadı:", coursesError);
        setLoading(false);
        return;
      }

      // id bazlı map oluştur
      const map = {};
      coursesData?.forEach((course) => {
        map[course.id] = course;
      });
      setCoursesMap(map);
      setLoading(false);
    };

    fetchCompletedAndCourses();
  }, [user]);

  if (loading) {
    return (
      <div className="mt-12">
        <h2 className="text-2xl font-bold mb-6 text-gray-800 flex items-center">
          <Award className="mr-2 text-purple-600" />
          Tamamlanan Kurslar
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {[1, 2].map((i) => (
            <div key={i} className="bg-gray-100 p-4 rounded-xl animate-pulse">
              <div className="h-6 bg-gray-200 rounded mb-2"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (completedCourses.length === 0) {
    return (
      <div className="mt-12">
        <h2 className="text-2xl font-bold mb-6 text-gray-800 flex items-center">
          <Award className="mr-2 text-purple-600" />
          Tamamlanan Kurslar
        </h2>
        <div className="bg-gray-50 border-2 border-dashed border-gray-300 rounded-xl p-8 text-center">
          <BookOpen className="mx-auto h-12 w-12 text-gray-400 mb-3" />
          <p className="text-gray-600">Henüz tamamladığın kurs yok.</p>
          <p className="text-sm text-gray-500 mt-1">
            Kursları tamamladıkça burada görünecek!
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="mt-12">
      <h2 className="text-2xl font-bold mb-6 text-gray-800 flex items-center">
        <Award className="mr-2 text-purple-600" />
        Tamamlanan Kurslar ({completedCourses.length})
      </h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        {completedCourses.map(({ course_id, completed_at }) => {
          const course = coursesMap[course_id];
          return (
            <div
              key={course_id}
              className="bg-white p-5 rounded-xl shadow-sm hover:shadow-md transition-all duration-200 border border-gray-100 group"
            >
              <div className="flex justify-between items-start mb-3">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center group-hover:bg-purple-200 transition-colors">
                  <BookOpen className="w-6 h-6 text-purple-600" />
                </div>
                <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full">
                  Tamamlandı
                </span>
              </div>
              
              {course ? (
                <>
                  <h3 className="font-semibold text-lg text-gray-800 mb-2">
                    {course.title}
                  </h3>
                  <p className="text-sm text-gray-600 line-clamp-2 mb-3">
                    {course.description}
                  </p>
                </>
              ) : (
                <p className="text-sm text-gray-500 italic">
                  Kurs bilgisi bulunamadı.
                </p>
              )}
              
              <div className="flex items-center text-xs text-gray-500">
                <Calendar className="w-3 h-3 mr-1" />
                {new Date(completed_at).toLocaleDateString("tr-TR")}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// Ana Profil Komponenti
export default function Profile() {
  const { user, updateProfile } = useAuth();
  const [profile, setProfile] = useState({ email: "", department: "" });
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [tempDepartment, setTempDepartment] = useState("");
  const [userBadges, setUserBadges] = useState([]);

  useEffect(() => {
    if (user) {
      loadProfile();
      fetchBadges();
    }
    // eslint-disable-next-line
  }, [user]);

  async function loadProfile() {
    setLoading(true);
    
    let { data: profileData, error: profileError } = await supabase
      .from("profiles")
      .select("email, department, full_name, phone, year")
      .eq("id", user.id)
      .single();

    if (profileError && profileError.code === "PGRST116") {
      // Profil yoksa oluştur
      const { error: insertError } = await supabase
        .from("profiles")
        .insert({ 
          id: user.id, 
          email: user.email, 
          department: "" 
        });

      if (insertError) {
        toast.error("Profil oluşturulurken hata oluştu.");
        setLoading(false);
        return;
      }

      profileData = { email: user.email, department: "" };
    } else if (profileError) {
      toast.error("Profil yüklenirken hata oluştu.");
      setLoading(false);
      return;
    }

    setProfile(profileData);
    setTempDepartment(profileData.department || "");
    setLoading(false);

    // Profil tamamlanma kontrolü
    await checkProfileCompletion(profileData, user);
  }

  // Kullanıcının rozetlerini getir
  async function fetchBadges() {
    if (!user) return;
    const { data, error } = await supabase
      .from("user_badges")
      .select("id, badge_title, icon")
      .eq("user_id", user.id);

    if (error) {
      setUserBadges([]);
      return;
    }

    // Eğer icon bir SVG string ise, doğrudan render edebilirsiniz.
    // Eğer icon bir isim ise, burada bir ikon eşlemesi yapılabilir.
    setUserBadges(
      (data || []).map(badge => ({
        ...badge,
        icon: typeof badge.icon === "string" && badge.icon.startsWith("<svg")
          ? <span dangerouslySetInnerHTML={{ __html: badge.icon }} />
          : badge.icon // string isim ise burada ikon eşlemesi yapılabilir
      }))
    );
  }

  async function handleUpdate() {
    setLoading(true);

    const { error } = await supabase
      .from("profiles")
      .update({ department: tempDepartment })
      .eq("id", user.id);

    if (error) {
      toast.error("Güncelleme başarısız: " + error.message);
    } else {
      toast.success("Profil başarıyla güncellendi.");
      setProfile({ ...profile, department: tempDepartment });
      setIsEditing(false);
      
      // AuthContext'teki user metadata'yı da güncelle
      await updateProfile({ department: tempDepartment });

      // Profil tamamlanma kontrolü
      await checkProfileCompletion({ ...profile, department: tempDepartment }, user);
    }
    setLoading(false);
  }

  if (loading || !user) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  const userName = user.user_metadata?.full_name || user.email?.split('@')[0];

  return (
    <div className="max-w-4xl mx-auto">
      {/* Profil Header */}
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-2xl p-8 text-white shadow-lg mb-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <div className="w-20 h-20 bg-white/20 backdrop-blur rounded-full flex items-center justify-center">
              <User className="w-10 h-10 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold mb-1">{userName}</h1>
              <p className="text-purple-100 flex items-center">
                <Mail className="w-4 h-4 mr-2" />
                {user.email}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Profil Bilgileri */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8 mb-8">
        <h2 className="text-2xl font-bold mb-6 text-gray-800 flex items-center">
          <GraduationCap className="mr-2 text-purple-600" />
          Profil Bilgileri
        </h2>

        <div className="space-y-6">
          {/* Email (Değiştirilemez) */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              E-posta Adresi
            </label>
            <div className="flex items-center p-3 bg-gray-50 rounded-lg border border-gray-200">
              <Mail className="w-5 h-5 text-gray-400 mr-3" />
              <span className="text-gray-600">{profile.email}</span>
            </div>
          </div>

          {/* Bölüm (Düzenlenebilir) */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Bölüm
            </label>
            {isEditing ? (
              <div className="flex items-center space-x-2">
                <select
                  value={tempDepartment}
                  onChange={(e) => setTempDepartment(e.target.value)}
                  className="flex-1 p-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                >
                  <option value="">Bölüm seçiniz</option>
                  {departmentOptions.map((dept) => (
                    <option key={dept} value={dept}>
                      {dept}
                    </option>
                  ))}
                </select>
                <button
                  onClick={handleUpdate}
                  disabled={loading}
                  className="p-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                >
                  <Check className="w-5 h-5" />
                </button>
                <button
                  onClick={() => {
                    setIsEditing(false);
                    setTempDepartment(profile.department || "");
                  }}
                  className="p-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-200">
                <div className="flex items-center">
                  <GraduationCap className="w-5 h-5 text-gray-400 mr-3" />
                  <span className={profile.department ? "text-gray-700" : "text-gray-400"}>
                    {profile.department || "Bölüm seçilmemiş"}
                  </span>
                </div>
                <button
                  onClick={() => setIsEditing(true)}
                  className="text-purple-600 hover:text-purple-700 transition-colors"
                >
                  <Edit className="w-5 h-5" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Kullanıcı Rozetleri */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8 mb-8">
        <h2 className="text-2xl font-bold mb-6 text-gray-800 flex items-center">
          <Award className="mr-2 text-yellow-500" />
          Rozetlerim
        </h2>
        {userBadges.length === 0 ? (
          <div className="text-gray-500 text-sm">Henüz rozetin yok.</div>
        ) : (
          <div className="grid grid-cols-3 md:grid-cols-6 gap-4">
            {userBadges.map(badge => (
              <div key={badge.id} className="text-center">
                <div className="w-16 h-16 mx-auto mb-2 text-4xl flex items-center justify-center">
                  {badge.icon}
                </div>
                <p className="text-xs text-gray-600">{badge.badge_title}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Tamamlanan Kurslar */}
      <CompletedCourses />
    </div>
  );
}