import { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { supabase } from "../utils/supabaseClient";
import toast from "react-hot-toast";
import { 
  Settings as SettingsIcon, 
  User, 
  Lock, 
  Bell, 
  Shield,
  Eye,
  EyeOff,
  Save,
  AlertCircle,
  AlertTriangle
} from "lucide-react";

export default function Settings() {
  const { user, updatePassword, signOut, refreshSession } = useAuth();
  const [activeTab, setActiveTab] = useState("profile");
  const [loading, setLoading] = useState(false);
  
  // Profil state
  const [fullName, setFullName] = useState(user?.user_metadata?.full_name || "");
  
  // Şifre state
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false
  });
  
  // Hesap silme için state
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleteConfirmText, setDeleteConfirmText] = useState("");
  
  // Bildirim tercihleri
  const [notifications, setNotifications] = useState({
    email: true,
    newCourses: true,
    jobAlerts: true,
    newsletter: false
  });

  // Profil güncelleme
  const handleProfileUpdate = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const { error } = await supabase.auth.updateUser({
        data: { full_name: fullName }
      });
      
      if (error) throw error;
      toast.success("Profil bilgileri güncellendi!");
    } catch (error) {
      toast.error("Güncelleme başarısız: " + error.message);
    }
    
    setLoading(false);
  };

  // Şifre güncelleme
  const handlePasswordUpdate = async (e) => {
    e.preventDefault();
    
    if (newPassword !== confirmPassword) {
      toast.error("Yeni şifreler eşleşmiyor!");
      return;
    }
    
    if (newPassword.length < 6) {
      toast.error("Şifre en az 6 karakter olmalıdır!");
      return;
    }
    
    setLoading(true);
    const result = await updatePassword(newPassword);
    
    if (result.success) {
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    }
    
    setLoading(false);
  };

  // Hesap silme
  const handleDeleteAccount = async () => {
    if (deleteConfirmText !== "HESABIMI SIL") {
      toast.error("Onay metni hatalı!");
      return;
    }

    setLoading(true);
    
    try {
      // SQL fonksiyonunu çağır
      const { error } = await supabase.rpc('delete_user');

      if (error) {
        console.error('Hesap silme hatası:', error);
        toast.error("Hesap silinirken bir hata oluştu: " + error.message);
        setLoading(false);
        setShowDeleteModal(false);
        return;
      }

      // Başarılı silme
      toast.success("Hesabınız kalıcı olarak silindi");
      
      // Modal'ı kapat
      setShowDeleteModal(false);
      
      // Agresif temizleme
      try {
        // 1. Önce normal çıkış dene
        await supabase.auth.signOut();
        
        // 2. Local storage'ı temizle
        localStorage.clear();
        
        // 3. Session storage'ı temizle
        sessionStorage.clear();
        
        // 4. Supabase auth token'larını temizle
        const keys = Object.keys(localStorage);
        keys.forEach(key => {
          if (key.includes('supabase') || key.includes('auth')) {
            localStorage.removeItem(key);
          }
        });
        
      } catch (err) {
        console.log('Temizleme hatası:', err);
      }
      
      // 5. Sayfayı tamamen yenile ve ana sayfaya git
      setTimeout(() => {
        window.location.replace('/');
      }, 100);
      
    } catch (error) {
      console.error('Hesap silme hatası:', error);
      toast.error("Hesap silinirken bir hata oluştu");
      setLoading(false);
      setShowDeleteModal(false);
    }
  };

  // Bildirim tercihlerini güncelle
  const handleNotificationUpdate = async (key) => {
    const newNotifications = { ...notifications, [key]: !notifications[key] };
    setNotifications(newNotifications);

    const updateFields = {};
    if (key === "email") updateFields.email_notifications = newNotifications[key];
    if (key === "newCourses") updateFields.new_course_notifications = newNotifications[key];
    if (key === "jobAlerts") updateFields.job_alerts = newNotifications[key];
    if (key === "newsletter") updateFields.newsletter = newNotifications[key];

    const { error } = await supabase
      .from("notification_preferences")
      .update(updateFields)
      .eq("user_id", user.id);

    if (error) {
      toast.error("Tercih güncellenemedi: " + error.message);
    } else {
      toast.success("Bildirim tercihi güncellendi!");
    }
  };

  const tabs = [
    { id: "profile", label: "Profil", icon: User },
    { id: "password", label: "Şifre", icon: Lock },
    { id: "notifications", label: "Bildirimler", icon: Bell },
    { id: "privacy", label: "Gizlilik", icon: Shield }
  ];

  return (
    <div className="max-w-4xl mx-auto py-8">
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-indigo-600 p-6 text-white">
          <div className="flex items-center space-x-3">
            <SettingsIcon className="w-8 h-8" />
            <h1 className="text-2xl font-bold">Ayarlar</h1>
          </div>
        </div>

        <div className="flex flex-col md:flex-row">
          {/* Sidebar */}
          <div className="w-full md:w-64 border-r border-gray-200 p-4">
            <nav className="space-y-1">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                      activeTab === tab.id
                        ? "bg-purple-50 text-purple-600"
                        : "text-gray-700 hover:bg-gray-50"
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{tab.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Content */}
          <div className="flex-1 p-6">
            {/* Profil Ayarları */}
            {activeTab === "profile" && (
              <div>
                <h2 className="text-xl font-semibold mb-6">Profil Bilgileri</h2>
                <form onSubmit={handleProfileUpdate} className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Ad Soyad
                    </label>
                    <input
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      placeholder="Adınız Soyadınız"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      E-posta Adresi
                    </label>
                    <input
                      type="email"
                      value={user?.email}
                      disabled
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-300 rounded-lg text-gray-500 cursor-not-allowed"
                    />
                    <p className="mt-1 text-sm text-gray-500">
                      E-posta adresi değiştirilemez
                    </p>
                  </div>
                  
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex items-center bg-purple-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-purple-700 disabled:opacity-50 transition-colors"
                  >
                    <Save className="w-5 h-5 mr-2" />
                    {loading ? "Kaydediliyor..." : "Değişiklikleri Kaydet"}
                  </button>
                </form>
              </div>
            )}

            {/* Şifre Ayarları */}
            {activeTab === "password" && (
              <div>
                <h2 className="text-xl font-semibold mb-6">Şifre Değiştir</h2>
                <form onSubmit={handlePasswordUpdate} className="space-y-6 max-w-md">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Mevcut Şifre
                    </label>
                    <div className="relative">
                      <input
                        type={showPasswords.current ? "text" : "password"}
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                        className="w-full px-4 py-3 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        placeholder="••••••••"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPasswords({...showPasswords, current: !showPasswords.current})}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center"
                      >
                        {showPasswords.current ? (
                          <EyeOff className="h-5 w-5 text-gray-400" />
                        ) : (
                          <Eye className="h-5 w-5 text-gray-400" />
                        )}
                      </button>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Yeni Şifre
                    </label>
                    <div className="relative">
                      <input
                        type={showPasswords.new ? "text" : "password"}
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        className="w-full px-4 py-3 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        placeholder="••••••••"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPasswords({...showPasswords, new: !showPasswords.new})}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center"
                      >
                        {showPasswords.new ? (
                          <EyeOff className="h-5 w-5 text-gray-400" />
                        ) : (
                          <Eye className="h-5 w-5 text-gray-400" />
                        )}
                      </button>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Yeni Şifre (Tekrar)
                    </label>
                    <div className="relative">
                      <input
                        type={showPasswords.confirm ? "text" : "password"}
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        className="w-full px-4 py-3 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                        placeholder="••••••••"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPasswords({...showPasswords, confirm: !showPasswords.confirm})}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center"
                      >
                        {showPasswords.confirm ? (
                          <EyeOff className="h-5 w-5 text-gray-400" />
                        ) : (
                          <Eye className="h-5 w-5 text-gray-400" />
                        )}
                      </button>
                    </div>
                  </div>
                  
                  <button
                    type="submit"
                    disabled={loading || !newPassword || !confirmPassword}
                    className="flex items-center bg-purple-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-purple-700 disabled:opacity-50 transition-colors"
                  >
                    <Lock className="w-5 h-5 mr-2" />
                    {loading ? "Güncelleniyor..." : "Şifreyi Güncelle"}
                  </button>
                </form>
              </div>
            )}

            {/* Bildirim Ayarları */}
            {activeTab === "notifications" && (
              <div>
                <h2 className="text-xl font-semibold mb-6">Bildirim Tercihleri</h2>
                <div className="space-y-4">
                  <label className="flex items-center justify-between p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100">
                    <div>
                      <p className="font-medium text-gray-700">E-posta Bildirimleri</p>
                      <p className="text-sm text-gray-500">Önemli güncellemeler için e-posta al</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={notifications.email}
                      onChange={() => handleNotificationUpdate("email")}
                      className="h-5 w-5 text-purple-600 rounded focus:ring-purple-500"
                    />
                  </label>
                  
                  <label className="flex items-center justify-between p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100">
                    <div>
                      <p className="font-medium text-gray-700">Yeni Kurs Bildirimleri</p>
                      <p className="text-sm text-gray-500">Yeni kurslar eklendiğinde haberdar ol</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={notifications.newCourses}
                      onChange={() => handleNotificationUpdate("newCourses")}
                      className="h-5 w-5 text-purple-600 rounded focus:ring-purple-500"
                    />
                  </label>
                  
                  <label className="flex items-center justify-between p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100">
                    <div>
                      <p className="font-medium text-gray-700">İş İlanı Uyarıları</p>
                      <p className="text-sm text-gray-500">Profiline uygun iş ilanları için bildirim al</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={notifications.jobAlerts}
                      onChange={() => handleNotificationUpdate("jobAlerts")}
                      className="h-5 w-5 text-purple-600 rounded focus:ring-purple-500"
                    />
                  </label>
                  
                  <label className="flex items-center justify-between p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100">
                    <div>
                      <p className="font-medium text-gray-700">Haftalık Bülten</p>
                      <p className="text-sm text-gray-500">Haftalık özet ve öneriler al</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={notifications.newsletter}
                      onChange={() => handleNotificationUpdate("newsletter")}
                      className="h-5 w-5 text-purple-600 rounded focus:ring-purple-500"
                    />
                  </label>
                </div>
              </div>
            )}

            {/* Gizlilik Ayarları */}
            {activeTab === "privacy" && (
              <div>
                <h2 className="text-xl font-semibold mb-6">Gizlilik ve Güvenlik</h2>
                
                <div className="space-y-6">
                  {/* İki Faktörlü Doğrulama */}
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-start space-x-4">
                      <Shield className="w-6 h-6 text-purple-600 mt-1" />
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">İki Faktörlü Doğrulama</h3>
                        <p className="text-sm text-gray-600 mt-1">
                          Hesabınızı ekstra güvenlik katmanı ile koruyun
                        </p>
                        <button className="mt-3 text-purple-600 hover:text-purple-700 font-medium text-sm">
                          Etkinleştir →
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  {/* Hesap Gizliliği */}
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <h3 className="font-medium text-gray-900 mb-3">Profil Görünürlüğü</h3>
                    <div className="space-y-2">
                      <label className="flex items-center">
                        <input
                          type="radio"
                          name="visibility"
                          className="h-4 w-4 text-purple-600 focus:ring-purple-500"
                          defaultChecked
                        />
                        <span className="ml-2 text-sm text-gray-700">Herkese açık</span>
                      </label>
                      <label className="flex items-center">
                        <input
                          type="radio"
                          name="visibility"
                          className="h-4 w-4 text-purple-600 focus:ring-purple-500"
                        />
                        <span className="ml-2 text-sm text-gray-700">Sadece kayıtlı kullanıcılar</span>
                      </label>
                      <label className="flex items-center">
                        <input
                          type="radio"
                          name="visibility"
                          className="h-4 w-4 text-purple-600 focus:ring-purple-500"
                        />
                        <span className="ml-2 text-sm text-gray-700">Gizli</span>
                      </label>
                    </div>
                  </div>
                  
                  {/* Tehlike Bölgesi */}
                  <div className="border-t pt-6">
                    <h3 className="text-lg font-medium text-red-600 mb-4">Tehlike Bölgesi</h3>
                    
                    <div className="space-y-4">
                      {/* Hesabı Dondur */}
                      <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-700">Hesabı Geçici Olarak Dondur</p>
                          <p className="text-sm text-gray-500">Hesabınız geçici olarak erişime kapatılır</p>
                        </div>
                        <button className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
                          Dondur
                        </button>
                      </div>
                      
                      {/* Hesabı Sil */}
                      <div className="flex items-center justify-between p-4 border border-red-200 rounded-lg bg-red-50">
                        <div>
                          <p className="font-medium text-red-700">Hesabı Kalıcı Olarak Sil</p>
                          <p className="text-sm text-red-600">Bu işlem geri alınamaz!</p>
                        </div>
                        <button 
                          onClick={() => setShowDeleteModal(true)}
                          className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
                        >
                          Hesabı Sil
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Hesap Silme Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Hesabı Kalıcı Olarak Sil</h3>
            </div>
            
            <div className="mb-6">
              <p className="text-gray-600 mb-4">
                Bu işlem geri alınamaz! Hesabınızı silerseniz:
              </p>
              <ul className="list-disc list-inside space-y-1 text-sm text-gray-600 ml-2">
                <li>Tüm kişisel bilgileriniz silinecek</li>
                <li>Kurs kayıtlarınız iptal olacak</li>
                <li>Başvurularınız silinecek</li>
                <li>Kazandığınız puanlar kaybolacak</li>
                <li>Bu e-posta ile tekrar kayıt olamayacaksınız</li>
              </ul>
            </div>
            
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Onaylamak için <span className="font-bold text-red-600">HESABIMI SIL</span> yazın:
              </label>
              <input
                type="text"
                value={deleteConfirmText}
                onChange={(e) => setDeleteConfirmText(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                placeholder="HESABIMI SIL"
              />
            </div>
            
            <div className="flex space-x-3">
              <button
                onClick={() => {
                  setShowDeleteModal(false);
                  setDeleteConfirmText("");
                }}
                className="flex-1 px-4 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 font-medium"
              >
                İptal
              </button>
              <button
                onClick={handleDeleteAccount}
                disabled={deleteConfirmText !== "HESABIMI SIL" || loading}
                className="flex-1 px-4 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 font-medium"
              >
                {loading ? "Siliniyor..." : "Hesabı Sil"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}