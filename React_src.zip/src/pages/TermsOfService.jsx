// src/pages/TermsOfService.jsx

import { FileText, Scale, Users, Shield, AlertTriangle, CheckCircle } from "lucide-react";

export default function TermsOfService() {
  return (
    <div className="max-w-4xl mx-auto py-12">
      {/* Hero Section */}
      <div className="text-center mb-12">
        <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <FileText className="w-8 h-8 text-purple-600" />
        </div>
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Kullanım Şartları
        </h1>
        <p className="text-gray-600">
          Son güncellenme: 1 Ocak 2025
        </p>
      </div>

      {/* Content */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 space-y-8">
        {/* Giriş */}
        <section>
          <p className="text-gray-600 leading-relaxed">
            Öğrenci Platformu'na hoş geldiniz. Platformumuzu kullanarak aşağıdaki şartları 
            kabul etmiş sayılırsınız. Lütfen bu şartları dikkatlice okuyunuz.
          </p>
        </section>

        {/* Genel Şartlar */}
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
            <Scale className="w-6 h-6 text-purple-600 mr-2" />
            Genel Kullanım Şartları
          </h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">1. Platform Kullanımı</h3>
              <ul className="list-disc list-inside text-gray-600 space-y-1">
                <li>Platform sadece eğitim ve kariyer gelişimi amaçlı kullanılmalıdır</li>
                <li>18 yaşından küçükler veli izni ile kayıt olabilir</li>
                <li>Bir kişi sadece bir hesap açabilir</li>
                <li>Hesap bilgilerinizin güvenliğinden siz sorumlusunuz</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-gray-900 mb-2">2. Üyelik Şartları</h3>
              <ul className="list-disc list-inside text-gray-600 space-y-1">
                <li>Kayıt sırasında doğru ve güncel bilgiler vermelisiniz</li>
                <li>Üniversite öğrencisi veya yeni mezun olmalısınız</li>
                <li>E-posta adresinizi doğrulamalısınız</li>
                <li>Profil bilgilerinizi güncel tutmalısınız</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Kullanıcı Sorumlulukları */}
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
            <Users className="w-6 h-6 text-purple-600 mr-2" />
            Kullanıcı Sorumlulukları
          </h2>
          <p className="text-gray-600 mb-3">Platform kullanıcıları olarak:</p>
          <div className="bg-purple-50 rounded-lg p-4 space-y-2">
            <p className="text-purple-900">
              <CheckCircle className="w-4 h-4 inline mr-2 text-purple-600" />
              Diğer kullanıcılara saygılı davranmalısınız
            </p>
            <p className="text-purple-900">
              <CheckCircle className="w-4 h-4 inline mr-2 text-purple-600" />
              Yanıltıcı veya sahte bilgi paylaşmamalısınız
            </p>
            <p className="text-purple-900">
              <CheckCircle className="w-4 h-4 inline mr-2 text-purple-600" />
              Telif haklarına saygı göstermelisiniz
            </p>
            <p className="text-purple-900">
              <CheckCircle className="w-4 h-4 inline mr-2 text-purple-600" />
              Platform güvenliğini tehlikeye atacak davranışlarda bulunmamalısınız
            </p>
            <p className="text-purple-900">
              <CheckCircle className="w-4 h-4 inline mr-2 text-purple-600" />
              Spam veya istenmeyen içerik paylaşmamalısınız
            </p>
          </div>
        </section>

        {/* Yasaklı Davranışlar */}
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
            <AlertTriangle className="w-6 h-6 text-red-600 mr-2" />
            Yasaklı Davranışlar
          </h2>
          <p className="text-gray-600 mb-3">Aşağıdaki davranışlar kesinlikle yasaktır:</p>
          <ul className="list-disc list-inside text-gray-600 space-y-2">
            <li>Başkalarının kişisel bilgilerini izinsiz paylaşmak</li>
            <li>Platformu ticari amaçlarla kullanmak (izin alınmadıysa)</li>
            <li>Virüs, trojan veya zararlı kod yaymak</li>
            <li>Platformun normal işleyişini bozmaya çalışmak</li>
            <li>Sahte veya yanıltıcı profil oluşturmak</li>
            <li>Hakaret, tehdit veya taciz içeren davranışlarda bulunmak</li>
            <li>Yasalara aykırı içerik paylaşmak</li>
          </ul>
        </section>

        {/* Puan Sistemi Kuralları */}
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Puan Sistemi Kuralları</h2>
          <div className="space-y-3">
            <p className="text-gray-600">
              Puan sistemi dürüst kullanım esasına dayanır:
            </p>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>Puan kazanmak için hile veya bot kullanımı yasaktır</li>
              <li>Başka kullanıcılarla puan ticareti yapılamaz</li>
              <li>Sistem açıklarını kullanmak hesap kapatma sebebidir</li>
              <li>Kazanılan puanlar devredilemez</li>
              <li>Platform, şüpheli puan artışlarını inceleme hakkına sahiptir</li>
            </ul>
          </div>
        </section>

        {/* İçerik Hakları */}
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
            <Shield className="w-6 h-6 text-purple-600 mr-2" />
            İçerik Hakları
          </h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Kullanıcı İçerikleri</h3>
              <p className="text-gray-600">
                Platforma yüklediğiniz içeriklerin (CV, proje, yorum vb.) sorumluluğu 
                size aittir. Bu içerikleri yükleyerek, platformun bunları kullanma, 
                gösterme ve paylaşma hakkına sahip olduğunu kabul edersiniz.
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Platform İçerikleri</h3>
              <p className="text-gray-600">
                Platform üzerindeki tüm içerikler (kurslar, tasarım, yazılım, metinler) 
                telif hakkı ile korunmaktadır. İzinsiz kopyalama, dağıtma veya değiştirme 
                yasaktır.
              </p>
            </div>
          </div>
        </section>

        {/* Sorumluluk Reddi */}
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Sorumluluk Reddi</h2>
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <p className="text-yellow-900">
              Platform "olduğu gibi" sunulmaktadır. İş bulma garantisi vermiyoruz. 
              Kullanıcılar arasındaki anlaşmazlıklardan sorumlu değiliz. Platform 
              kullanımından doğabilecek zararlardan sorumluluk kabul etmiyoruz.
            </p>
          </div>
        </section>

        {/* Hesap Askıya Alma ve Fesih */}
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Hesap Askıya Alma ve Fesih</h2>
          <p className="text-gray-600 mb-3">
            Aşağıdaki durumlarda hesabınız askıya alınabilir veya kapatılabilir:
          </p>
          <ul className="list-disc list-inside text-gray-600 space-y-2">
            <li>Kullanım şartlarının ihlali</li>
            <li>Sahte veya yanıltıcı bilgi paylaşımı</li>
            <li>Diğer kullanıcıları taciz veya rahatsız etme</li>
            <li>Platform güvenliğini tehdit eden davranışlar</li>
            <li>Yasal olmayan faaliyetler</li>
          </ul>
        </section>

        {/* Değişiklikler */}
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Değişiklikler</h2>
          <p className="text-gray-600">
            Bu kullanım şartları zaman zaman güncellenebilir. Önemli değişiklikler 
            olması durumunda size e-posta veya platform üzerinden bildirim yapılacaktır. 
            Değişikliklerden sonra platformu kullanmaya devam etmeniz, yeni şartları 
            kabul ettiğiniz anlamına gelir.
          </p>
        </section>

        {/* İletişim */}
        <section className="border-t pt-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4">İletişim</h2>
          <p className="text-gray-600 mb-4">
            Kullanım şartları hakkında sorularınız için:
          </p>
          <div className="bg-gray-50 rounded-lg p-4">
            <p className="text-gray-700"><strong>E-posta:</strong> info@ogrenciintelligence.com</p>
            <p className="text-gray-700"><strong>Telefon:</strong> +90 (212) 345 67 89</p>
          </div>
        </section>
      </div>
    </div>
  );
}