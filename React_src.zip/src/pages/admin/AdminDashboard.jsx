import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useAdmin } from "../../contexts/AdminContext";
import supabase from "../../utils/supabaseClient";
import { 
  Shield, Users, Building2, Briefcase, GraduationCap, 
  CreditCard, AlertCircle, CheckCircle, XCircle, 
  TrendingUp, Clock, Activity, BarChart3
} from "lucide-react";
import { toast } from "react-hot-toast";

export default function AdminDashboard() {
  const { adminData } = useAdmin();
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalCompanies: 0,
    pendingCompanies: 0,
    totalJobs: 0,
    totalInternships: 0,
    activeSubscriptions: 0,
    monthlyRevenue: 0,
    todayRegistrations: 0
  });
  const [recentActivities, setRecentActivities] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      // Fetch all stats in parallel
      const [
        usersCount,
        companiesData,
        jobsCount,
        internshipsCount,
        subscriptionsData,
        recentLogs
      ] = await Promise.all([
        // Total users (students)
        supabase
          .from('profiles')
          .select('*', { count: 'exact', head: true }),
        
        // Companies stats
        supabase
          .from('companies')
          .select('approval_status'),
        
        // Total jobs
        supabase
          .from('jobs')
          .select('*', { count: 'exact', head: true })
          .eq('is_active', true),
        
        // Total internships
        supabase
          .from('internships')
          .select('*', { count: 'exact', head: true })
          .eq('is_active', true),
        
        // Active subscriptions and revenue
        supabase
          .from('company_subscriptions')
          .select('*, subscription_plans!inner(price_monthly, price_yearly)')
          .eq('status', 'active'),
        
        // Recent admin activities
        supabase
          .from('admin_logs')
          .select('*, admins!inner(name)')
          .order('created_at', { ascending: false })
          .limit(10)
      ]);

      // Calculate stats
      const pendingCompanies = companiesData.data?.filter(c => c.approval_status === 'pending').length || 0;
      const approvedCompanies = companiesData.data?.filter(c => c.approval_status === 'approved').length || 0;
      
      // Calculate monthly revenue
      let monthlyRevenue = 0;
      subscriptionsData.data?.forEach(sub => {
        if (sub.billing_period === 'monthly') {
          monthlyRevenue += sub.subscription_plans.price_monthly;
        } else if (sub.billing_period === 'yearly') {
          monthlyRevenue += sub.subscription_plans.price_yearly / 12;
        }
      });

      // Today's registrations
      const today = new Date().toISOString().split('T')[0];
      const { count: todayRegs } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true })
        .gte('created_at', today);

      setStats({
        totalUsers: usersCount.count || 0,
        totalCompanies: companiesData.data?.length || 0,
        pendingCompanies,
        approvedCompanies,
        totalJobs: jobsCount.count || 0,
        totalInternships: internshipsCount.count || 0,
        activeSubscriptions: subscriptionsData.data?.length || 0,
        monthlyRevenue: Math.round(monthlyRevenue),
        todayRegistrations: todayRegs || 0
      });

      setRecentActivities(recentLogs.data || []);
    } catch (error) {
      console.error('Dashboard data fetch error:', error);
      toast.error('Veriler yüklenirken hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  const getActivityIcon = (actionType) => {
    switch (actionType) {
      case 'company_approve':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'company_reject':
        return <XCircle className="w-5 h-5 text-red-500" />;
      case 'job_delete':
        return <Briefcase className="w-5 h-5 text-gray-500" />;
      default:
        return <Activity className="w-5 h-5 text-blue-500" />;
    }
  };

  const getActivityText = (activity) => {
    switch (activity.action_type) {
      case 'company_approve':
        return 'Şirket onaylandı';
      case 'company_reject':
        return 'Şirket reddedildi';
      case 'job_delete':
        return 'İş ilanı silindi';
      case 'user_ban':
        return 'Kullanıcı engellendi';
      default:
        return activity.action_type;
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 60) return `${minutes} dakika önce`;
    if (hours < 24) return `${hours} saat önce`;
    if (days < 7) return `${days} gün önce`;
    
    return date.toLocaleDateString('tr-TR');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-3">
                <Shield className="w-8 h-8 text-purple-600" />
                Admin Dashboard
              </h1>
              <p className="text-sm text-gray-600 mt-1">
                Hoş geldiniz, {adminData?.name}
              </p>
            </div>
            <div className="flex items-center gap-4">
              <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm font-medium">
                {adminData?.role === 'super_admin' ? 'Süper Admin' : 'Admin'}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Toplam Kullanıcı</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{stats.totalUsers}</p>
                <p className="text-xs text-green-600 mt-2">
                  +{stats.todayRegistrations} bugün
                </p>
              </div>
              <Users className="w-10 h-10 text-blue-500" />
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Şirketler</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{stats.totalCompanies}</p>
                <p className="text-xs text-orange-600 mt-2">
                  {stats.pendingCompanies} onay bekliyor
                </p>
              </div>
              <Building2 className="w-10 h-10 text-purple-500" />
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Aktif İlanlar</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">
                  {stats.totalJobs + stats.totalInternships}
                </p>
                <p className="text-xs text-gray-500 mt-2">
                  {stats.totalJobs} iş, {stats.totalInternships} staj
                </p>
              </div>
              <Briefcase className="w-10 h-10 text-green-500" />
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Aylık Gelir</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">
                  ₺{stats.monthlyRevenue.toLocaleString()}
                </p>
                <p className="text-xs text-green-600 mt-2">
                  {stats.activeSubscriptions} aktif abonelik
                </p>
              </div>
              <CreditCard className="w-10 h-10 text-yellow-500" />
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          {/* Pending Approvals */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-orange-500" />
              Onay Bekleyenler
            </h2>
            {stats.pendingCompanies > 0 ? (
              <div>
                <p className="text-3xl font-bold text-orange-600 mb-4">
                  {stats.pendingCompanies}
                </p>
                <p className="text-gray-600 mb-4">
                  Şirket onay bekliyor
                </p>
                <Link
                  to="/admin/companies?status=pending"
                  className="inline-flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
                >
                  Şirketleri İncele
                  <TrendingUp className="w-4 h-4" />
                </Link>
              </div>
            ) : (
              <p className="text-gray-500">Onay bekleyen şirket bulunmuyor</p>
            )}
          </div>

          {/* Quick Links */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Hızlı Erişim
            </h2>
            <div className="grid grid-cols-2 gap-4">
              <Link
                to="/admin/companies"
                className="flex flex-col items-center gap-2 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <Building2 className="w-8 h-8 text-purple-600" />
                <span className="text-sm font-medium text-gray-700">Şirketler</span>
              </Link>
              <Link
                to="/admin/users"
                className="flex flex-col items-center gap-2 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <Users className="w-8 h-8 text-blue-600" />
                <span className="text-sm font-medium text-gray-700">Kullanıcılar</span>
              </Link>
              <Link
                to="/admin/jobs"
                className="flex flex-col items-center gap-2 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <Briefcase className="w-8 h-8 text-green-600" />
                <span className="text-sm font-medium text-gray-700">İlanlar</span>
              </Link>
              <Link
                to="/admin/subscriptions"
                className="flex flex-col items-center gap-2 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <CreditCard className="w-8 h-8 text-yellow-600" />
                <span className="text-sm font-medium text-gray-700">Abonelikler</span>
              </Link>
            </div>
          </div>
        </div>

        {/* Recent Activities */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <Clock className="w-5 h-5 text-gray-600" />
            Son Aktiviteler
          </h2>
          {recentActivities.length > 0 ? (
            <div className="space-y-3">
              {recentActivities.map((activity) => (
                <div 
                  key={activity.id} 
                  className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg"
                >
                  {getActivityIcon(activity.action_type)}
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900">
                      {getActivityText(activity)}
                    </p>
                    <p className="text-xs text-gray-500">
                      {activity.admins.name} • {formatDate(activity.created_at)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500">Henüz aktivite bulunmuyor</p>
          )}
        </div>
      </div>
    </div>
  );
}