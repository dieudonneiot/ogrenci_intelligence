import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import supabase from "../../utils/supabaseClient";
import { toast } from "react-hot-toast";
import { Shield, Mail, Lock, User, Loader2, AlertCircle, CheckCircle } from "lucide-react";

// Bu sayfa sadece hiç admin yoksa çalışmalı
export default function AdminSetup() {
  const navigate = useNavigate();
  const [hasAdmins, setHasAdmins] = useState(null);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [setupKey, setSetupKey] = useState("");
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: ""
  });

  // Güvenlik için setup key kontrolü (opsiyonel)
  const SETUP_KEY = import.meta.env.VITE_ADMIN_SETUP_KEY || "default-setup-key-2024";

  useEffect(() => {
    checkExistingAdmins();
  }, []);

  const checkExistingAdmins = async () => {
    try {
      // Önce admin tablosunu kontrol et
      const { count } = await supabase
        .from('admins')
        .select('*', { count: 'exact', head: true });
      
      setHasAdmins(count > 0);
      
      if (count > 0) {
        // Admin varsa bu sayfaya erişimi engelle
        toast.error('Bu sayfaya erişim yetkiniz yok');
        navigate('/');
        return;
      }

      // Ek güvenlik: auth.users tablosunda admin tipinde kullanıcı var mı kontrol et
      const { data: users } = await supabase
        .from('auth.users')
        .select('raw_user_meta_data')
        .eq('raw_user_meta_data->>user_type', 'admin');
      
      if (users && users.length > 0) {
        toast.error('Sistemde admin kullanıcı mevcut');
        navigate('/');
        return;
      }
    } catch (error) {
      console.error('Admin check error:', error);
      // Güvenlik için hata durumunda da erişimi engelle
      navigate('/');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Setup key kontrolü
    if (setupKey !== SETUP_KEY) {
      toast.error('Geçersiz kurulum anahtarı');
      return;
    }

    // Validation
    if (!form.name || !form.email || !form.password) {
      toast.error('Tüm alanları doldurun');
      return;
    }

    if (form.password.length < 8) {
      toast.error('Şifre en az 8 karakter olmalı');
      return;
    }

    if (form.password !== form.confirmPassword) {
      toast.error('Şifreler eşleşmiyor');
      return;
    }

    // Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(form.email)) {
      toast.error('Geçerli bir email adresi girin');
      return;
    }

    setCreating(true);
    try {
      // 1. Create auth user with admin metadata
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: form.email,
        password: form.password,
        options: {
          data: {
            user_type: 'admin',
            name: form.name
          }
        }
      });

      if (authError) throw authError;

      // 2. Create admin record
      const { error: adminError } = await supabase
        .from('admins')
        .insert({
          user_id: authData.user.id,
          name: form.name,
          email: form.email,
          role: 'super_admin',
          permissions: {
            manage_companies: true,
            manage_users: true,
            manage_jobs: true,
            manage_subscriptions: true,
            manage_admins: true,
            view_reports: true,
            manage_payments: true
          }
        });

      if (adminError) {
        // Rollback - delete auth user if admin creation fails
        await supabase.auth.admin.deleteUser(authData.user.id);
        throw adminError;
      }

      toast.success('Admin hesabı başarıyla oluşturuldu!');
      
      // Auto login
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: form.email,
        password: form.password
      });

      if (!signInError) {
        navigate('/admin/dashboard');
      } else {
        navigate('/admin/login');
      }
    } catch (error) {
      console.error('Admin creation error:', error);
      toast.error(error.message || 'Admin oluşturulamadı');
    } finally {
      setCreating(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  if (hasAdmins) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-blue-900 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="bg-white rounded-2xl shadow-2xl p-8">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-purple-100 rounded-full mb-4">
              <Shield className="w-10 h-10 text-purple-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">İlk Admin Kurulumu</h1>
            <p className="text-gray-600 mt-2">Platform için ilk admin hesabını oluşturun</p>
          </div>

          {/* Info */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <div className="flex gap-3">
              <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium text-blue-900">Önemli Bilgi</h4>
                <p className="text-sm text-blue-700 mt-1">
                  Bu sayfa sadece sistemde hiç admin yokken görüntülenir. 
                  Oluşturacağınız hesap süper admin yetkilerine sahip olacaktır.
                </p>
              </div>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Setup Key */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Kurulum Anahtarı
              </label>
              <div className="relative">
                <Shield className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="password"
                  value={setupKey}
                  onChange={(e) => setSetupKey(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                  placeholder="Güvenlik anahtarını girin"
                  required
                />
              </div>
              <p className="mt-1 text-xs text-gray-500">
                Bu anahtarı sistem yöneticisinden alın
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ad Soyad
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm({...form, name: e.target.value})}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                  placeholder="Admin User"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                E-posta Adresi
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({...form, email: e.target.value})}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                  placeholder="admin@platform.com"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Şifre
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="password"
                  value={form.password}
                  onChange={(e) => setForm({...form, password: e.target.value})}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                  placeholder="En az 8 karakter"
                  required
                  minLength={8}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Şifre Tekrar
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="password"
                  value={form.confirmPassword}
                  onChange={(e) => setForm({...form, confirmPassword: e.target.value})}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                  placeholder="Şifreyi tekrar girin"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={creating}
              className="w-full inline-flex items-center justify-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {creating ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Admin oluşturuluyor...
                </>
              ) : (
                <>
                  <CheckCircle className="w-5 h-5" />
                  Admin Hesabı Oluştur
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}