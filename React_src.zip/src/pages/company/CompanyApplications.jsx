import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useCompany } from "../../contexts/CompanyContext";
import supabase from "../../utils/supabaseClient";
import { toast } from "react-hot-toast";
import {
  Users, Loader2, Search, Filter, Calendar, Clock,
  CheckCircle, XCircle, AlertCircle, FileText, Eye,
  Briefcase, GraduationCap, Mail, Phone, MessageSquare,
  Download, RefreshCw, ChevronDown, User
} from "lucide-react";

// StatusBadge Component
const StatusBadge = ({ status }) => {
  const statusConfig = {
    pending: { 
      color: "bg-yellow-100 text-yellow-800 border-yellow-200", 
      icon: Clock, 
      text: "Beklemede" 
    },
    accepted: { 
      color: "bg-green-100 text-green-800 border-green-200", 
      icon: CheckCircle, 
      text: "Kabul Edildi" 
    },
    rejected: { 
      color: "bg-red-100 text-red-800 border-red-200", 
      icon: XCircle, 
      text: "Reddedildi" 
    }
  };

  const config = statusConfig[status] || statusConfig.pending;
  const Icon = config.icon;

  return (
    <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium border ${config.color}`}>
      <Icon className="w-3 h-3" />
      {config.text}
    </span>
  );
};


// Application Card Component
const ApplicationCard = ({ application, type, onUpdateStatus, onViewDetails, updating }) => {
  const [showMessage, setShowMessage] = useState(false);
  const isJob = type === 'job';
  
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-200">
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-start gap-4 flex-1">
          <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-blue-600 rounded-full flex items-center justify-center text-white font-semibold text-lg">
            {application.profile?.full_name?.charAt(0)?.toUpperCase() || "?"}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-1">
              <h3 className="font-semibold text-lg text-gray-900">
                {application.profile?.full_name || "İsimsiz Kullanıcı"}
              </h3>
              <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                isJob ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700'
              }`}>
                {isJob ? <Briefcase className="w-3 h-3" /> : <GraduationCap className="w-3 h-3" />}
                {isJob ? 'İş İlanı' : 'Staj İlanı'}
              </div>
            </div>
            
            <p className="text-sm font-medium text-gray-700 mb-2">
              {isJob ? application.job?.title : application.internship?.title}
              <span className="text-gray-500 ml-2">• {isJob ? application.job?.department : application.internship?.department}</span>
            </p>

            <div className="space-y-1">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Mail className="w-4 h-4" />
                {application.profile?.email || "E-posta yok"}
              </div>
              {application.profile?.phone && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Phone className="w-4 h-4" />
                  {application.profile.phone}
                </div>
              )}
              {application.profile?.department && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <GraduationCap className="w-4 h-4" />
                  {application.profile.department} - {application.profile.year || "?"}.Sınıf
                </div>
              )}
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <Calendar className="w-4 h-4" />
                {new Date(application.applied_at || application.created_at).toLocaleDateString('tr-TR', {
                  day: 'numeric',
                  month: 'long',
                  year: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </div>
            </div>
          </div>
        </div>
        <StatusBadge status={application.status} />
      </div>

      {/* Ön Yazı / Motivasyon Mektubu */}
      {(application.cover_letter || application.motivation_letter) && (
        <div className="mb-4">
          <button
            onClick={() => setShowMessage(!showMessage)}
            className="flex items-center gap-2 text-sm font-medium text-purple-600 hover:text-purple-700 transition-colors"
          >
            <MessageSquare className="w-4 h-4" />
            {isJob ? 'Ön Yazı' : 'Motivasyon Mektubu'}
            <span className="text-gray-400">{showMessage ? '▲' : '▼'}</span>
          </button>
          {showMessage && (
            <div className="mt-3 p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-700 whitespace-pre-wrap">
                {application.cover_letter || application.motivation_letter}
              </p>
            </div>
          )}
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex gap-3 pt-4 border-t border-gray-100">
        {application.cv_url && (
          <a
            href={application.cv_url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm font-medium"
          >
            <FileText className="w-4 h-4" />
            CV Görüntüle
          </a>
        )}
        
        <button
          onClick={() => onViewDetails(application, type)}
          className="inline-flex items-center gap-2 px-4 py-2 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 transition-colors text-sm font-medium"
        >
          <Eye className="w-4 h-4" />
          Detaylar
        </button>

        {application.status === "pending" && (
          <div className="flex gap-2 ml-auto">
            <button
              onClick={() => onUpdateStatus(application.id, "accepted", type)}
              disabled={updating === application.id}
              className="inline-flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-medium disabled:opacity-50"
            >
              {updating === application.id ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <CheckCircle className="w-4 h-4" />
              )}
              Kabul Et
            </button>
            <button
              onClick={() => onUpdateStatus(application.id, "rejected", type)}
              disabled={updating === application.id}
              className="inline-flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm font-medium disabled:opacity-50"
            >
              {updating === application.id ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <XCircle className="w-4 h-4" />
              )}
              Reddet
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default function CompanyApplications() {
  const { companyId } = useAuth();
  const { company } = useCompany();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [applications, setApplications] = useState([]);
  const [filteredApplications, setFilteredApplications] = useState([]);
  const [updatingStatus, setUpdatingStatus] = useState(null);
  
  // Filters
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterType, setFilterType] = useState("all");
  const [sortBy, setSortBy] = useState("newest");
  
  // Stats
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    accepted: 0,
    rejected: 0,
    jobApplications: 0,
    internshipApplications: 0
  });

  useEffect(() => {
    if (companyId) {
      fetchApplications();
    }
  }, [companyId]);

  useEffect(() => {
    filterAndSortApplications();
  }, [applications, searchTerm, filterStatus, filterType, sortBy]);

  const fetchApplications = async () => {
    setLoading(true);
    try {
      // Önce şirketin ilanlarını al
      const { data: companyJobs } = await supabase
        .from("jobs")
        .select("id")
        .eq("company_id", companyId);

      const jobIds = companyJobs?.map(job => job.id) || [];

      // İş başvuruları
      let jobApps = [];
      if (jobIds.length > 0) {
        const { data, error } = await supabase
          .from("job_applications")
          .select(`
            *,
            profile:user_id(
              id,
              full_name,
              email,
              phone,
              department,
              year
            ),
            job:job_id(
              id,
              title,
              department,
              location
            )
          `)
          .in("job_id", jobIds)
          .order("applied_at", { ascending: false });
        
        if (error) {
          console.error("İş başvuruları hatası:", error);
        } else {
          jobApps = data || [];
        }
      }

      // Staj ilanlarını al
      const { data: companyInternships } = await supabase
        .from("internships")
        .select("id")
        .eq("company_id", companyId);

      const internshipIds = companyInternships?.map(internship => internship.id) || [];

      // Staj başvuruları
      let internshipApps = [];
      if (internshipIds.length > 0) {
        const { data, error } = await supabase
          .from("internship_applications")
          .select(`
            *,
            profile:user_id(
              id,
              full_name,
              email,
              phone,
              department,
              year
            ),
            internship:internship_id(
              id,
              title,
              department,
              location
            )
          `)
          .in("internship_id", internshipIds)
          .order("applied_at", { ascending: false });
        
        if (error) {
          console.error("Staj başvuruları hatası:", error);
        } else {
          internshipApps = data || [];
        }
      }

      // Tüm başvuruları birleştir
      const allApplications = [
        ...jobApps.map(app => ({ 
          ...app, 
          type: 'job', 
          applied_at: app.applied_at || app.created_at,
          job_id: app.job_id 
        })),
        ...internshipApps.map(app => ({ 
          ...app, 
          type: 'internship', 
          applied_at: app.applied_at,
          internship_id: app.internship_id 
        }))
      ];

      // Tarihe göre sırala
      allApplications.sort((a, b) => new Date(b.applied_at) - new Date(a.applied_at));

      setApplications(allApplications);

      // İstatistikleri hesapla
      const jobAppsCount = jobApps.length;
      const internshipAppsCount = internshipApps.length;
      const totalCount = jobAppsCount + internshipAppsCount;
      
      const pendingCount = allApplications.filter(app => app.status === 'pending').length;
      const acceptedCount = allApplications.filter(app => app.status === 'accepted').length;
      const rejectedCount = allApplications.filter(app => app.status === 'rejected').length;

      setStats({
        total: totalCount,
        pending: pendingCount,
        accepted: acceptedCount,
        rejected: rejectedCount,
        jobApplications: jobAppsCount,
        internshipApplications: internshipAppsCount
      });

    } catch (error) {
      console.error("Başvuru getirme hatası:", error);
      toast.error("Başvurular yüklenemedi");
    } finally {
      setLoading(false);
    }
  };

  const filterAndSortApplications = () => {
    let filtered = [...applications];

    // Arama filtresi
    if (searchTerm) {
      filtered = filtered.filter(app => 
        app.profile?.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        app.profile?.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (app.type === 'job' ? app.job?.title : app.internship?.title)?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Durum filtresi
    if (filterStatus !== "all") {
      filtered = filtered.filter(app => app.status === filterStatus);
    }

    // Tip filtresi
    if (filterType !== "all") {
      filtered = filtered.filter(app => app.type === filterType);
    }

    // Sıralama
    switch(sortBy) {
      case "newest":
        filtered.sort((a, b) => new Date(b.applied_at) - new Date(a.applied_at));
        break;
      case "oldest":
        filtered.sort((a, b) => new Date(a.applied_at) - new Date(b.applied_at));
        break;
      case "name":
        filtered.sort((a, b) => (a.profile?.full_name || "").localeCompare(b.profile?.full_name || ""));
        break;
    }

    setFilteredApplications(filtered);
  };

  const updateApplicationStatus = async (applicationId, newStatus, type) => {
    setUpdatingStatus(applicationId);
    try {
      const table = type === 'job' ? 'job_applications' : 'internship_applications';
      
      const { error } = await supabase
        .from(table)
        .update({ 
          status: newStatus,
          updated_at: new Date().toISOString()
        })
        .eq("id", applicationId);

      if (error) throw error;

      // State'i güncelle
      setApplications(prev =>
        prev.map(app =>
          app.id === applicationId ? { ...app, status: newStatus } : app
        )
      );

      // İstatistikleri güncelle
      const oldStatus = applications.find(app => app.id === applicationId)?.status;
      setStats(prev => ({
        ...prev,
        [oldStatus]: prev[oldStatus] - 1,
        [newStatus]: prev[newStatus] + 1
      }));

      toast.success(
        newStatus === "accepted" ? "Başvuru kabul edildi" :
        newStatus === "rejected" ? "Başvuru reddedildi" :
        "Durum güncellendi"
      );
    } catch (error) {
      console.error("Durum güncelleme hatası:", error);
      toast.error("Durum güncellenemedi");
    } finally {
      setUpdatingStatus(null);
    }
  };

  const viewApplicationDetails = (application, type) => {
    if (type === 'job') {
      navigate(`/company/jobs/${application.job_id}/applications`);
    } else {
      navigate(`/company/internships/${application.internship_id}/applications`);
    }
  };

  const refreshData = async () => {
    setRefreshing(true);
    await fetchApplications();
    setRefreshing(false);
    toast.success("Veriler güncellendi");
  };

  const exportApplications = () => {
    const csvContent = `
Başvuru Raporu - ${company?.name}
Oluşturulma: ${new Date().toLocaleString('tr-TR')}

Ad Soyad,E-posta,Telefon,Başvuru Tipi,İlan,Departman,Durum,Başvuru Tarihi
${filteredApplications.map(app => 
  `"${app.profile?.full_name || ''}","${app.profile?.email || ''}","${app.profile?.phone || ''}","${app.type === 'job' ? 'İş İlanı' : 'Staj'}","${app.type === 'job' ? app.job?.title : app.internship?.title}","${app.type === 'job' ? app.job?.department : app.internship?.department}","${
    app.status === 'pending' ? 'Beklemede' : 
    app.status === 'accepted' ? 'Kabul Edildi' : 
    'Reddedildi'
  }","${new Date(app.applied_at).toLocaleString('tr-TR')}"`
).join('\n')}
    `.trim();

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `basvurular-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-3">
                <Users className="w-8 h-8 text-purple-600" />
                Tüm Başvurular
              </h1>
              <p className="text-sm text-gray-600 mt-1">
                {company?.name} - İş ve staj başvurularını yönetin
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={refreshData}
                disabled={refreshing}
                className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
                Yenile
              </button>
              <button
                onClick={exportApplications}
                className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
              >
                <Download className="w-4 h-4" />
                CSV İndir
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* İstatistikler */}
        <div className="grid grid-cols-1 md:grid-cols-6 gap-4 mb-8">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-2">
              <Users className="w-8 h-8 text-gray-400" />
              <span className="text-2xl font-bold text-gray-900">{stats.total}</span>
            </div>
            <p className="text-sm text-gray-600">Toplam Başvuru</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-2">
              <Clock className="w-8 h-8 text-yellow-400" />
              <span className="text-2xl font-bold text-gray-900">{stats.pending}</span>
            </div>
            <p className="text-sm text-gray-600">Beklemede</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-2">
              <CheckCircle className="w-8 h-8 text-green-400" />
              <span className="text-2xl font-bold text-gray-900">{stats.accepted}</span>
            </div>
            <p className="text-sm text-gray-600">Kabul Edildi</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-2">
              <XCircle className="w-8 h-8 text-red-400" />
              <span className="text-2xl font-bold text-gray-900">{stats.rejected}</span>
            </div>
            <p className="text-sm text-gray-600">Reddedildi</p>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-2">
              <Briefcase className="w-8 h-8 text-blue-400" />
              <span className="text-2xl font-bold text-gray-900">{stats.jobApplications}</span>
            </div>
            <p className="text-sm text-gray-600">İş Başvurusu</p>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-2">
              <GraduationCap className="w-8 h-8 text-purple-400" />
              <span className="text-2xl font-bold text-gray-900">{stats.internshipApplications}</span>
            </div>
            <p className="text-sm text-gray-600">Staj Başvurusu</p>
          </div>
        </div>

        {/* Filtreler */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Arama */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Ad, e-posta veya ilan ara..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            {/* Durum Filtresi */}
            <div className="relative">
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="w-full appearance-none px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              >
                <option value="all">Tüm Durumlar</option>
                <option value="pending">Beklemede</option>
                <option value="accepted">Kabul Edildi</option>
                <option value="rejected">Reddedildi</option>
              </select>
              <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
            </div>

            {/* Tip Filtresi */}
            <div className="relative">
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="w-full appearance-none px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              >
                <option value="all">Tüm Tipler</option>
                <option value="job">İş İlanları</option>
                <option value="internship">Staj İlanları</option>
              </select>
              <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
            </div>

            {/* Sıralama */}
            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="w-full appearance-none px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              >
                <option value="newest">En Yeni</option>
                <option value="oldest">En Eski</option>
                <option value="name">İsme Göre</option>
              </select>
              <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Debug bilgisi - production'da kaldırılabilir */}
        {process.env.NODE_ENV === 'development' && (
          <div className="text-xs text-gray-400 mb-2">
            Debug: {applications.length} başvuru yüklendi
          </div>
        )}

        {/* Başvuru Listesi */}
        {filteredApplications.length === 0 ? (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
            <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {searchTerm || filterStatus !== "all" || filterType !== "all" 
                ? "Başvuru bulunamadı" 
                : "Henüz başvuru yok"}
            </h3>
            <p className="text-gray-600">
              {searchTerm || filterStatus !== "all" || filterType !== "all"
                ? "Farklı filtreler deneyin"
                : "İlanlarınıza henüz başvuru yapılmamış"}
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredApplications.map(application => (
              <ApplicationCard
                key={application.id}
                application={application}
                type={application.type}
                onUpdateStatus={updateApplicationStatus}
                onViewDetails={viewApplicationDetails}
                updating={updatingStatus}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
