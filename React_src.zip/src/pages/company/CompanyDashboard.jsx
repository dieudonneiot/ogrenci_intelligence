import { useEffect } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useCompany } from "../../contexts/CompanyContext";
import StatsCard from "../../components/company/StatsCard";
import { 
  Briefcase, Users, ClipboardList, UserCheck, 
  Plus, Building2, Loader2, FileText, Calendar, 
  Target, Award, BarChart, GraduationCap
} from "lucide-react";

const QuickAction = ({ icon: Icon, label, to, color }) => (
  <Link
    to={to}
    className={`flex items-center gap-3 p-4 rounded-lg border-2 border-gray-200 hover:border-${color}-500 hover:bg-${color}-50 transition-all group`}
  >
    <div className={`p-2 rounded-lg bg-${color}-100 group-hover:bg-${color}-200 transition-colors`}>
      <Icon className={`w-5 h-5 text-${color}-600`} />
    </div>
    <span className="font-medium text-gray-700 group-hover:text-gray-900">{label}</span>
  </Link>
);

export default function CompanyDashboard() {
  const { user } = useAuth();
  const { company, stats, loading, fetchStats } = useCompany();

  useEffect(() => {
    // Sayfa yüklendiğinde istatistikleri yenile
    fetchStats();
  }, []);

  const quickActions = [
    { icon: Plus, label: "Yeni İş İlanı", to: "/company/jobs/create", color: "blue" },
    { icon: ClipboardList, label: "İlanlarım", to: "/company/jobs", color: "purple" },
    { icon: Users, label: "Başvurular", to: "/company/applications", color: "green" },
    { icon: BarChart, label: "Raporlar", to: "/company/reports", color: "orange" }
  ];

  const recentActivity = [
    { type: "application", message: "Yeni bir başvuru aldınız", time: "5 dakika önce", icon: Users },
    { type: "job", message: "İlanınız onaylandı", time: "1 saat önce", icon: Briefcase },
    { type: "report", message: "Aylık raporunuz hazır", time: "2 saat önce", icon: FileText }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl">
                <Building2 className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  {loading ? (
                    <div className="w-48 h-6 bg-gray-200 rounded animate-pulse"></div>
                  ) : (
                    company?.name || "İşletme Paneli"
                  )}
                </h1>
                <p className="text-sm text-gray-600 mt-1">
                  Hoş geldiniz, {user?.user_metadata?.full_name || user?.email}
                </p>
              </div>
            </div>
            <div className="text-sm text-gray-500">
              <Calendar className="w-4 h-4 inline mr-1" />
              {new Date().toLocaleDateString('tr-TR', { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* İstatistikler */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatsCard
            icon={Briefcase}
            label="Aktif İş İlanı"
            value={stats.activeJobs}
            color="bg-purple-600"
            loading={loading}
          />
          <StatsCard
            icon={GraduationCap}
            label="Aktif Staj İlanı"
            value={stats.activeInternships}
            color="bg-blue-600"
            loading={loading}
          />
          <StatsCard
            icon={ClipboardList}
            label="Bekleyen Başvuru"
            value={stats.pendingApplications}
            color="bg-orange-600"
            trend={12}
            loading={loading}
          />
          <StatsCard
            icon={Users}
            label="Toplam Başvuru"
            value={stats.totalApplications}
            color="bg-green-600"
            loading={loading}
          />
        </div>

        {/* Hızlı İşlemler */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <Target className="w-5 h-5 text-gray-600" />
            Hızlı İşlemler
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {quickActions.map((action, idx) => (
              <QuickAction key={idx} {...action} />
            ))}
          </div>
        </div>

        {/* Ana İçerik */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Son Aktiviteler */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                <FileText className="w-5 h-5 text-gray-600" />
                Son Aktiviteler
              </h3>
              <Link
                to="/company/activities"
                className="text-sm text-blue-600 hover:text-blue-700 font-medium"
              >
                Tümünü Gör →
              </Link>
            </div>
            <div className="space-y-3">
              {recentActivity.map((activity, idx) => {
                const Icon = activity.icon;
                return (
                  <div key={idx} className="flex items-start gap-3 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                    <div className="p-2 bg-gray-100 rounded-lg">
                      <Icon className="w-4 h-4 text-gray-600" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-900">{activity.message}</p>
                      <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Performans Özeti */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                <Award className="w-5 h-5 text-gray-600" />
                Performans Özeti
              </h3>
              <Link
                to="/company/reports"
                className="text-sm text-blue-600 hover:text-blue-700 font-medium"
              >
                Detaylı Rapor →
              </Link>
            </div>
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-gray-600">İlan Görüntülenme</span>
                  <span className="text-sm font-semibold text-gray-900">2,450</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-blue-600 h-2 rounded-full" style={{ width: '75%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-gray-600">Başvuru Dönüşüm</span>
                  <span className="text-sm font-semibold text-gray-900">18%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-green-600 h-2 rounded-full" style={{ width: '18%' }}></div>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-gray-600">Ortalama Yanıt Süresi</span>
                  <span className="text-sm font-semibold text-gray-900">2.3 gün</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-purple-600 h-2 rounded-full" style={{ width: '90%' }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bilgi Kartı */}
        <div className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6 border border-blue-200">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-white rounded-lg shadow-sm">
              <FileText className="w-6 h-6 text-blue-600" />
            </div>
            <div className="flex-1">
              <h4 className="font-semibold text-gray-900 mb-1">
                İpucu: Daha fazla başvuru almak ister misiniz?
              </h4>
              <p className="text-sm text-gray-600 mb-3">
                İlan açıklamalarınızı detaylandırın ve şirket kültürünüzden bahsedin. 
                Detaylı ilanlar %40 daha fazla başvuru alıyor.
              </p>
              <Link
                to="/company/jobs/create"
                className="inline-flex items-center gap-2 text-sm font-medium text-blue-600 hover:text-blue-700"
              >
                Yeni ilan oluştur
                <Plus className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}