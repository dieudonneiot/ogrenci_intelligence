import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useCompany } from "../../contexts/CompanyContext";
import supabase from "../../utils/supabaseClient";
import JobCard from "../../components/company/JobCard";
import StatsCard from "../../components/company/StatsCard";
import { 
  Plus, Briefcase, Search, Filter, Loader2, 
  FileText, Users, Eye, TrendingUp, ChevronDown
} from "lucide-react";
import { toast } from "react-hot-toast";

export default function CompanyJobs() {
  const { companyId } = useAuth();
  const { company } = useCompany();
  const navigate = useNavigate();
  
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [sortBy, setSortBy] = useState("newest");
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    inactive: 0,
    totalApplications: 0
  });

  useEffect(() => {
    if (companyId) {
      fetchJobs();
    }
  }, [companyId, filterStatus]);

  const fetchJobs = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from("jobs")
        .select(`
          *,
          applications:job_applications(id, status)
        `)
        .eq("company_id", companyId)
        .order("created_at", { ascending: false });

      if (filterStatus !== "all") {
        query = query.eq("is_active", filterStatus === "active");
      }

      const { data, error } = await query;

      if (error) throw error;

      // Her ilan için başvuru sayılarını hesapla
      const jobsWithCounts = data.map(job => ({
        ...job,
        applications_count: job.applications?.length || 0,
        accepted_count: job.applications?.filter(app => app.status === 'accepted').length || 0,
        views_count: job.views_count || 0
      }));

      setJobs(jobsWithCounts);

      // İstatistikleri hesapla
      const activeCount = jobsWithCounts.filter(j => j.is_active).length;
      const inactiveCount = jobsWithCounts.filter(j => !j.is_active).length;
      const totalApps = jobsWithCounts.reduce((sum, j) => sum + j.applications_count, 0);

      setStats({
        total: jobsWithCounts.length,
        active: activeCount,
        inactive: inactiveCount,
        totalApplications: totalApps
      });
    } catch (error) {
      console.error("İlanları getirme hatası:", error);
      toast.error("İlanlar yüklenemedi");
    } finally {
      setLoading(false);
    }
  };

  const handleToggleStatus = async (jobId, newStatus) => {
    try {
      const { error } = await supabase
        .from("jobs")
        .update({ is_active: newStatus })
        .eq("id", jobId)
        .eq("company_id", companyId);

      if (error) throw error;

      toast.success(newStatus ? "İlan aktif edildi" : "İlan pasif edildi");
      fetchJobs();
    } catch (error) {
      console.error("Durum güncelleme hatası:", error);
      toast.error("Durum güncellenemedi");
    }
  };

  const handleEdit = (jobId) => {
    navigate(`/company/jobs/${jobId}/edit`);
  };

  const handleViewApplications = (jobId) => {
    navigate(`/company/jobs/${jobId}/applications`);
  };

  // Filtreleme ve sıralama
  const filteredJobs = jobs
    .filter(job =>
      job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      job.department.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      switch(sortBy) {
        case "newest":
          return new Date(b.created_at) - new Date(a.created_at);
        case "oldest":
          return new Date(a.created_at) - new Date(b.created_at);
        case "mostApplied":
          return b.applications_count - a.applications_count;
        default:
          return 0;
      }
    });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-3">
                <Briefcase className="w-8 h-8 text-purple-600" />
                İş İlanlarım
              </h1>
              <p className="text-sm text-gray-600 mt-1">
                {company?.name} - İş ilanlarınızı yönetin
              </p>
            </div>
            <Link
              to="/company/jobs/create"
              className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-medium"
            >
              <Plus className="w-5 h-5" />
              Yeni İlan
            </Link>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* İstatistikler */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <StatsCard
            icon={FileText}
            label="Toplam İlan"
            value={stats.total}
            color="bg-gray-600"
            size="small"
          />
          <StatsCard
            icon={TrendingUp}
            label="Aktif İlan"
            value={stats.active}
            color="bg-green-600"
            size="small"
          />
          <StatsCard
            icon={Eye}
            label="Pasif İlan"
            value={stats.inactive}
            color="bg-red-600"
            size="small"
          />
          <StatsCard
            icon={Users}
            label="Toplam Başvuru"
            value={stats.totalApplications}
            color="bg-blue-600"
            size="small"
          />
        </div>

        {/* Filtreler */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="İlan ara..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>
            
            <div className="flex gap-2">
              <button
                onClick={() => setFilterStatus("all")}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  filterStatus === "all"
                    ? "bg-purple-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Tümü
              </button>
              <button
                onClick={() => setFilterStatus("active")}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  filterStatus === "active"
                    ? "bg-purple-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Aktif
              </button>
              <button
                onClick={() => setFilterStatus("inactive")}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  filterStatus === "inactive"
                    ? "bg-purple-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Pasif
              </button>
            </div>

            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="appearance-none px-4 py-2 pr-8 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              >
                <option value="newest">En Yeni</option>
                <option value="oldest">En Eski</option>
                <option value="mostApplied">En Çok Başvuru</option>
              </select>
              <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* İlan Listesi */}
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
          </div>
        ) : filteredJobs.length === 0 ? (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
            <Briefcase className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {searchTerm ? "İlan bulunamadı" : "Henüz ilanınız yok"}
            </h3>
            <p className="text-gray-600 mb-6">
              {searchTerm 
                ? "Farklı arama terimleri deneyin" 
                : "İlk ilanınızı oluşturarak başlayın"}
            </p>
            {!searchTerm && (
              <Link
                to="/company/jobs/create"
                className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-medium"
              >
                <Plus className="w-5 h-5" />
                İlan Oluştur
              </Link>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredJobs.map(job => (
              <JobCard
                key={job.id}
                job={job}
                type="job"
                onEdit={handleEdit}
                onToggleStatus={handleToggleStatus}
                onViewApplications={handleViewApplications}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}