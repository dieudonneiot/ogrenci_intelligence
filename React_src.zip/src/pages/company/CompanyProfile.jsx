import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useCompany } from "../../contexts/CompanyContext";
import CompanyHeader from "../../components/company/CompanyHeader";
import supabase from "../../utils/supabaseClient";
import { toast } from "react-hot-toast";
import { 
  Building2, Camera, Save, Loader2, MapPin, Phone, Mail, 
  Globe, Linkedin, Twitter, Facebook, Instagram, FileText,
  Users, Calendar, Briefcase, Award, Image, X, Plus,
  AlertCircle, CheckCircle
} from "lucide-react";

const SECTORS = [
  "Yazılım", "Finans", "Eğitim", "Sağlık", "Üretim", 
  "Danışmanlık", "E-ticaret", "Turizm", "Medya", "Diğer"
];

const COMPANY_SIZES = [
  { value: "1-10", label: "1-10 Çalışan" },
  { value: "11-50", label: "11-50 Çalışan" },
  { value: "51-200", label: "51-200 Çalışan" },
  { value: "201-500", label: "201-500 Çalışan" },
  { value: "500+", label: "500+ Çalışan" }
];

export default function CompanyProfile() {
  const { companyId, user } = useAuth();
  const { company, fetchCompanyData } = useCompany();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: "",
    sector: "",
    phone: "",
    email: "",
    website: "",
    city: "",
    address: "",
    description: "",
    founded_year: "",
    employee_count: "",
    linkedin: "",
    twitter: "",
    facebook: "",
    instagram: "",
    logo_url: "",
    cover_image_url: ""
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const [uploadingCover, setUploadingCover] = useState(false);
  const [errors, setErrors] = useState({});
  const [showEditForm, setShowEditForm] = useState(false);

  useEffect(() => {
    if (company) {
      setForm({
        name: company.name || "",
        sector: company.sector || "",
        phone: company.phone || "",
        email: company.email || "",
        website: company.website || "",
        city: company.city || "",
        address: company.address || "",
        description: company.description || "",
        founded_year: company.founded_year || "",
        employee_count: company.employee_count || "",
        linkedin: company.linkedin || "",
        twitter: company.twitter || "",
        facebook: company.facebook || "",
        instagram: company.instagram || "",
        logo_url: company.logo_url || "",
        cover_image_url: company.cover_image_url || ""
      });
      setLoading(false);
    }
  }, [company]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: "" }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!form.name) newErrors.name = "Şirket adı zorunludur";
    if (!form.sector) newErrors.sector = "Sektör seçimi zorunludur";
    if (!form.phone) newErrors.phone = "Telefon numarası zorunludur";
    if (!form.city) newErrors.city = "Şehir zorunludur";
    
    if (form.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      newErrors.email = "Geçerli bir e-posta adresi giriniz";
    }
    
    if (form.website && !/^https?:\/\/.+/.test(form.website)) {
      newErrors.website = "URL http:// veya https:// ile başlamalıdır";
    }
    
    if (form.founded_year && (isNaN(form.founded_year) || form.founded_year < 1900 || form.founded_year > new Date().getFullYear())) {
      newErrors.founded_year = "Geçerli bir yıl giriniz";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleLogoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error("Lütfen bir resim dosyası seçin");
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      toast.error("Dosya boyutu 2MB'dan küçük olmalıdır");
      return;
    }

    setUploadingLogo(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${companyId}-logo-${Date.now()}.${fileExt}`;
      const filePath = `company-logos/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('uploads')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('uploads')
        .getPublicUrl(filePath);

      setForm(prev => ({ ...prev, logo_url: publicUrl }));
      
      // Direkt veritabanını güncelle
      await supabase
        .from("companies")
        .update({ logo_url: publicUrl })
        .eq("id", companyId);
      
      toast.success("Logo başarıyla yüklendi");
      await fetchCompanyData();
    } catch (error) {
      console.error("Logo yükleme hatası:", error);
      toast.error("Logo yüklenemedi");
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleCoverUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error("Lütfen bir resim dosyası seçin");
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error("Dosya boyutu 5MB'dan küçük olmalıdır");
      return;
    }

    setUploadingCover(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${companyId}-cover-${Date.now()}.${fileExt}`;
      const filePath = `company-covers/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('uploads')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('uploads')
        .getPublicUrl(filePath);

      setForm(prev => ({ ...prev, cover_image_url: publicUrl }));
      
      // Direkt veritabanını güncelle
      await supabase
        .from("companies")
        .update({ cover_image_url: publicUrl })
        .eq("id", companyId);
      
      toast.success("Kapak görseli başarıyla yüklendi");
      await fetchCompanyData();
    } catch (error) {
      console.error("Kapak görseli yükleme hatası:", error);
      toast.error("Kapak görseli yüklenemedi");
    } finally {
      setUploadingCover(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error("Lütfen zorunlu alanları doldurun");
      return;
    }

    setSaving(true);
    try {
      const { error } = await supabase
        .from("companies")
        .update({
          name: form.name,
          sector: form.sector,
          phone: form.phone,
          email: form.email || null,
          website: form.website || null,
          city: form.city,
          address: form.address || null,
          description: form.description || null,
          founded_year: form.founded_year ? parseInt(form.founded_year) : null,
          employee_count: form.employee_count || null,
          linkedin: form.linkedin || null,
          twitter: form.twitter || null,
          facebook: form.facebook || null,
          instagram: form.instagram || null,
          updated_at: new Date().toISOString()
        })
        .eq("id", companyId);

      if (error) throw error;

      toast.success("Şirket profili başarıyla güncellendi!");
      await fetchCompanyData();
      setShowEditForm(false);
    } catch (error) {
      console.error("Güncelleme hatası:", error);
      toast.error("Profil güncellenemedi: " + error.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Kapak ve Logo Yükleme Alanı */}
      <div className="relative">
        {/* Kapak Görseli */}
        <div className="relative h-64 bg-gradient-to-r from-purple-600 to-blue-600">
          {form.cover_image_url && (
            <img 
              src={form.cover_image_url} 
              alt="Kapak" 
              className="w-full h-full object-cover"
            />
          )}
          <div className="absolute inset-0 bg-black bg-opacity-30" />
          
          {/* Kapak Görseli Yükleme */}
          <label className="absolute bottom-4 right-4 cursor-pointer">
            <input
              type="file"
              accept="image/*"
              onChange={handleCoverUpload}
              className="hidden"
              disabled={uploadingCover}
            />
            <div className="flex items-center gap-2 px-4 py-2 bg-white/20 backdrop-blur-md text-white rounded-lg hover:bg-white/30 transition-colors">
              {uploadingCover ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Camera className="w-5 h-5" />
              )}
              <span className="text-sm font-medium">
                {uploadingCover ? "Yükleniyor..." : "Kapak Değiştir"}
              </span>
            </div>
          </label>
        </div>

        {/* Logo Yükleme */}
        <div className="absolute -bottom-16 left-8">
          <div className="relative">
            <div className="w-32 h-32 bg-white rounded-xl overflow-hidden border-4 border-white shadow-lg">
              {form.logo_url ? (
                <img 
                  src={form.logo_url} 
                  alt="Logo" 
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full bg-gray-100 flex items-center justify-center">
                  <Building2 className="w-12 h-12 text-gray-400" />
                </div>
              )}
            </div>
            <label className="absolute bottom-0 right-0 cursor-pointer">
              <input
                type="file"
                accept="image/*"
                onChange={handleLogoUpload}
                className="hidden"
                disabled={uploadingLogo}
              />
              <div className="p-2 bg-purple-600 text-white rounded-full hover:bg-purple-700 transition-colors">
                {uploadingLogo ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Camera className="w-4 h-4" />
                )}
              </div>
            </label>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-8">
        {/* Şirket Başlık Bilgileri */}
        {!showEditForm && (
          <CompanyHeader 
            company={company} 
            showEditButton={true}
            onEdit={() => setShowEditForm(true)}
            coverImage={false}
          />
        )}

        {/* Düzenleme Formu */}
        {showEditForm && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 mt-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-900">Şirket Bilgilerini Düzenle</h2>
              <button
                onClick={() => setShowEditForm(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Temel Bilgiler */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Temel Bilgiler</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Şirket Adı *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={form.name}
                      onChange={handleChange}
                      className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                        errors.name ? "border-red-500" : "border-gray-300"
                      }`}
                    />
                    {errors.name && (
                      <p className="mt-1 text-sm text-red-600">{errors.name}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Sektör *
                    </label>
                    <select
                      name="sector"
                      value={form.sector}
                      onChange={handleChange}
                      className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                        errors.sector ? "border-red-500" : "border-gray-300"
                      }`}
                    >
                      <option value="">Seçiniz</option>
                      {SECTORS.map(sector => (
                        <option key={sector} value={sector}>{sector}</option>
                      ))}
                    </select>
                    {errors.sector && (
                      <p className="mt-1 text-sm text-red-600">{errors.sector}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Kuruluş Yılı
                    </label>
                    <input
                      type="number"
                      name="founded_year"
                      value={form.founded_year}
                      onChange={handleChange}
                      placeholder="Örn: 2010"
                      min="1900"
                      max={new Date().getFullYear()}
                      className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                        errors.founded_year ? "border-red-500" : "border-gray-300"
                      }`}
                    />
                    {errors.founded_year && (
                      <p className="mt-1 text-sm text-red-600">{errors.founded_year}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Çalışan Sayısı
                    </label>
                    <select
                      name="employee_count"
                      value={form.employee_count}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                    >
                      <option value="">Seçiniz</option>
                      {COMPANY_SIZES.map(size => (
                        <option key={size.value} value={size.value}>{size.label}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* İletişim Bilgileri */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">İletişim Bilgileri</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Telefon *
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="tel"
                        name="phone"
                        value={form.phone}
                        onChange={handleChange}
                        placeholder="0XXX XXX XX XX"
                        className={`w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                          errors.phone ? "border-red-500" : "border-gray-300"
                        }`}
                      />
                    </div>
                    {errors.phone && (
                      <p className="mt-1 text-sm text-red-600">{errors.phone}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      E-posta
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="email"
                        name="email"
                        value={form.email}
                        onChange={handleChange}
                        placeholder="info@sirket.com"
                        className={`w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                          errors.email ? "border-red-500" : "border-gray-300"
                        }`}
                      />
                    </div>
                    {errors.email && (
                      <p className="mt-1 text-sm text-red-600">{errors.email}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Web Sitesi
                    </label>
                    <div className="relative">
                      <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="url"
                        name="website"
                        value={form.website}
                        onChange={handleChange}
                        placeholder="https://www.sirket.com"
                        className={`w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                          errors.website ? "border-red-500" : "border-gray-300"
                        }`}
                      />
                    </div>
                    {errors.website && (
                      <p className="mt-1 text-sm text-red-600">{errors.website}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Şehir *
                    </label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        name="city"
                        value={form.city}
                        onChange={handleChange}
                        placeholder="İstanbul"
                        className={`w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                          errors.city ? "border-red-500" : "border-gray-300"
                        }`}
                      />
                    </div>
                    {errors.city && (
                      <p className="mt-1 text-sm text-red-600">{errors.city}</p>
                    )}
                  </div>
                </div>

                <div className="mt-6">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Adres
                  </label>
                  <textarea
                    name="address"
                    value={form.address}
                    onChange={handleChange}
                    rows={2}
                    placeholder="Detaylı adres bilgisi"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
              </div>

              {/* Şirket Açıklaması */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Şirket Hakkında
                </label>
                <textarea
                  name="description"
                  value={form.description}
                  onChange={handleChange}
                  rows={4}
                  placeholder="Şirketiniz hakkında detaylı bilgi..."
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
                <p className="mt-1 text-sm text-gray-500">
                  Bu açıklama ilanlarınızda görüntülenecektir
                </p>
              </div>

              {/* Sosyal Medya */}
              <div>
                <h3 className="text-lg font-medium text-gray-900 mb-4">Sosyal Medya</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      LinkedIn
                    </label>
                    <div className="relative">
                      <Linkedin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="url"
                        name="linkedin"
                        value={form.linkedin}
                        onChange={handleChange}
                        placeholder="https://linkedin.com/company/..."
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Twitter
                    </label>
                    <div className="relative">
                      <Twitter className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="url"
                        name="twitter"
                        value={form.twitter}
                        onChange={handleChange}
                        placeholder="https://twitter.com/..."
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Facebook
                    </label>
                    <div className="relative">
                      <Facebook className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="url"
                        name="facebook"
                        value={form.facebook}
                        onChange={handleChange}
                        placeholder="https://facebook.com/..."
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Instagram
                    </label>
                    <div className="relative">
                      <Instagram className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="url"
                        name="instagram"
                        value={form.instagram}
                        onChange={handleChange}
                        placeholder="https://instagram.com/..."
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <div className="flex justify-end gap-4 pt-6 border-t border-gray-200">
                <button
                  type="button"
                  onClick={() => setShowEditForm(false)}
                  className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
                >
                  İptal
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="inline-flex items-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {saving ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Kaydediliyor...
                    </>
                  ) : (
                    <>
                      <Save className="w-5 h-5" />
                      Değişiklikleri Kaydet
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}