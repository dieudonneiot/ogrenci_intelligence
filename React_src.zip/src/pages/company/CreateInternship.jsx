import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useCompany } from "../../contexts/CompanyContext";
import supabase from "../../utils/supabaseClient";
import { toast } from "react-hot-toast";
import { 
  GraduationCap, Loader2, Plus, Calendar, MapPin, 
  Clock, Users, FileText, DollarSign, Gift, 
  AlertCircle, ArrowLeft, Briefcase
} from "lucide-react";

const DEPARTMENTS = [
  "Bilgisayar Mühendisliği",
  "Elektrik-Elektronik Mühendisliği", 
  "Makine Mühendisliği",
  "Endüstri Mühendisliği",
  "İşletme",
  "İnsan Kaynakları",
  "Pazarlama",
  "Muhasebe/Finans",
  "Hukuk",
  "Diğer"
];

const WORK_TYPES = [
  { value: "on-site", label: "Ofiste" },
  { value: "remote", label: "Uzaktan" },
  { value: "hybrid", label: "Hibrit" }
];

const DURATION_OPTIONS = [
  { value: 1, label: "1 Ay" },
  { value: 2, label: "2 Ay" },
  { value: 3, label: "3 Ay" },
  { value: 4, label: "4 Ay" },
  { value: 5, label: "5 Ay" },
  { value: 6, label: "6 Ay" },
  { value: 12, label: "12 Ay" }
];

export default function CreateInternship() {
  const { companyId, user } = useAuth();
  const { company } = useCompany();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    title: "",
    description: "",
    requirements: "",
    department: "",
    location: "",
    work_type: "on-site",
    duration_months: "",
    start_date: "",
    quota: "",
    monthly_stipend: "",
    benefits: "",
    deadline: "",
    is_paid: false,
    provides_certificate: true,
    possibility_of_employment: false
  });

  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm(prev => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: "" }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Trim whitespace from text fields
    if (!form.title.trim()) newErrors.title = "Başlık zorunludur";
    if (!form.description.trim()) newErrors.description = "Açıklama zorunludur";
    if (!form.requirements.trim()) newErrors.requirements = "Gereksinimler zorunludur";
    if (!form.department) newErrors.department = "Departman seçimi zorunludur";
    if (!form.location.trim()) newErrors.location = "Lokasyon zorunludur";
    if (!form.duration_months) newErrors.duration_months = "Süre seçimi zorunludur";
    if (!form.start_date) newErrors.start_date = "Başlangıç tarihi zorunludur";
    if (!form.quota) newErrors.quota = "Kontenjan zorunludur";
    if (!form.deadline) newErrors.deadline = "Son başvuru tarihi zorunludur";
    
    // Numeric validations
    const quotaNum = parseInt(form.quota);
    if (isNaN(quotaNum) || quotaNum < 1) {
      newErrors.quota = "Geçerli bir kontenjan giriniz (minimum 1)";
    }
    
    // Paid internship validation
    if (form.is_paid) {
      const stipendNum = parseFloat(form.monthly_stipend);
      if (isNaN(stipendNum)) {
        newErrors.monthly_stipend = "Geçerli bir ücret giriniz";
      } else if (stipendNum <= 0) {
        newErrors.monthly_stipend = "Ücret 0'dan büyük olmalıdır";
      }
    }

    // Date validations
    if (form.deadline) {
      const deadlineDate = new Date(form.deadline);
      if (deadlineDate < today) {
        newErrors.deadline = "Son başvuru tarihi bugünden ileri bir tarih olmalıdır";
      }
    }
    
    if (form.start_date) {
      const startDate = new Date(form.start_date);
      if (startDate < today) {
        newErrors.start_date = "Başlangıç tarihi bugünden ileri bir tarih olmalıdır";
      }
    }
    
    if (form.deadline && form.start_date) {
      const deadlineDate = new Date(form.deadline);
      const startDate = new Date(form.start_date);
      if (deadlineDate >= startDate) {
        newErrors.deadline = "Son başvuru tarihi, başlangıç tarihinden önce olmalıdır";
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error("Lütfen formdaki hataları düzeltin");
      return;
    }

    if (!companyId) {
      toast.error("Şirket bilgisi bulunamadı");
      return;
    }

    setLoading(true);

    try {
      const { error } = await supabase.from("internships").insert({
        title: form.title.trim(),
        description: form.description.trim(),
        requirements: form.requirements.trim(),
        department: form.department,
        location: form.location.trim(),
        work_type: form.work_type,
        duration_months: parseInt(form.duration_months),
        start_date: form.start_date,
        quota: parseInt(form.quota),
        monthly_stipend: form.is_paid ? parseFloat(form.monthly_stipend) : null,
        benefits: form.benefits.trim(),
        deadline: form.deadline,
        is_paid: form.is_paid,
        provides_certificate: form.provides_certificate,
        possibility_of_employment: form.possibility_of_employment,
        company_id: companyId,
        company_name: company?.name || "",
        created_by: user.id,
        is_active: true
      });

      if (error) throw error;

      toast.success("Staj ilanı başarıyla oluşturuldu!");
      navigate("/company/internships");
    } catch (error) {
      console.error("Staj ilanı oluşturma hatası:", error);
      toast.error("Staj ilanı oluşturulamadı: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/company/internships")}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-3">
                <GraduationCap className="w-8 h-8 text-purple-600" />
                Yeni Staj İlanı Oluştur
              </h1>
              <p className="text-sm text-gray-600 mt-1">
                {company?.name} için yeni staj ilanı
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Temel Bilgiler */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <FileText className="w-5 h-5 text-gray-600" />
                Temel Bilgiler
              </h3>
              
              <div className="grid grid-cols-1 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Başlık *
                  </label>
                  <input
                    type="text"
                    name="title"
                    value={form.title}
                    onChange={handleChange}
                    placeholder="Staj pozisyon başlığı"
                    className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                      errors.title ? "border-red-500" : "border-gray-300"
                    }`}
                  />
                  {errors.title && (
                    <p className="mt-1 text-sm text-red-600">{errors.title}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Açıklama *
                  </label>
                  <textarea
                    name="description"
                    value={form.description}
                    onChange={handleChange}
                    rows={3}
                    placeholder="Staj hakkında detaylı açıklama..."
                    className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                      errors.description ? "border-red-500" : "border-gray-300"
                    }`}
                  />
                  {errors.description && (
                    <p className="mt-1 text-sm text-red-600">{errors.description}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Gereksinimler *
                  </label>
                  <textarea
                    name="requirements"
                    value={form.requirements}
                    onChange={handleChange}
                    rows={3}
                    placeholder="Aranan nitelikler ve gereksinimler..."
                    className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                      errors.requirements ? "border-red-500" : "border-gray-300"
                    }`}
                  />
                  {errors.requirements && (
                    <p className="mt-1 text-sm text-red-600">{errors.requirements}</p>
                  )}
                </div>
              </div>
            </div>

            {/* Detay Bilgileri */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-gray-600" />
                Detay Bilgileri
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Departman *
                  </label>
                  <select
                    name="department"
                    value={form.department}
                    onChange={handleChange}
                    className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                      errors.department ? "border-red-500" : "border-gray-300"
                    }`}
                  >
                    <option value="">Seçiniz</option>
                    {DEPARTMENTS.map(dept => (
                      <option key={dept} value={dept}>{dept}</option>
                    ))}
                  </select>
                  {errors.department && (
                    <p className="mt-1 text-sm text-red-600">{errors.department}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Lokasyon *
                  </label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      name="location"
                      value={form.location}
                      onChange={handleChange}
                      placeholder="Şehir veya ilçe"
                      className={`w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                        errors.location ? "border-red-500" : "border-gray-300"
                      }`}
                    />
                  </div>
                  {errors.location && (
                    <p className="mt-1 text-sm text-red-600">{errors.location}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Çalışma Şekli *
                  </label>
                  <select
                    name="work_type"
                    value={form.work_type}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                  >
                    {WORK_TYPES.map(type => (
                      <option key={type.value} value={type.value}>{type.label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Staj Süresi *
                  </label>
                  <div className="relative">
                    <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <select
                      name="duration_months"
                      value={form.duration_months}
                      onChange={handleChange}
                      className={`w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                        errors.duration_months ? "border-red-500" : "border-gray-300"
                      }`}
                    >
                      <option value="">Seçiniz</option>
                      {DURATION_OPTIONS.map(option => (
                        <option key={option.value} value={option.value}>{option.label}</option>
                      ))}
                    </select>
                  </div>
                  {errors.duration_months && (
                    <p className="mt-1 text-sm text-red-600">{errors.duration_months}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Başlangıç Tarihi *
                  </label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="date"
                      name="start_date"
                      value={form.start_date}
                      onChange={handleChange}
                      min={new Date().toISOString().split('T')[0]}
                      className={`w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                        errors.start_date ? "border-red-500" : "border-gray-300"
                      }`}
                    />
                  </div>
                  {errors.start_date && (
                    <p className="mt-1 text-sm text-red-600">{errors.start_date}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Kontenjan *
                  </label>
                  <div className="relative">
                    <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="number"
                      name="quota"
                      value={form.quota}
                      onChange={handleChange}
                      min="1"
                      placeholder="Stajyer sayısı"
                      className={`w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                        errors.quota ? "border-red-500" : "border-gray-300"
                      }`}
                    />
                  </div>
                  {errors.quota && (
                    <p className="mt-1 text-sm text-red-600">{errors.quota}</p>
                  )}
                </div>
              </div>
            </div>

            {/* Ücret ve Yan Haklar */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-gray-600" />
                Ücret ve Yan Haklar
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    id="is_paid"
                    name="is_paid"
                    checked={form.is_paid}
                    onChange={handleChange}
                    className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
                  />
                  <label htmlFor="is_paid" className="text-sm font-medium text-gray-700">
                    Ücretli Staj
                  </label>
                </div>

                {form.is_paid && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Aylık Ücret *
                    </label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="number"
                        name="monthly_stipend"
                        value={form.monthly_stipend}
                        onChange={handleChange}
                        placeholder="Örn: 5000"
                        min="0"
                        step="100"
                        className={`w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                          errors.monthly_stipend ? "border-red-500" : "border-gray-300"
                        }`}
                      />
                    </div>
                    {errors.monthly_stipend && (
                      <p className="mt-1 text-sm text-red-600">{errors.monthly_stipend}</p>
                    )}
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Yan Haklar
                  </label>
                  <div className="relative">
                    <Gift className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                    <textarea
                      name="benefits"
                      value={form.benefits}
                      onChange={handleChange}
                      rows={2}
                      placeholder="Yemek, ulaşım, sigorta vb."
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      id="provides_certificate"
                      name="provides_certificate"
                      checked={form.provides_certificate}
                      onChange={handleChange}
                      className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
                    />
                    <label htmlFor="provides_certificate" className="text-sm font-medium text-gray-700">
                      Staj sertifikası verilir
                    </label>
                  </div>

                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      id="possibility_of_employment"
                      name="possibility_of_employment"
                      checked={form.possibility_of_employment}
                      onChange={handleChange}
                      className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500"
                    />
                    <label htmlFor="possibility_of_employment" className="text-sm font-medium text-gray-700">
                      İş imkanı sunulur
                    </label>
                  </div>
                </div>
              </div>
            </div>

            {/* Son Başvuru Tarihi */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Son Başvuru Tarihi *
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="date"
                  name="deadline"
                  value={form.deadline}
                  onChange={handleChange}
                  min={new Date().toISOString().split('T')[0]}
                  className={`w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                    errors.deadline ? "border-red-500" : "border-gray-300"
                  }`}
                />
              </div>
              {errors.deadline && (
                <p className="mt-1 text-sm text-red-600">{errors.deadline}</p>
              )}
            </div>

            {/* Uyarı */}
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <div className="flex gap-3">
                <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-medium text-amber-900">Önemli Bilgilendirme</h4>
                  <p className="text-sm text-amber-700 mt-1">
                    Staj ilanınız onaylandıktan sonra öğrencilere görünür olacaktır. 
                    İlan bilgilerini daha sonra düzenleyebilirsiniz.
                  </p>
                </div>
              </div>
            </div>

            {/* Submit Buttons */}
            <div className="flex justify-end gap-4 pt-6 border-t border-gray-200">
              <button
                type="button"
                onClick={() => navigate("/company/internships")}
                className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
              >
                İptal
              </button>
              <button
                type="submit"
                disabled={loading}
                className="inline-flex items-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Oluşturuluyor...
                  </>
                ) : (
                  <>
                    <Plus className="w-5 h-5" />
                    Staj İlanı Oluştur
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}