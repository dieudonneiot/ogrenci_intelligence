import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useCompany } from "../../contexts/CompanyContext";
import supabase from "../../utils/supabaseClient";
import { toast } from "react-hot-toast";
import { 
  Briefcase, Loader2, Plus, MapPin, Building2, 
  DollarSign, Clock, Calendar, FileText, Users,
  AlertCircle, ArrowLeft
} from "lucide-react";

const DEPARTMENTS = [
  "Yazılım Geliştirme",
  "Satış & Pazarlama",
  "İnsan Kaynakları",
  "Muhasebe & Finans",
  "Operasyon",
  "Müşteri Hizmetleri",
  "Ürün Yönetimi",
  "Tasarım",
  "Hukuk",
  "Diğer"
];

const WORK_TYPES = [
  { value: "full-time", label: "Tam Zamanlı" },
  { value: "part-time", label: "Yarı Zamanlı" },
  { value: "intern", label: "Stajyer" },
  { value: "freelance", label: "Freelance" }
];

const LOCATION_TYPES = [
  { value: "on-site", label: "Ofiste" },
  { value: "remote", label: "Uzaktan" },
  { value: "hybrid", label: "Hibrit" }
];

export default function CreateJob() {
  const { companyId, user } = useAuth();
  const { company } = useCompany();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    title: "",
    description: "",
    department: "",
    location: "",
    work_type: "on-site",
    type: "full-time",
    min_year: "",
    max_year: "",
    salary: "",
    benefits: "",
    contact_email: company?.email || "",
    deadline: "",
    is_remote: false
  });

  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setForm(prev => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value
    }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: "" }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!form.title) newErrors.title = "Pozisyon başlığı zorunludur";
    if (!form.description) newErrors.description = "İş tanımı zorunludur";
    if (!form.department) newErrors.department = "Departman seçimi zorunludur";
    if (!form.location) newErrors.location = "Lokasyon zorunludur";
    if (!form.deadline) newErrors.deadline = "Son başvuru tarihi zorunludur";
    if (!form.contact_email) newErrors.contact_email = "İletişim e-postası zorunludur";
    
    if (form.min_year && form.max_year && parseInt(form.min_year) > parseInt(form.max_year)) {
      newErrors.min_year = "Minimum yıl maksimum yıldan büyük olamaz";
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (form.deadline && new Date(form.deadline) < today) {
      newErrors.deadline = "Son başvuru tarihi bugünden ileri bir tarih olmalıdır";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      toast.error("Lütfen tüm zorunlu alanları doldurun");
      return;
    }

    if (!companyId || !company) {
      toast.error("Şirket bilgisi bulunamadı");
      return;
    }

    setLoading(true);

    try {
      // ÖNEMLİ: company alanına şirket adını yazıyoruz
      const { error } = await supabase.from("jobs").insert({
        title: form.title,
        description: form.description,
        department: form.department,
        company: company.name, // Mock değil, gerçek şirket adı
        location: form.location,
        work_type: form.work_type,
        type: form.type,
        min_year: form.min_year ? parseInt(form.min_year) : 0,
        max_year: form.max_year ? parseInt(form.max_year) : 5,
        salary: form.salary || "Belirtilmemiş",
        benefits: form.benefits || "",
        contact_email: form.contact_email,
        deadline: form.deadline,
        is_remote: form.work_type === "remote",
        is_active: true,
        company_id: companyId,
        created_by: user.id
      });

      if (error) throw error;

      toast.success("İş ilanı başarıyla oluşturuldu!");
      navigate("/company/jobs");
    } catch (error) {
      console.error("İlan oluşturma hatası:", error);
      toast.error("İlan oluşturulamadı: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/company/jobs")}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-3">
                <Briefcase className="w-8 h-8 text-purple-600" />
                Yeni İş İlanı Oluştur
              </h1>
              <p className="text-sm text-gray-600 mt-1">
                {company?.name} için yeni iş ilanı
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Temel Bilgiler */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <FileText className="w-5 h-5 text-gray-600" />
                Temel Bilgiler
              </h3>
              
              <div className="grid grid-cols-1 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Pozisyon Başlığı *
                  </label>
                  <input
                    type="text"
                    name="title"
                    value={form.title}
                    onChange={handleChange}
                    placeholder="Örn: Senior Yazılım Geliştirici"
                    className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                      errors.title ? "border-red-500" : "border-gray-300"
                    }`}
                  />
                  {errors.title && (
                    <p className="mt-1 text-sm text-red-600">{errors.title}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    İş Tanımı *
                  </label>
                  <textarea
                    name="description"
                    value={form.description}
                    onChange={handleChange}
                    rows={6}
                    placeholder="Pozisyon hakkında detaylı bilgi, sorumluluklar, gereksinimler..."
                    className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                      errors.description ? "border-red-500" : "border-gray-300"
                    }`}
                  />
                  {errors.description && (
                    <p className="mt-1 text-sm text-red-600">{errors.description}</p>
                  )}
                </div>
              </div>
            </div>

            {/* Detay Bilgileri */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-gray-600" />
                Detay Bilgileri
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Departman *
                  </label>
                  <select
                    name="department"
                    value={form.department}
                    onChange={handleChange}
                    className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                      errors.department ? "border-red-500" : "border-gray-300"
                    }`}
                  >
                    <option value="">Seçiniz</option>
                    {DEPARTMENTS.map(dept => (
                      <option key={dept} value={dept}>{dept}</option>
                    ))}
                  </select>
                  {errors.department && (
                    <p className="mt-1 text-sm text-red-600">{errors.department}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Lokasyon *
                  </label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      name="location"
                      value={form.location}
                      onChange={handleChange}
                      placeholder="Şehir veya ilçe"
                      className={`w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                        errors.location ? "border-red-500" : "border-gray-300"
                      }`}
                    />
                  </div>
                  {errors.location && (
                    <p className="mt-1 text-sm text-red-600">{errors.location}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Çalışma Şekli *
                  </label>
                  <select
                    name="work_type"
                    value={form.work_type}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                  >
                    {LOCATION_TYPES.map(type => (
                      <option key={type.value} value={type.value}>{type.label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Çalışma Tipi *
                  </label>
                  <select
                    name="type"
                    value={form.type}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                  >
                    {WORK_TYPES.map(type => (
                      <option key={type.value} value={type.value}>{type.label}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Deneyim ve Maaş */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <Users className="w-5 h-5 text-gray-600" />
                Deneyim ve Ücret
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Minimum Deneyim (Yıl)
                  </label>
                  <input
                    type="number"
                    name="min_year"
                    value={form.min_year}
                    onChange={handleChange}
                    min="0"
                    max="20"
                    placeholder="0"
                    className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                      errors.min_year ? "border-red-500" : "border-gray-300"
                    }`}
                  />
                  {errors.min_year && (
                    <p className="mt-1 text-sm text-red-600">{errors.min_year}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Maksimum Deneyim (Yıl)
                  </label>
                  <input
                    type="number"
                    name="max_year"
                    value={form.max_year}
                    onChange={handleChange}
                    min="0"
                    max="30"
                    placeholder="5"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Maaş Aralığı
                  </label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      name="salary"
                      value={form.salary}
                      onChange={handleChange}
                      placeholder="Örn: 25.000 - 35.000 TL"
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                    />
                  </div>
                </div>
              </div>

              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Yan Haklar
                </label>
                <textarea
                  name="benefits"
                  value={form.benefits}
                  onChange={handleChange}
                  rows={3}
                  placeholder="Yemek kartı, ulaşım, sağlık sigortası vb."
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
              </div>
            </div>

            {/* İletişim ve Tarih */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-gray-600" />
                İletişim ve Tarih
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    İletişim E-postası *
                  </label>
                  <input
                    type="email"
                    name="contact_email"
                    value={form.contact_email}
                    onChange={handleChange}
                    placeholder="hr@sirket.com"
                    className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                      errors.contact_email ? "border-red-500" : "border-gray-300"
                    }`}
                  />
                  {errors.contact_email && (
                    <p className="mt-1 text-sm text-red-600">{errors.contact_email}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Son Başvuru Tarihi *
                  </label>
                  <input
                    type="date"
                    name="deadline"
                    value={form.deadline}
                    onChange={handleChange}
                    min={new Date().toISOString().split('T')[0]}
                    className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 ${
                      errors.deadline ? "border-red-500" : "border-gray-300"
                    }`}
                  />
                  {errors.deadline && (
                    <p className="mt-1 text-sm text-red-600">{errors.deadline}</p>
                  )}
                </div>
              </div>
            </div>

            {/* Uyarı */}
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <div className="flex gap-3">
                <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-medium text-amber-900">Önemli Bilgilendirme</h4>
                  <p className="text-sm text-amber-700 mt-1">
                    İlanınız onaylandıktan sonra yayınlanacaktır. 
                    İlan bilgilerini daha sonra düzenleyebilirsiniz.
                  </p>
                </div>
              </div>
            </div>

            {/* Submit Buttons */}
            <div className="flex justify-end gap-4 pt-6 border-t border-gray-200">
              <button
                type="button"
                onClick={() => navigate("/company/jobs")}
                className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
              >
                İptal
              </button>
              <button
                type="submit"
                disabled={loading}
                className="inline-flex items-center gap-2 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Oluşturuluyor...
                  </>
                ) : (
                  <>
                    <Plus className="w-5 h-5" />
                    İlan Oluştur
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}