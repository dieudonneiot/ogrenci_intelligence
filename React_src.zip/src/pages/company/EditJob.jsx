import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import supabase from "../../utils/supabaseClient";
import { toast } from "react-hot-toast";
import { Briefcase, Loader2, Save } from "lucide-react";

const DEPARTMENTS = [
  "Bilgisayar Mühendisliği", "Elektrik-Elektronik", "Makine", "İşletme", "Endüstri", "Diğer"
];
const TYPES = [
  { value: "departmental", label: "Bölüm İçi" },
  { value: "part-time", label: "Part-Time" }
];
const WORK_TYPES = [
  { value: "remote", label: "Uzaktan" },
  { value: "on-site", label: "Ofis" },
  { value: "hybrid", label: "Hibrit" }
];

export default function EditJob() {
  const { id } = useParams();
  const { companyId } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    title: "",
    description: "",
    department: "",
    type: "",
    location: "",
    salary: "",
    work_type: "",
    is_remote: false,
    min_year: "",
    max_year: "",
    deadline: "",
    benefits: "",
    is_active: true,
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!id || !companyId) return;
    setLoading(true);
    supabase
      .from("jobs")
      .select("*")
      .eq("id", id)
      .eq("company_id", companyId)
      .single()
      .then(({ data, error }) => {
        if (error || !data) {
          toast.error("İlan bulunamadı veya yetkiniz yok.");
          navigate("/company/jobs");
          return;
        }
        setForm({
          title: data.title || "",
          description: data.description || "",
          department: data.department || "",
          type: data.type || "",
          location: data.location || "",
          salary: data.salary || "",
          work_type: data.work_type || "",
          is_remote: !!data.is_remote,
          min_year: data.min_year || "",
          max_year: data.max_year || "",
          deadline: data.deadline ? data.deadline.slice(0, 10) : "",
          benefits: data.benefits || "",
          is_active: data.is_active,
        });
        setLoading(false);
      });
  }, [id, companyId, navigate]);

  const handleChange = e => {
    const { name, value, type, checked } = e.target;
    setForm(f => ({
      ...f,
      [name]: type === "checkbox" ? checked : value
    }));
  };

  const handleSubmit = async e => {
    e.preventDefault();
    if (!form.title || !form.description || !form.department || !form.type || !form.location || !form.deadline) {
      toast.error("Zorunlu alanları doldurun.");
      return;
    }
    setSaving(true);

    const { error } = await supabase
      .from("jobs")
      .update({
        title: form.title,
        description: form.description,
        department: form.department,
        type: form.type,
        location: form.location,
        salary: form.salary,
        work_type: form.work_type,
        is_remote: form.is_remote,
        min_year: form.min_year ? Number(form.min_year) : null,
        max_year: form.max_year ? Number(form.max_year) : null,
        deadline: form.deadline,
        benefits: form.benefits,
        is_active: form.is_active,
      })
      .eq("id", id)
      .eq("company_id", companyId);

    setSaving(false);

    if (error) {
      toast.error("İlan güncellenemedi: " + error.message);
      return;
    }

    toast.success("İlan başarıyla güncellendi!");
    navigate("/company/jobs");
  };

  if (loading) {
    return (
      <div className="max-w-2xl mx-auto py-10 text-center">
        <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4" />
        Yükleniyor...
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto py-10">
      <h1 className="text-2xl font-bold mb-6 flex items-center gap-2">
        <Briefcase className="w-7 h-7 text-purple-600" />
        İlanı Düzenle
      </h1>
      <form onSubmit={handleSubmit} className="space-y-6 bg-white rounded-xl shadow-sm border border-gray-200 p-8">
        <div>
          <label className="block text-sm font-medium mb-2">Pozisyon Başlığı *</label>
          <input
            name="title"
            value={form.title}
            onChange={handleChange}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">Açıklama *</label>
          <textarea
            name="description"
            value={form.description}
            onChange={handleChange}
            rows={4}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            required
          />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-2">Departman *</label>
            <select
              name="department"
              value={form.department}
              onChange={handleChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
              required
            >
              <option value="">Seçiniz</option>
              {DEPARTMENTS.map(dep => (
                <option key={dep} value={dep}>{dep}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">İlan Türü *</label>
            <select
              name="type"
              value={form.type}
              onChange={handleChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
              required
            >
              <option value="">Seçiniz</option>
              {TYPES.map(t => (
                <option key={t.value} value={t.value}>{t.label}</option>
              ))}
            </select>
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">Lokasyon *</label>
          <input
            name="location"
            value={form.location}
            onChange={handleChange}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            required
          />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-2">Çalışma Şekli</label>
            <select
              name="work_type"
              value={form.work_type}
              onChange={handleChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            >
              <option value="">Seçiniz</option>
              {WORK_TYPES.map(w => (
                <option key={w.value} value={w.value}>{w.label}</option>
              ))}
            </select>
          </div>
          <div className="flex items-center gap-2 mt-7">
            <input
              type="checkbox"
              name="is_remote"
              checked={form.is_remote}
              onChange={handleChange}
              className="w-4 h-4"
              id="is_remote"
            />
            <label htmlFor="is_remote" className="text-sm">Uzaktan Çalışma</label>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-2">Minimum Sınıf</label>
            <input
              name="min_year"
              type="number"
              min={1}
              max={5}
              value={form.min_year}
              onChange={handleChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Maksimum Sınıf</label>
            <input
              name="max_year"
              type="number"
              min={1}
              max={5}
              value={form.max_year}
              onChange={handleChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">Son Başvuru Tarihi *</label>
          <input
            name="deadline"
            type="date"
            value={form.deadline}
            onChange={handleChange}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">Maaş (opsiyonel)</label>
          <input
            name="salary"
            value={form.salary}
            onChange={handleChange}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">Yan Haklar (opsiyonel)</label>
          <input
            name="benefits"
            value={form.benefits}
            onChange={handleChange}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
          />
        </div>
        <div className="flex items-center gap-2">
          <input
            type="checkbox"
            name="is_active"
            checked={form.is_active}
            onChange={handleChange}
            className="w-4 h-4"
            id="is_active"
          />
          <label htmlFor="is_active" className="text-sm">İlan Aktif</label>
        </div>
        <button
          type="submit"
          disabled={saving}
          className="w-full bg-purple-600 text-white py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors flex items-center justify-center disabled:opacity-50"
        >
          {saving ? <Loader2 className="animate-spin w-5 h-5 mr-2" /> : <Save className="w-5 h-5 mr-2" />}
          Kaydet
        </button>
      </form>
    </div>
  );
}