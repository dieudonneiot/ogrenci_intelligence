import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import supabase from "../../utils/supabaseClient";
import { 
  Loader2, User, FileText, ArrowLeft, Check, X, Clock, 
  Mail, Phone, Calendar, Download, Filter, Search,
  GraduationCap, AlertCircle, Eye, MessageSquare,
  CheckCircle, XCircle, Users
} from "lucide-react";
import { toast } from "react-hot-toast";

// Status Badge Component
const StatusBadge = ({ status }) => {
  const statusConfig = {
    pending: { 
      color: "bg-yellow-100 text-yellow-800 border-yellow-200", 
      icon: Clock, 
      text: "Beklemede" 
    },
    accepted: { 
      color: "bg-green-100 text-green-800 border-green-200", 
      icon: CheckCircle, 
      text: "Kabul Edildi" 
    },
    rejected: { 
      color: "bg-red-100 text-red-800 border-red-200", 
      icon: XCircle, 
      text: "Reddedildi" 
    }
  };

  const config = statusConfig[status] || statusConfig.pending;
  const Icon = config.icon;

  return (
    <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium border ${config.color}`}>
      <Icon className="w-3 h-3" />
      {config.text}
    </span>
  );
};

// Application Card Component
const ApplicationCard = ({ application, onUpdateStatus, updating }) => {
  const [showMotivation, setShowMotivation] = useState(false);
  
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-200">
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-start gap-4 flex-1">
          <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-blue-600 rounded-full flex items-center justify-center text-white font-semibold text-lg">
            {application.profile?.full_name?.charAt(0)?.toUpperCase() || "?"}
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-lg text-gray-900">
              {application.profile?.full_name || "İsimsiz Kullanıcı"}
            </h3>
            <div className="space-y-1 mt-2">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Mail className="w-4 h-4" />
                {application.profile?.email || "E-posta yok"}
              </div>
              {application.profile?.phone && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Phone className="w-4 h-4" />
                  {application.profile.phone}
                </div>
              )}
              {application.profile?.department && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <GraduationCap className="w-4 h-4" />
                  {application.profile.department} - {application.profile.year || "?"}.Sınıf
                </div>
              )}
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <Calendar className="w-4 h-4" />
                {new Date(application.applied_at || application.created_at).toLocaleDateString('tr-TR', {
                  day: 'numeric',
                  month: 'long',
                  year: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </div>
            </div>
          </div>
        </div>
        <StatusBadge status={application.status} />
      </div>

      {/* Motivasyon Mektubu */}
      {application.motivation_letter && (
        <div className="mb-4">
          <button
            onClick={() => setShowMotivation(!showMotivation)}
            className="flex items-center gap-2 text-sm font-medium text-purple-600 hover:text-purple-700 transition-colors"
          >
            <MessageSquare className="w-4 h-4" />
            Motivasyon Mektubu
            <span className="text-gray-400">{showMotivation ? '▲' : '▼'}</span>
          </button>
          {showMotivation && (
            <div className="mt-3 p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-700 whitespace-pre-wrap">
                {application.motivation_letter}
              </p>
            </div>
          )}
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex gap-3 pt-4 border-t border-gray-100">
        {application.cv_url && (
          <a
            href={application.cv_url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm font-medium"
          >
            <FileText className="w-4 h-4" />
            CV Görüntüle
          </a>
        )}
        
        {application.profile?.id && (
          <a
            href={`/profiles/${application.profile.id}`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 transition-colors text-sm font-medium"
          >
            <Eye className="w-4 h-4" />
            Profili Gör
          </a>
        )}

        {application.status === "pending" && (
          <div className="flex gap-2 ml-auto">
            <button
              onClick={() => onUpdateStatus(application.id, "accepted")}
              disabled={updating === application.id}
              className="inline-flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm font-medium disabled:opacity-50"
            >
              {updating === application.id ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Check className="w-4 h-4" />
              )}
              Kabul Et
            </button>
            <button
              onClick={() => onUpdateStatus(application.id, "rejected")}
              disabled={updating === application.id}
              className="inline-flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm font-medium disabled:opacity-50"
            >
              {updating === application.id ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <X className="w-4 h-4" />
              )}
              Reddet
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default function InternshipApplications() {
  const { id } = useParams();
  const { companyId } = useAuth();
  const navigate = useNavigate();

  const [internship, setInternship] = useState(null);
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [updatingStatus, setUpdatingStatus] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    accepted: 0,
    rejected: 0
  });

  useEffect(() => {
    if (!id || !companyId) return;
    fetchData();
  }, [id, companyId]);

  const fetchData = async () => {
    setLoading(true);
    try {
      // Staj bilgilerini kontrol et
      const { data: internshipData, error: internshipError } = await supabase
        .from("internships")
        .select("*")
        .eq("id", id)
        .eq("company_id", companyId)
        .single();

      if (internshipError || !internshipData) {
        toast.error("Staj ilanı bulunamadı veya yetkiniz yok");
        navigate("/company/internships");
        return;
      }

      setInternship(internshipData);

      // Başvuruları getir - user_id foreign key ile profiles tablosunu join et
      const { data: appData, error: appError } = await supabase
        .from("internship_applications")
        .select(`
          *,
          profile:user_id(
            id,
            full_name,
            email,
            phone,
            department,
            year
          )
        `)
        .eq("internship_id", id)
        .order("applied_at", { ascending: false });

      if (appError) {
        console.error("Başvuru getirme hatası:", appError);
        toast.error("Başvurular yüklenemedi");
      } else {
        setApplications(appData || []);
        
        // İstatistikleri hesapla
        const stats = {
          total: appData?.length || 0,
          pending: appData?.filter(app => app.status === 'pending').length || 0,
          accepted: appData?.filter(app => app.status === 'accepted').length || 0,
          rejected: appData?.filter(app => app.status === 'rejected').length || 0
        };
        setStats(stats);
      }
    } catch (error) {
      console.error("Veri yükleme hatası:", error);
      toast.error("Bir hata oluştu");
    } finally {
      setLoading(false);
    }
  };

  const updateApplicationStatus = async (applicationId, newStatus) => {
    setUpdatingStatus(applicationId);
    try {
      // Eğer kabul ediliyorsa, kontenjan kontrolü yap
      if (newStatus === 'accepted') {
        const acceptedCount = applications.filter(app => app.status === 'accepted').length;
        if (acceptedCount >= internship.quota) {
          toast.error(`Kontenjan doldu! (${internship.quota} kişi)`);
          setUpdatingStatus(null);
          return;
        }
      }

      const { error } = await supabase
        .from("internship_applications")
        .update({ 
          status: newStatus,
          updated_at: new Date().toISOString()
        })
        .eq("id", applicationId);

      if (error) throw error;

      // State'i güncelle
      setApplications(prev =>
        prev.map(app =>
          app.id === applicationId ? { ...app, status: newStatus } : app
        )
      );

      // İstatistikleri güncelle
      setStats(prev => {
        const oldStatus = applications.find(app => app.id === applicationId)?.status;
        return {
          ...prev,
          [oldStatus]: prev[oldStatus] - 1,
          [newStatus]: prev[newStatus] + 1
        };
      });

      toast.success(
        newStatus === "accepted" ? "Başvuru kabul edildi" :
        newStatus === "rejected" ? "Başvuru reddedildi" :
        "Durum güncellendi"
      );
    } catch (error) {
      console.error("Durum güncelleme hatası:", error);
      toast.error("Durum güncellenemedi");
    } finally {
      setUpdatingStatus(null);
    }
  };

  // Filtreleme
  const filteredApplications = applications.filter(app => {
    const matchesSearch = app.profile?.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         app.profile?.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || app.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/company/internships")}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-3">
                <GraduationCap className="w-8 h-8 text-purple-600" />
                {internship?.title} - Başvurular
              </h1>
              <p className="text-sm text-gray-600 mt-1">
                {internship?.department} • {internship?.location} • {internship?.duration_months} ay
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* İstatistikler */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-2">
              <Users className="w-8 h-8 text-gray-400" />
              <span className="text-2xl font-bold text-gray-900">{stats.total}</span>
            </div>
            <p className="text-sm text-gray-600">Toplam Başvuru</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-2">
              <Clock className="w-8 h-8 text-yellow-400" />
              <span className="text-2xl font-bold text-gray-900">{stats.pending}</span>
            </div>
            <p className="text-sm text-gray-600">Beklemede</p>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-2">
              <CheckCircle className="w-8 h-8 text-green-400" />
              <span className="text-2xl font-bold text-gray-900">{stats.accepted}</span>
            </div>
            <p className="text-sm text-gray-600">Kabul Edildi</p>
            <p className="text-xs text-gray-500 mt-1">
              Kontenjan: {stats.accepted}/{internship?.quota}
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-2">
              <XCircle className="w-8 h-8 text-red-400" />
              <span className="text-2xl font-bold text-gray-900">{stats.rejected}</span>
            </div>
            <p className="text-sm text-gray-600">Reddedildi</p>
          </div>
        </div>

        {/* Kontenjan Uyarısı */}
        {stats.accepted >= internship?.quota && (
          <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-6">
            <div className="flex gap-3">
              <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium text-orange-900">
                  Kontenjan Doldu!
                </h4>
                <p className="text-sm text-orange-700 mt-1">
                  Bu staj ilanı için belirlenen {internship.quota} kişilik kontenjan dolmuştur. 
                  Yeni başvuruları kabul edemezsiniz.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Filtreler */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="İsim veya e-posta ile ara..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setFilterStatus("all")}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  filterStatus === "all"
                    ? "bg-purple-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Tümü ({stats.total})
              </button>
              <button
                onClick={() => setFilterStatus("pending")}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  filterStatus === "pending"
                    ? "bg-purple-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Beklemede ({stats.pending})
              </button>
              <button
                onClick={() => setFilterStatus("accepted")}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  filterStatus === "accepted"
                    ? "bg-purple-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Kabul ({stats.accepted})
              </button>
              <button
                onClick={() => setFilterStatus("rejected")}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  filterStatus === "rejected"
                    ? "bg-purple-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Red ({stats.rejected})
              </button>
            </div>
          </div>
        </div>

        {/* Başvuru Listesi */}
        {filteredApplications.length === 0 ? (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
            <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {searchTerm || filterStatus !== "all" 
                ? "Başvuru bulunamadı" 
                : "Henüz başvuru yok"}
            </h3>
            <p className="text-gray-600">
              {searchTerm || filterStatus !== "all"
                ? "Farklı arama kriterleri deneyin"
                : "Bu staj ilanına henüz başvuru yapılmamış"}
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredApplications.map(application => (
              <ApplicationCard
                key={application.id}
                application={application}
                onUpdateStatus={updateApplicationStatus}
                updating={updatingStatus}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}