import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useCompany } from "../../contexts/CompanyContext";
import supabase from "../../utils/supabaseClient";
import JobCard from "../../components/company/JobCard";
import StatsCard from "../../components/company/StatsCard";
import { 
  GraduationCap, Plus, Search, Filter, Loader2, 
  FileText, Users, TrendingUp, Award, ChevronDown
} from "lucide-react";
import { toast } from "react-hot-toast";

export default function InternshipManagement() {
  const { companyId } = useAuth();
  const { company } = useCompany();
  const navigate = useNavigate();
  
  const [internships, setInternships] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [sortBy, setSortBy] = useState("newest");
  const [stats, setStats] = useState({
    total: 0,
    active: 0,
    totalApplications: 0,
    totalAccepted: 0
  });

  useEffect(() => {
    if (companyId) {
      fetchInternships();
    }
  }, [companyId, filterStatus]);

  const fetchInternships = async () => {
    setLoading(true);
    try {
      // Stajları getir
      let query = supabase
        .from("internships")
        .select(`
          *,
          applications:internship_applications(
            id,
            status
          )
        `)
        .eq("company_id", companyId)
        .order("created_at", { ascending: false });

      if (filterStatus !== "all") {
        query = query.eq("is_active", filterStatus === "active");
      }

      const { data, error } = await query;

      if (error) throw error;

      // Her staj için başvuru sayılarını hesapla
      const internshipsWithCounts = data.map(internship => ({
        ...internship,
        applications_count: internship.applications?.length || 0,
        accepted_count: internship.applications?.filter(app => app.status === 'accepted').length || 0
      }));

      setInternships(internshipsWithCounts);

      // İstatistikleri hesapla
      const activeCount = internshipsWithCounts.filter(i => i.is_active).length;
      const totalApps = internshipsWithCounts.reduce((sum, i) => sum + i.applications_count, 0);
      const totalAccepted = internshipsWithCounts.reduce((sum, i) => sum + i.accepted_count, 0);

      setStats({
        total: internshipsWithCounts.length,
        active: activeCount,
        totalApplications: totalApps,
        totalAccepted: totalAccepted
      });
    } catch (error) {
      console.error("Stajları getirme hatası:", error);
      toast.error("Stajlar yüklenemedi");
    } finally {
      setLoading(false);
    }
  };

  const handleToggleStatus = async (internshipId, newStatus) => {
    try {
      const { error } = await supabase
        .from("internships")
        .update({ is_active: newStatus })
        .eq("id", internshipId)
        .eq("company_id", companyId);

      if (error) throw error;

      toast.success(newStatus ? "Staj ilanı aktif edildi" : "Staj ilanı pasif edildi");
      fetchInternships();
    } catch (error) {
      console.error("Durum güncelleme hatası:", error);
      toast.error("Durum güncellenemedi");
    }
  };

  const handleEdit = (internshipId) => {
    navigate(`/company/internships/${internshipId}/edit`);
  };

  const handleViewApplications = (internshipId) => {
    navigate(`/company/internships/${internshipId}/applications`);
  };

  // Filtreleme ve sıralama
  const filteredInternships = internships
    .filter(internship =>
      internship.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      internship.department.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      switch(sortBy) {
        case "newest":
          return new Date(b.created_at) - new Date(a.created_at);
        case "oldest":
          return new Date(a.created_at) - new Date(b.created_at);
        case "mostApplied":
          return b.applications_count - a.applications_count;
        default:
          return 0;
      }
    });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-3">
                <GraduationCap className="w-8 h-8 text-purple-600" />
                Staj Yönetimi
              </h1>
              <p className="text-sm text-gray-600 mt-1">
                {company?.name} - Staj ilanlarını yönetin
              </p>
            </div>
            <Link
              to="/company/internships/create"
              className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-medium"
            >
              <Plus className="w-5 h-5" />
              Yeni Staj İlanı
            </Link>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* İstatistikler */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <StatsCard
            icon={FileText}
            label="Toplam Staj İlanı"
            value={stats.total}
            color="bg-gray-600"
            size="small"
          />
          <StatsCard
            icon={TrendingUp}
            label="Aktif İlan"
            value={stats.active}
            color="bg-green-600"
            size="small"
          />
          <StatsCard
            icon={Users}
            label="Toplam Başvuru"
            value={stats.totalApplications}
            color="bg-blue-600"
            size="small"
          />
          <StatsCard
            icon={Award}
            label="Kabul Edilen"
            value={stats.totalAccepted}
            color="bg-purple-600"
            size="small"
          />
        </div>

        {/* Filtreler */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Staj ilanı ara..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>
            
            <div className="flex gap-2">
              <button
                onClick={() => setFilterStatus("all")}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  filterStatus === "all"
                    ? "bg-purple-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Tümü
              </button>
              <button
                onClick={() => setFilterStatus("active")}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  filterStatus === "active"
                    ? "bg-purple-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Aktif
              </button>
              <button
                onClick={() => setFilterStatus("inactive")}
                className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                  filterStatus === "inactive"
                    ? "bg-purple-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                Pasif
              </button>
            </div>

            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="appearance-none px-4 py-2 pr-8 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              >
                <option value="newest">En Yeni</option>
                <option value="oldest">En Eski</option>
                <option value="mostApplied">En Çok Başvuru</option>
              </select>
              <ChevronDown className="absolute right-2 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Staj Listesi */}
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
          </div>
        ) : filteredInternships.length === 0 ? (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
            <GraduationCap className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {searchTerm ? "Staj ilanı bulunamadı" : "Henüz staj ilanınız yok"}
            </h3>
            <p className="text-gray-600 mb-6">
              {searchTerm 
                ? "Farklı arama terimleri deneyin" 
                : "İlk staj ilanınızı oluşturarak başlayın"}
            </p>
            {!searchTerm && (
              <Link
                to="/company/internships/create"
                className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-medium"
              >
                <Plus className="w-5 h-5" />
                Staj İlanı Oluştur
              </Link>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredInternships.map(internship => (
              <JobCard
                key={internship.id}
                job={internship}
                type="internship"
                onEdit={handleEdit}
                onToggleStatus={handleToggleStatus}
                onViewApplications={handleViewApplications}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}