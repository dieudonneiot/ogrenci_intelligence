import { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import supabase from "../../utils/supabaseClient";
import { Loader2, User, FileText, ArrowLeft, Check, X, Clock, Mail, Phone, Calendar } from "lucide-react";
import { toast } from "react-hot-toast";

export default function JobApplications() {
  const { id } = useParams(); // job id
  const { companyId } = useAuth();
  const navigate = useNavigate();

  const [job, setJob] = useState(null);
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [updatingStatus, setUpdatingStatus] = useState(null);

  useEffect(() => {
    if (!id || !companyId) return;
    fetchData();
  }, [id, companyId]);

  const fetchData = async () => {
    setLoading(true);
    try {
      // İlanı kontrol et
      const { data: jobData, error: jobError } = await supabase
        .from("jobs")
        .select("*")
        .eq("id", id)
        .eq("company_id", companyId)
        .single();

      if (jobError || !jobData) {
        toast.error("İlan bulunamadı veya yetkiniz yok.");
        navigate("/company/jobs");
        return;
      }

      setJob(jobData);

      // Başvuruları getir (profiles tablosu ile join)
      const { data: appData, error: appError } = await supabase
        .from("job_applications")
        .select(`
          *,
          profile:profiles(*)
        `)
        .eq("job_id", id)
        .order("created_at", { ascending: false });

      if (appError) {
        console.error("Başvuru getirme hatası:", appError);
        toast.error("Başvurular yüklenemedi");
      } else {
        setApplications(appData || []);
      }
    } catch (error) {
      console.error("Veri yükleme hatası:", error);
      toast.error("Bir hata oluştu");
    } finally {
      setLoading(false);
    }
  };

  const updateApplicationStatus = async (applicationId, newStatus) => {
    setUpdatingStatus(applicationId);
    try {
      const { error } = await supabase
        .from("job_applications")
        .update({ 
          status: newStatus,
          updated_at: new Date().toISOString()
        })
        .eq("id", applicationId);

      if (error) throw error;

      // State'i güncelle
      setApplications(prev =>
        prev.map(app =>
          app.id === applicationId ? { ...app, status: newStatus } : app
        )
      );

      toast.success(
        newStatus === "accepted" ? "Başvuru kabul edildi" :
        newStatus === "rejected" ? "Başvuru reddedildi" :
        "Durum güncellendi"
      );
    } catch (error) {
      console.error("Durum güncelleme hatası:", error);
      toast.error("Durum güncellenemedi");
    } finally {
      setUpdatingStatus(null);
    }
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      pending: { color: "bg-yellow-100 text-yellow-800", icon: Clock, text: "Beklemede" },
      accepted: { color: "bg-green-100 text-green-800", icon: Check, text: "Kabul Edildi" },
      rejected: { color: "bg-red-100 text-red-800", icon: X, text: "Reddedildi" }
    };

    const config = statusConfig[status] || statusConfig.pending;
    const Icon = config.icon;

    return (
      <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm font-medium ${config.color}`}>
        <Icon className="w-4 h-4" />
        {config.text}
      </span>
    );
  };

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto py-10 text-center">
        <Loader2 className="w-8 h-8 animate-spin mx-auto mb-4" />
        Yükleniyor...
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto py-10 px-4">
      <div className="flex items-center gap-4 mb-8">
        <button
          onClick={() => navigate("/company/jobs")}
          className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
          title="Geri"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="text-2xl font-bold">{job?.title} - Başvurular</h1>
          <p className="text-gray-600">{job?.department} • {job?.location}</p>
        </div>
      </div>

      {applications.length === 0 ? (
        <div className="bg-gray-50 rounded-xl p-12 text-center">
          <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-500 text-lg">Bu ilana henüz başvuru yapılmamış.</p>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <p className="text-sm text-gray-600">
              Toplam <span className="font-semibold text-gray-900">{applications.length}</span> başvuru
            </p>
          </div>

          {applications.map(app => (
            <div
              key={app.id}
              className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
            >
              <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold">
                    {app.profile?.full_name?.charAt(0)?.toUpperCase() || "?"}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg">
                      {app.profile?.full_name || "İsimsiz Kullanıcı"}
                    </h3>
                    <div className="space-y-1 mt-2">
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Mail className="w-4 h-4" />
                        {app.profile?.email || "E-posta yok"}
                      </div>
                      {app.profile?.phone && (
                        <div className="flex items-center gap-2 text-sm text-gray-600">
                          <Phone className="w-4 h-4" />
                          {app.profile.phone}
                        </div>
                      )}
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Calendar className="w-4 h-4" />
                        {new Date(app.created_at).toLocaleDateString("tr-TR", {
                          day: "numeric",
                          month: "long",
                          year: "numeric",
                          hour: "2-digit",
                          minute: "2-digit"
                        })}
                      </div>
                    </div>
                    
                    {app.cover_letter && (
                      <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                        <p className="text-sm font-medium text-gray-700 mb-1">Ön Yazı:</p>
                        <p className="text-sm text-gray-600">{app.cover_letter}</p>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex flex-col items-end gap-3">
                  {getStatusBadge(app.status)}
                  
                  <div className="flex gap-2">
                    {app.cv_url && (
                      <a
                        href={app.cv_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 px-3 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 text-sm font-medium transition-colors"
                      >
                        <FileText className="w-4 h-4" />
                        CV Görüntüle
                      </a>
                    )}
                  </div>

                  {app.status === "pending" && (
                    <div className="flex gap-2">
                      <button
                        onClick={() => updateApplicationStatus(app.id, "accepted")}
                        disabled={updatingStatus === app.id}
                        className="inline-flex items-center gap-1 px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm font-medium transition-colors disabled:opacity-50"
                      >
                        {updatingStatus === app.id ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Check className="w-4 h-4" />
                        )}
                        Kabul Et
                      </button>
                      <button
                        onClick={() => updateApplicationStatus(app.id, "rejected")}
                        disabled={updatingStatus === app.id}
                        className="inline-flex items-center gap-1 px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 text-sm font-medium transition-colors disabled:opacity-50"
                      >
                        {updatingStatus === app.id ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <X className="w-4 h-4" />
                        )}
                        Reddet
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
