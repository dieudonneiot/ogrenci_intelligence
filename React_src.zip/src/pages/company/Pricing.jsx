import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { useCompany } from "../../contexts/CompanyContext";
import { toast } from "react-hot-toast";
import { 
  Check, X, Zap, Crown, Building2, ArrowRight,
  Star, Shield, Rocket, Users, ChartBar, Phone,
  Mail, MessageCircle, Clock, Infinity, FileText,
  Filter, Target, Award, TrendingUp, CreditCard
} from "lucide-react";

const PACKAGES = [
  {
    id: "starter",
    name: "Başlangıç",
    description: "Küçük işletmeler için ideal",
    monthlyPrice: 1999,
    yearlyPrice: 19990,
    color: "purple",
    icon: Zap,
    popular: false,
    features: [
      { text: "5 aktif ilan", included: true },
      { text: "Temel raporlama", included: true },
      { text: "E-posta desteği", included: true },
      { text: "Standart listeleme", included: true },
      { text: "Aylık 50 CV görüntüleme", included: true },
      { text: "Öne çıkan ilanlar", included: false },
      { text: "Aday filtreleme araçları", included: false },
      { text: "Öncelikli destek", included: false },
      { text: "API erişimi", included: false },
      { text: "Özel entegrasyonlar", included: false }
    ],
    highlights: [
      "Hızlı başlangıç",
      "Kolay kullanım",
      "Temel özellikler"
    ]
  },
  {
    id: "professional",
    name: "Profesyonel",
    description: "Büyüyen şirketler için",
    monthlyPrice: 2999,
    yearlyPrice: 29990,
    color: "blue",
    icon: Crown,
    popular: true,
    features: [
      { text: "20 aktif ilan", included: true },
      { text: "Gelişmiş raporlama", included: true },
      { text: "Öncelikli destek (24 saat)", included: true },
      { text: "Öne çıkan ilanlar (5 adet)", included: true },
      { text: "Aday filtreleme araçları", included: true },
      { text: "Aylık 500 CV görüntüleme", included: true },
      { text: "Detaylı analitik", included: true },
      { text: "E-posta ve telefon desteği", included: true },
      { text: "API erişimi", included: false },
      { text: "Özel entegrasyonlar", included: false }
    ],
    highlights: [
      "En popüler paket",
      "Gelişmiş özellikler",
      "Öncelikli destek"
    ]
  },
  {
    id: "enterprise",
    name: "Kurumsal",
    description: "Büyük organizasyonlar için",
    monthlyPrice: 0,
    yearlyPrice: 0,
    customPrice: true,
    color: "purple",
    icon: Building2,
    popular: false,
    features: [
      { text: "Sınırsız ilan", included: true },
      { text: "Özel raporlar ve dashboard", included: true },
      { text: "7/24 dedicated destek", included: true },
      { text: "Sınırsız öne çıkan ilan", included: true },
      { text: "Gelişmiş filtreleme ve AI araçları", included: true },
      { text: "Sınırsız CV görüntüleme", included: true },
      { text: "API erişimi", included: true },
      { text: "Özel entegrasyonlar", included: true },
      { text: "Eğitim ve danışmanlık", included: true },
      { text: "SLA garantisi", included: true }
    ],
    highlights: [
      "Tamamen özelleştirilebilir",
      "Dedicated account manager",
      "Enterprise seviye güvenlik"
    ]
  }
];

const FAQS = [
  {
    question: "Paket değişikliği yapabilir miyim?",
    answer: "Evet, istediğiniz zaman üst pakete geçiş yapabilirsiniz. Alt pakete geçişler ise fatura döneminin sonunda gerçekleşir."
  },
  {
    question: "İptal politikanız nedir?",
    answer: "Aboneliğinizi istediğiniz zaman iptal edebilirsiniz. İptal işlemi mevcut fatura döneminin sonunda geçerli olur."
  },
  {
    question: "Ücretsiz deneme var mı?",
    answer: "Yeni kayıt olan şirketlere 14 gün ücretsiz deneme sunuyoruz. Kredi kartı bilgisi gerekmez."
  },
  {
    question: "Fatura nasıl kesilir?",
    answer: "Aylık veya yıllık ödeme seçenekleri sunuyoruz. Yıllık ödemede %17 indirim uygulanır."
  }
];

export default function Pricing() {
  const navigate = useNavigate();
  const { user, companyId } = useAuth();
  const { company } = useCompany();
  const [billingPeriod, setBillingPeriod] = useState("monthly");
  const [selectedPackage, setSelectedPackage] = useState(null);

  const handleSelectPackage = (packageId) => {
    if (!user || !companyId) {
      toast.error("Lütfen önce giriş yapın");
      navigate("/company/auth");
      return;
    }

    if (!company?.name) {
      toast.error("Lütfen önce şirket bilgilerinizi tamamlayın");
      navigate("/company/register");
      return;
    }

    if (packageId === "enterprise") {
      // Kurumsal paket için iletişim formu veya özel sayfa
      toast.success("Kurumsal paket için sizinle iletişime geçeceğiz");
      // TODO: İletişim formu veya özel kurumsal başvuru sayfasına yönlendir
      return;
    }

    setSelectedPackage(packageId);
    // TODO: Ödeme sayfasına yönlendir
    toast.success("Ödeme sayfasına yönlendiriliyorsunuz...");
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-purple-900 via-purple-800 to-blue-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              İşe Alım Süreçlerinizi Hızlandırın
            </h1>
            <p className="text-xl md:text-2xl text-purple-200 max-w-3xl mx-auto mb-8">
              Size en uygun paketi seçin, doğru yeteneklere ulaşın
            </p>
            
            {/* Billing Period Toggle */}
            <div className="inline-flex items-center bg-white/10 backdrop-blur-md rounded-full p-1 mb-12">
              <button
                onClick={() => setBillingPeriod("monthly")}
                className={`px-6 py-3 rounded-full font-medium transition-all ${
                  billingPeriod === "monthly"
                    ? "bg-white text-purple-900"
                    : "text-white hover:text-purple-200"
                }`}
              >
                Aylık
              </button>
              <button
                onClick={() => setBillingPeriod("yearly")}
                className={`px-6 py-3 rounded-full font-medium transition-all ${
                  billingPeriod === "yearly"
                    ? "bg-white text-purple-900"
                    : "text-white hover:text-purple-200"
                }`}
              >
                Yıllık
                <span className="ml-2 text-xs bg-green-500 text-white px-2 py-1 rounded-full">
                  %17 İndirim
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Pricing Cards */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-16 pb-20">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {PACKAGES.map((pkg) => {
            const Icon = pkg.icon;
            const isPopular = pkg.popular;
            
            return (
              <div
                key={pkg.id}
                className={`relative bg-white rounded-2xl shadow-xl overflow-hidden transform transition-all hover:scale-105 ${
                  isPopular ? "ring-4 ring-blue-500 ring-opacity-50" : ""
                }`}
              >
                {/* Popular Badge */}
                {isPopular && (
                  <div className="absolute top-0 right-0 bg-gradient-to-r from-blue-500 to-blue-600 text-white px-4 py-1 rounded-bl-lg">
                    <span className="text-sm font-semibold flex items-center gap-1">
                      <Star className="w-4 h-4" />
                      En Popüler
                    </span>
                  </div>
                )}

                <div className="p-8">
                  {/* Package Header */}
                  <div className="text-center mb-8">
                    <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full bg-${pkg.color}-100 mb-4`}>
                      <Icon className={`w-8 h-8 text-${pkg.color}-600`} />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">
                      {pkg.name}
                    </h3>
                    <p className="text-gray-600">{pkg.description}</p>
                  </div>

                  {/* Price */}
                  <div className="text-center mb-8">
                    {pkg.customPrice ? (
                      <div>
                        <p className="text-4xl font-bold text-gray-900">Özel Fiyat</p>
                        <p className="text-gray-600 mt-2">İletişime geçin</p>
                      </div>
                    ) : (
                      <div>
                        <p className="text-4xl font-bold text-gray-900">
                          ₺{billingPeriod === "monthly" ? pkg.monthlyPrice.toLocaleString() : pkg.yearlyPrice.toLocaleString()}
                        </p>
                        <p className="text-gray-600 mt-2">
                          {billingPeriod === "monthly" ? "/ay" : "/yıl"}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Highlights */}
                  <div className="mb-8 space-y-2">
                    {pkg.highlights.map((highlight, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm text-gray-700">
                        <Shield className="w-4 h-4 text-green-500" />
                        <span>{highlight}</span>
                      </div>
                    ))}
                  </div>

                  {/* Features */}
                  <ul className="space-y-4 mb-8">
                    {pkg.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-3">
                        {feature.included ? (
                          <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                        ) : (
                          <X className="w-5 h-5 text-gray-300 flex-shrink-0 mt-0.5" />
                        )}
                        <span className={`text-sm ${
                          feature.included ? "text-gray-700" : "text-gray-400"
                        }`}>
                          {feature.text}
                        </span>
                      </li>
                    ))}
                  </ul>

                  {/* CTA Button */}
                  <button
                    onClick={() => handleSelectPackage(pkg.id)}
                    className={`w-full py-4 rounded-lg font-semibold transition-all flex items-center justify-center gap-2 ${
                      isPopular
                        ? "bg-gradient-to-r from-blue-600 to-blue-700 text-white hover:from-blue-700 hover:to-blue-800"
                        : pkg.customPrice
                        ? "bg-gray-900 text-white hover:bg-gray-800"
                        : "bg-purple-600 text-white hover:bg-purple-700"
                    }`}
                  >
                    {pkg.customPrice ? "İletişime Geç" : "Paketi Seç"}
                    <ArrowRight className="w-5 h-5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Features Grid */}
      <div className="bg-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Tüm Paketlerde Standart Özellikler
            </h2>
            <p className="text-xl text-gray-600">
              Her pakette sunduğumuz temel özellikler
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: Shield,
                title: "Güvenli Altyapı",
                description: "SSL sertifikası ve veri güvenliği"
              },
              {
                icon: Clock,
                title: "Hızlı Yayınlama",
                description: "İlanlarınız anında yayında"
              },
              {
                icon: Users,
                title: "Aday Havuzu",
                description: "Binlerce nitelikli adaya erişim"
              },
              {
                icon: ChartBar,
                title: "Performans Takibi",
                description: "İlan performanslarını görüntüleme"
              },
              {
                icon: MessageCircle,
                title: "Mesajlaşma",
                description: "Adaylarla direkt iletişim"
              },
              {
                icon: FileText,
                title: "CV Yönetimi",
                description: "Başvuruları organize etme"
              }
            ].map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div key={index} className="text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-purple-100 mb-4">
                    <Icon className="w-8 h-8 text-purple-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600">
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            {[
              { value: "10K+", label: "Aktif Şirket" },
              { value: "50K+", label: "Aylık Başvuru" },
              { value: "%95", label: "Müşteri Memnuniyeti" },
              { value: "7/24", label: "Destek" }
            ].map((stat, index) => (
              <div key={index}>
                <p className="text-4xl font-bold mb-2">{stat.value}</p>
                <p className="text-purple-200">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* FAQ Section */}
      <div className="py-20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Sıkça Sorulan Sorular
          </h2>
          
          <div className="space-y-6">
            {FAQS.map((faq, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {faq.question}
                </h3>
                <p className="text-gray-600">
                  {faq.answer}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gray-900 text-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">
            Hemen Başlayın
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            14 gün ücretsiz deneyin, kredi kartı gerekmez
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => handleSelectPackage("starter")}
              className="inline-flex items-center gap-2 px-8 py-4 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-semibold"
            >
              <Rocket className="w-5 h-5" />
              Ücretsiz Başla
            </button>
            <button
              onClick={() => navigate("/company/contact")}
              className="inline-flex items-center gap-2 px-8 py-4 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors font-semibold border border-gray-700"
            >
              <Phone className="w-5 h-5" />
              Satış Ekibiyle Konuş
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}