import { useState } from "react";
import { useNavigate } from "react-router-dom";
import supabase from "../../utils/supabaseClient";
import { useAuth } from "../../contexts/AuthContext";
import { toast } from "react-hot-toast";
import { Building, Phone, MapPin, ShieldCheck, Loader2 } from "lucide-react";

const SECTORS = [
  "Yazılım", "Finans", "Eğitim", "Sağlık", "Üretim", "Danışmanlık", "Diğer"
];
const CITIES = [
  "İstanbul", "Ankara", "İzmir", "Bursa", "Antalya", "Adana", "Diğer"
];

export default function RegisterCompany() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: "",
    sector: "",
    tax_number: "",
    phone: "",
    city: ""
  });
  const [loading, setLoading] = useState(false);

  const handleChange = e => {
    setForm(f => ({ ...f, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async e => {
    e.preventDefault();
    if (!user) {
      toast.error("Giriş yapmalısınız");
      return;
    }
    if (!form.name || !form.sector || !form.tax_number || !form.phone || !form.city) {
      toast.error("Tüm alanları doldurun");
      return;
    }
    setLoading(true);

    // Benzersiz vergi no kontrolü
    const { count: taxCount } = await supabase
      .from("companies")
      .select("id", { count: "exact", head: true })
      .eq("tax_number", form.tax_number);

    if (taxCount > 0) {
      toast.error("Bu vergi numarası ile kayıtlı bir şirket zaten var.");
      setLoading(false);
      return;
    }

    // Şirket kaydı
    const { data: company, error: companyError } = await supabase
      .from("companies")
      .insert({
        name: form.name,
        sector: form.sector,
        tax_number: form.tax_number,
        phone: form.phone,
        city: form.city,
        verified: false
      })
      .select()
      .single();

    if (companyError) {
      toast.error("Şirket kaydı başarısız: " + companyError.message);
      setLoading(false);
      return;
    }

    // company_users tablosuna owner rolüyle kayıt
    const { error: userError } = await supabase
      .from("company_users")
      .insert({
        company_id: company.id,
        user_id: user.id,
        role: "owner",
        permissions: "all"
      });

    if (userError) {
      toast.error("Kullanıcı kaydı başarısız: " + userError.message);
      setLoading(false);
      return;
    }

    toast.success("Şirket kaydı başarılı!");
    navigate("/company/dashboard");
  };

  return (
    <div className="max-w-lg mx-auto py-12">
      <h1 className="text-3xl font-bold mb-6 flex items-center gap-2">
        <Building className="w-8 h-8 text-purple-600" />
        Şirket Kaydı
      </h1>
      <form onSubmit={handleSubmit} className="space-y-6 bg-white rounded-xl shadow-sm border border-gray-200 p-8">
        <div>
          <label className="block text-sm font-medium mb-2">Şirket Adı</label>
          <input
            name="name"
            value={form.name}
            onChange={handleChange}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">Sektör</label>
          <select
            name="sector"
            value={form.sector}
            onChange={handleChange}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            required
          >
            <option value="">Seçiniz</option>
            {SECTORS.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">Vergi Numarası</label>
          <input
            name="tax_number"
            value={form.tax_number}
            onChange={handleChange}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">Telefon</label>
          <div className="flex items-center">
            <Phone className="w-5 h-5 text-gray-400 mr-2" />
            <input
              name="phone"
              value={form.phone}
              onChange={handleChange}
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
              required
            />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">Şehir</label>
          <select
            name="city"
            value={form.city}
            onChange={handleChange}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500"
            required
          >
            <option value="">Seçiniz</option>
            {CITIES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <button
          type="submit"
          disabled={loading}
          className="w-full bg-purple-600 text-white py-3 rounded-lg font-semibold hover:bg-purple-700 transition-colors flex items-center justify-center disabled:opacity-50"
        >
          {loading ? <Loader2 className="animate-spin w-5 h-5 mr-2" /> : <ShieldCheck className="w-5 h-5 mr-2" />}
          Kaydı Tamamla
        </button>
      </form>
    </div>
  );
}