import { useState, useEffect } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { useCompany } from "../../contexts/CompanyContext";
import supabase from "../../utils/supabaseClient";
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  AreaChart, Area, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar
} from "recharts";
import {
  Download, Calendar, TrendingUp, TrendingDown, Users,
  Eye, FileText, Briefcase, Clock, Target, Award,
  Filter, ChevronDown, RefreshCw, Loader2, AlertCircle,
  CheckCircle, XCircle, ArrowUp, ArrowDown, Minus
} from "lucide-react";
import { toast } from "react-hot-toast";

// Renk paleti
const COLORS = ['#8b5cf6', '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#6366f1'];

// Metrik kartı komponenti
const MetricCard = ({ title, value, previousValue, icon: Icon, color, prefix = "", suffix = "" }) => {
  const change = previousValue ? ((value - previousValue) / previousValue * 100).toFixed(1) : 0;
  const isPositive = change > 0;
  const isNeutral = change == 0;

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between mb-4">
        <div className={`p-3 rounded-lg ${color} bg-opacity-10`}>
          <Icon className={`w-6 h-6 ${color.replace('bg-', 'text-')}`} />
        </div>
        {previousValue !== undefined && !isNeutral && (
          <div className={`flex items-center gap-1 text-sm ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
            {isPositive ? <ArrowUp className="w-4 h-4" /> : <ArrowDown className="w-4 h-4" />}
            <span className="font-medium">{Math.abs(change)}%</span>
          </div>
        )}
        {isNeutral && previousValue !== undefined && (
          <div className="flex items-center gap-1 text-sm text-gray-500">
            <Minus className="w-4 h-4" />
            <span className="font-medium">0%</span>
          </div>
        )}
      </div>
      <div className="text-2xl font-bold text-gray-900">
        {prefix}{value.toLocaleString('tr-TR')}{suffix}
      </div>
      <div className="text-sm text-gray-600 mt-1">{title}</div>
    </div>
  );
};

export default function Reports() {
  const { companyId } = useAuth();
  const { company } = useCompany();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [dateRange, setDateRange] = useState("last30days");
  const [reportType, setReportType] = useState("overview");
  
  // Metrikler
  const [metrics, setMetrics] = useState({
    totalViews: 0,
    uniqueVisitors: 0,
    totalApplications: 0,
    conversionRate: 0,
    avgResponseTime: 0,
    acceptanceRate: 0,
    activeJobs: 0,
    activeInternships: 0
  });

  const [previousMetrics, setPreviousMetrics] = useState({});
  const [chartData, setChartData] = useState({
    viewsTrend: [],
    applicationsTrend: [],
    departmentDistribution: [],
    responseTimeDistribution: [],
    conversionFunnel: []
  });

  useEffect(() => {
    if (companyId) {
      fetchReportData();
    }
  }, [companyId, dateRange]);

  const getDateRangeFilter = () => {
    const now = new Date();
    let startDate;

    switch(dateRange) {
      case 'today':
        startDate = new Date(now.setHours(0,0,0,0));
        break;
      case 'last7days':
        startDate = new Date(now.setDate(now.getDate() - 7));
        break;
      case 'last30days':
        startDate = new Date(now.setDate(now.getDate() - 30));
        break;
      case 'last90days':
        startDate = new Date(now.setDate(now.getDate() - 90));
        break;
      case 'thisYear':
        startDate = new Date(now.getFullYear(), 0, 1);
        break;
      default:
        startDate = new Date(now.setDate(now.getDate() - 30));
    }

    return startDate.toISOString();
  };

  const fetchReportData = async () => {
    setLoading(true);
    try {
      const startDate = getDateRangeFilter();

      // Önce şirketin ilanlarını al
      const { data: companyJobs } = await supabase
        .from('jobs')
        .select('id')
        .eq('company_id', companyId);

      const jobIds = companyJobs?.map(job => job.id) || [];

      // 1. İlan görüntüleme verileri
      let jobViews = [];
      if (jobIds.length > 0) {
        const { data } = await supabase
          .from('job_views')
          .select('*')
          .in('job_id', jobIds)
          .gte('viewed_at', startDate);
        jobViews = data || [];
      }

      // 2. Başvuru verileri
      let applications = [];
      if (jobIds.length > 0) {
        const { data } = await supabase
          .from('job_applications')
          .select(`
            *,
            job:job_id(title, department),
            profile:user_id(department, year)
          `)
          .in('job_id', jobIds)
          .gte('applied_at', startDate);
        applications = data || [];
      }

      // 3. Staj verileri
      const { data: companyInternships } = await supabase
        .from('internships')
        .select('id')
        .eq('company_id', companyId);

      const internshipIds = companyInternships?.map(i => i.id) || [];

      let internshipApps = [];
      if (internshipIds.length > 0) {
        const { data } = await supabase
          .from('internship_applications')
          .select(`
            *,
            internship:internship_id(title, department)
          `)
          .in('internship_id', internshipIds)
          .gte('applied_at', startDate);
        internshipApps = data || [];
      }

      // 4. Aktif ilanlar
      const { count: activeJobCount } = await supabase
        .from('jobs')
        .select('id', { count: 'exact', head: true })
        .eq('company_id', companyId)
        .eq('is_active', true);

      const { count: activeInternshipCount } = await supabase
        .from('internships')
        .select('id', { count: 'exact', head: true })
        .eq('company_id', companyId)
        .eq('is_active', true);

      // Metrikleri hesapla
      const uniqueVisitors = new Set(jobViews?.map(v => v.user_id || v.ip_address)).size;
      const totalApplications = (applications?.length || 0) + (internshipApps?.length || 0);
      const acceptedApplications = applications?.filter(a => a.status === 'accepted').length || 0;
      const conversionRate = jobViews?.length > 0 ? (totalApplications / jobViews.length * 100) : 0;
      
      // Ortalama yanıt süresi hesapla
      const responseTimesInHours = applications
        ?.filter(a => a.status !== 'pending' && a.updated_at)
        .map(a => {
          const applied = new Date(a.applied_at || a.created_at);
          const responded = new Date(a.updated_at);
          return (responded - applied) / (1000 * 60 * 60); // Saat cinsinden
        }) || [];
      
      const avgResponseTime = responseTimesInHours.length > 0
        ? responseTimesInHours.reduce((a, b) => a + b) / responseTimesInHours.length
        : 0;

      setMetrics({
        totalViews: jobViews?.length || 0,
        uniqueVisitors,
        totalApplications,
        conversionRate: conversionRate.toFixed(1),
        avgResponseTime: avgResponseTime.toFixed(1),
        acceptanceRate: totalApplications > 0 ? (acceptedApplications / totalApplications * 100).toFixed(1) : 0,
        activeJobs: activeJobCount || 0,
        activeInternships: activeInternshipCount || 0
      });

      // Grafik verilerini hazırla
      prepareChartData(jobViews, applications, internshipApps);

    } catch (error) {
      console.error('Rapor verisi yükleme hatası:', error);
      toast.error('Rapor verileri yüklenemedi');
    } finally {
      setLoading(false);
    }
  };

  const prepareChartData = (jobViews, applications, internshipApps) => {
    // 1. Görüntüleme trendi (son 7 gün)
    const viewsTrend = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      
      const dayViews = jobViews?.filter(v => 
        v.viewed_at && v.viewed_at.startsWith(dateStr)
      ).length || 0;

      viewsTrend.push({
        date: date.toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' }),
        views: dayViews
      });
    }

    // 2. Başvuru trendi (son 7 gün)
    const applicationsTrend = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      
      const dayApps = applications?.filter(a => 
        a.applied_at && a.applied_at.startsWith(dateStr)
      ).length || 0;

      applicationsTrend.push({
        date: date.toLocaleDateString('tr-TR', { day: 'numeric', month: 'short' }),
        applications: dayApps
      });
    }

    // 3. Departman dağılımı
    const deptCounts = {};
    applications?.forEach(app => {
      const dept = app.job?.department || 'Diğer';
      deptCounts[dept] = (deptCounts[dept] || 0) + 1;
    });

    const departmentDistribution = Object.entries(deptCounts).map(([dept, count]) => ({
      department: dept,
      count,
      percentage: applications.length > 0 ? ((count / applications.length) * 100).toFixed(1) : 0
    }));

    // 4. Dönüşüm hunisi
    const totalViews = jobViews?.length || 0;
    const totalApps = applications?.length || 0;
    const interviewed = applications?.filter(a => a.interview_date).length || 0;
    const accepted = applications?.filter(a => a.status === 'accepted').length || 0;

    const conversionFunnel = [
      { stage: 'Görüntüleme', count: totalViews },
      { stage: 'Başvuru', count: totalApps },
      { stage: 'Mülakat', count: interviewed },
      { stage: 'Kabul', count: accepted }
    ];

    setChartData({
      viewsTrend,
      applicationsTrend,
      departmentDistribution,
      conversionFunnel
    });
  };

  const refreshData = async () => {
    setRefreshing(true);
    await fetchReportData();
    setRefreshing(false);
    toast.success('Veriler güncellendi');
  };

  const exportReport = () => {
    // Raporu CSV olarak indir
    const csvContent = `
Şirket Raporu - ${company?.name}
Tarih Aralığı: ${dateRange}
Oluşturulma: ${new Date().toLocaleString('tr-TR')}

GENEL METRİKLER
Toplam Görüntüleme,${metrics.totalViews}
Benzersiz Ziyaretçi,${metrics.uniqueVisitors}
Toplam Başvuru,${metrics.totalApplications}
Dönüşüm Oranı,%${metrics.conversionRate}
Ortalama Yanıt Süresi,${metrics.avgResponseTime} saat
Kabul Oranı,%${metrics.acceptanceRate}

DEPARTMAN DAĞILIMI
${chartData.departmentDistribution.map(d => `${d.department},${d.count}`).join('\n')}
    `.trim();

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `rapor-${company?.name}-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-3">
                <BarChart className="w-8 h-8 text-purple-600" />
                Raporlar ve Analizler
              </h1>
              <p className="text-sm text-gray-600 mt-1">
                {company?.name} - Detaylı performans analizleri
              </p>
            </div>
            <div className="flex items-center gap-3">
              {/* Tarih Aralığı Seçimi */}
              <div className="relative">
                <select
                  value={dateRange}
                  onChange={(e) => setDateRange(e.target.value)}
                  className="appearance-none bg-white border border-gray-300 rounded-lg px-4 py-2 pr-8 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                >
                  <option value="today">Bugün</option>
                  <option value="last7days">Son 7 Gün</option>
                  <option value="last30days">Son 30 Gün</option>
                  <option value="last90days">Son 90 Gün</option>
                  <option value="thisYear">Bu Yıl</option>
                </select>
                <Calendar className="absolute right-2 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
              </div>

              {/* Yenile Butonu */}
              <button
                onClick={refreshData}
                disabled={refreshing}
                className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
                Yenile
              </button>

              {/* İndir Butonu */}
              <button
                onClick={exportReport}
                className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
              >
                <Download className="w-4 h-4" />
                Raporu İndir
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Ana Metrikler */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard
            title="Toplam Görüntüleme"
            value={metrics.totalViews}
            previousValue={previousMetrics.totalViews}
            icon={Eye}
            color="bg-blue-600"
          />
          <MetricCard
            title="Benzersiz Ziyaretçi"
            value={metrics.uniqueVisitors}
            previousValue={previousMetrics.uniqueVisitors}
            icon={Users}
            color="bg-green-600"
          />
          <MetricCard
            title="Toplam Başvuru"
            value={metrics.totalApplications}
            previousValue={previousMetrics.totalApplications}
            icon={FileText}
            color="bg-purple-600"
          />
          <MetricCard
            title="Dönüşüm Oranı"
            value={parseFloat(metrics.conversionRate)}
            previousValue={previousMetrics.conversionRate}
            icon={Target}
            color="bg-orange-600"
            suffix="%"
          />
        </div>

        {/* İkinci Sıra Metrikler */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard
            title="Ortalama Yanıt Süresi"
            value={parseFloat(metrics.avgResponseTime)}
            icon={Clock}
            color="bg-indigo-600"
            suffix=" saat"
          />
          <MetricCard
            title="Kabul Oranı"
            value={parseFloat(metrics.acceptanceRate)}
            icon={CheckCircle}
            color="bg-emerald-600"
            suffix="%"
          />
          <MetricCard
            title="Aktif İş İlanı"
            value={metrics.activeJobs}
            icon={Briefcase}
            color="bg-pink-600"
          />
          <MetricCard
            title="Aktif Staj İlanı"
            value={metrics.activeInternships}
            icon={Award}
            color="bg-yellow-600"
          />
        </div>

        {/* Grafikler */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Görüntüleme Trendi */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Görüntüleme Trendi
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData.viewsTrend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line 
                  type="monotone" 
                  dataKey="views" 
                  stroke="#8b5cf6" 
                  strokeWidth={2}
                  dot={{ fill: '#8b5cf6' }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Başvuru Trendi */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Başvuru Trendi
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={chartData.applicationsTrend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Area 
                  type="monotone" 
                  dataKey="applications" 
                  stroke="#3b82f6" 
                  fill="#3b82f6"
                  fillOpacity={0.3}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Departman Dağılımı */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Departmanlara Göre Başvurular
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={chartData.departmentDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ department, percentage }) => `${department} (${percentage}%)`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="count"
                >
                  {chartData.departmentDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Dönüşüm Hunisi */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Dönüşüm Hunisi
            </h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData.conversionFunnel} layout="horizontal">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="stage" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#10b981">
                  {chartData.conversionFunnel.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Bilgi Kartı */}
        <div className="mt-8 bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl p-6 border border-purple-200">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-white rounded-lg shadow-sm">
              <TrendingUp className="w-6 h-6 text-purple-600" />
            </div>
            <div className="flex-1">
              <h4 className="font-semibold text-gray-900 mb-1">
                Performansınızı Artırın
              </h4>
              <p className="text-sm text-gray-600 mb-3">
                Dönüşüm oranınız sektör ortalamasının %{metrics.conversionRate > 15 ? 'üzerinde' : 'altında'}. 
                İlan açıklamalarınızı detaylandırarak ve daha hızlı yanıt vererek başvuru sayınızı artırabilirsiniz.
              </p>
              <div className="flex gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-purple-600" />
                  <span className="text-purple-700">Ortalama yanıt süresi: {metrics.avgResponseTime} saat</span>
                </div>
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-blue-600" />
                  <span className="text-blue-700">Hedef dönüşüm: %15</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}