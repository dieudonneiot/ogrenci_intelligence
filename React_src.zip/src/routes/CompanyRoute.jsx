import { useAuth } from "../contexts/AuthContext";
import { Navigate } from "react-router-dom";

export default function CompanyRoute({ children }) {
  const { userType, companyId, loading } = useAuth();

  if (loading) return <div className="p-8 text-center">Yükleniyor...</div>;

  if (userType !== "company" || !companyId) {
    return <Navigate to="/" replace />;
  }

  return children;
}