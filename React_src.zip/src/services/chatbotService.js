import supabase from '../utils/supabaseClient';
const OPENAI_API_KEY = import.meta.env.VITE_OPENAI_API_KEY;

// Chatbot mesajlarını kaydetmek için
export const saveChatMessage = async (userId, message, type) => {
  try {
    const { data, error } = await supabase
      .from('chat_messages')
      .insert({
        user_id: userId,
        message: message,
        type: type, // 'user' veya 'bot'
        created_at: new Date().toISOString()
      });

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error saving chat message:', error);
    return null;
  }
};

// Kullanıcının chat geçmişini getir
export const getChatHistory = async (userId, limit = 50) => {
  try {
    const { data, error } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: true })
      .limit(limit);

    if (error) throw error;
    return data || [];
  } catch (error) {
    console.error('Error fetching chat history:', error);
    return [];
  }
};

// Önceden tanımlanmış yanıtlar (FAQ)
export const FAQ_RESPONSES = {
  staj_basvuru: {
    keywords: ['staj', 'başvuru', 'nasıl', 'başvurabilirim'],
    response: `Staj başvurusu yapmak için şu adımları izleyebilirsiniz:

1. **Profil Tamamlama**: Öncelikle profilinizi %100 tamamlayın
2. **Staj İlanlarını İnceleyin**: 'Stajlar' bölümünden size uygun ilanları bulun
3. **CV Hazırlama**: Güncel ve özenli bir CV hazırlayın
4. **Başvuru**: İlan detayındaki 'Başvur' butonuna tıklayın

💡 İpucu: Her başvuru için özel bir ön yazı hazırlayın!`,
    followUp: ['CV örnekleri', 'Staj süreçleri', 'Başvuru takibi']
  },
  
  cv_hazirlama: {
    keywords: ['cv', 'özgeçmiş', 'resume', 'hazırlama'],
    response: `Etkili bir CV hazırlamak için önerilerim:

📌 **Temel İlkeler**:
• Maksimum 2 sayfa
• Profesyonel fotoğraf
• Güncel iletişim bilgileri
• ATS uyumlu format

📝 **İçerik Sıralaması**:
1. Kişisel bilgiler
2. Özet/Hedef
3. Eğitim bilgileri
4. İş/Staj deneyimleri
5. Projeler
6. Beceriler
7. Sertifikalar

💡 **İpucu**: Her başvuru için CV'nizi özelleştirin!`,
    followUp: ['CV şablonları', 'Örnek CV\'ler', 'ATS nedir?']
  },
  
  mulakat_ipucu: {
    keywords: ['mülakat', 'interview', 'görüşme', 'ipucu'],
    response: `Başarılı bir mülakat için tavsiyelerim:

🎯 **Hazırlık**:
• Şirketi araştırın
• Pozisyonu inceleyin
• STAR metodunu öğrenin
• Soru hazırlayın

👔 **Mülakat Günü**:
• Profesyonel giyinin
• 10-15 dk erken varın
• Göz teması kurun
• Aktif dinleyin

💬 **Sık Sorulan Sorular**:
• Kendinden bahset
• Neden bu şirket?
• Güçlü/zayıf yönlerin
• 5 yıl sonra nerede görüyorsun kendini?`,
    followUp: ['STAR metodu', 'Örnek sorular', 'Online mülakat']
  },
  
  bolumler: {
    keywords: ['bölüm', 'departman', 'alan', 'hangi'],
    response: `Platformumuzda şu bölümler için içerikler bulunmaktadır:

🔧 **Mühendislik**: 
• Yazılım, Bilgisayar, Elektrik, Makine

💼 **İşletme**: 
• Pazarlama, Finans, İK, Yönetim

🎨 **Tasarım**: 
• Grafik, UI/UX, Endüstriyel

🏥 **Sağlık**: 
• Tıp, Hemşirelik, Eczacılık

⚖️ **Hukuk**: 
• Avukatlık, Hukuk Müşavirliği

Hangi bölüm hakkında detaylı bilgi istersiniz?`,
    followUp: ['Yazılım Mühendisliği', 'İşletme', 'Tasarım']
  },
  
  staj_sureci: {
    keywords: ['staj', 'süreç', 'aşama', 'ne kadar'],
    response: `Tipik bir staj süreci şu aşamalardan oluşur:

📅 **Süreç Aşamaları**:
1. **Başvuru** (1-2 hafta)
2. **Ön Değerlendirme** (3-5 gün)
3. **Mülakat** (1-2 hafta)
4. **Sonuç** (3-7 gün)

⏱️ **Staj Süreleri**:
• Kısa dönem: 20-30 iş günü
• Uzun dönem: 40-60 iş günü
• Part-time: Haftada 2-3 gün

📋 **Staj Sonrası**:
• Staj defteri/raporu
• Referans mektubu
• İş teklifi imkanı`,
    followUp: ['Staj defteri', 'Sigorta işlemleri', 'Staj maaşı']
  }
};

// Basit bir keyword matching algoritması
export const findBestResponse = (userMessage) => {
  const lowerMessage = userMessage.toLowerCase();
  let bestMatch = null;
  let highestScore = 0;

  Object.entries(FAQ_RESPONSES).forEach(([key, faq]) => {
    let score = 0;
    faq.keywords.forEach(keyword => {
      if (lowerMessage.includes(keyword)) {
        score += 1;
      }
    });

    if (score > highestScore) {
      highestScore = score;
      bestMatch = faq;
    }
  });

  if (bestMatch && highestScore > 0) {
    return {
      text: bestMatch.response,
      suggestions: bestMatch.followUp
    };
  }

  // Varsayılan yanıt
  return {
    text: "Size nasıl yardımcı olabilirim? Staj süreçleri, bölüm bilgileri, CV hazırlama veya mülakat teknikleri hakkında sorularınızı yanıtlayabilirim. 😊",
    suggestions: ["Staj başvurusu", "CV hazırlama", "Mülakat ipuçları", "Bölümler"]
  };
};

// Gelişmiş chatbot için API çağrısı (OpenAI)
export const getAIResponse = async (userMessage, context = []) => {
  try {
    const faqResponse = findBestResponse(userMessage);
    if (faqResponse.text !== "Size nasıl yardımcı olabilirim?") {
      return faqResponse;
    }

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          { 
            role: 'system', 
            content: `Sen öğrencilere kariyer, staj ve eğitim konularında yardımcı olan bir asistansın. 
            Kısa, net ve Türkçe yanıtlar ver. 
            Öğrenci dostu bir dil kullan. 
            Gerektiğinde maddeler halinde sırala.`
          },
          ...context,
          { role: 'user', content: userMessage }
        ],
        temperature: 0.7,
        max_tokens: 500
      })
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error?.message || 'OpenAI API hatası');
    }

    return {
      text: data.choices[0].message.content.trim(),
      suggestions: []
    };
  } catch (error) {
    console.error('AI Response error:', error);
    return {
      text: 'Üzgünüm, bir hata oluştu. Lütfen daha sonra tekrar deneyin.',
      suggestions: []
    };
  }
};

// Chat session başlatma
export const startChatSession = async (userId) => {
  try {
    const { data, error } = await supabase
      .from('chat_sessions')
      .insert({
        user_id: userId,
        started_at: new Date().toISOString()
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error starting chat session:', error);
    return null;
  }
};

// Chat session güncelleme
export const updateChatSession = async (sessionId, updates) => {
  try {
    const { data, error } = await supabase
      .from('chat_sessions')
      .update(updates)
      .eq('id', sessionId)
      .select()
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error updating chat session:', error);
    return null;
  }
};

// Feedback kaydetme
export const saveFeedback = async (userId, messageId, isHelpful) => {
  try {
    const { data, error } = await supabase
      .from('chatbot_feedback')
      .insert({
        user_id: userId,
        message_id: messageId,
        is_helpful: isHelpful,
        created_at: new Date().toISOString()
      });

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error saving feedback:', error);
    return null;
  }
};