// src/services/pointsService.js

import { supabase } from '../utils/supabaseClient';

// Puan kategorileri ve değerleri
export const POINT_VALUES = {
  // Eğitim
  COURSE_ENROLLMENT: 10,
  COURSE_COMPLETION: 50,
  QUIZ_SUCCESS: 5,
  CERTIFICATE: 20,
  
  // Staj & İş
  JOB_APPLICATION: 5,
  INTERNSHIP_APPLICATION: 5,
  INTERNSHIP_ACCEPTED: 30,
  INTERNSHIP_COMPLETED: 100,
  JOB_ACCEPTED: 50,
  
  // Platform Aktivitesi
  DAILY_LOGIN: 2,
  WEEKLY_STREAK: 15,
  PROFILE_COMPLETION: 20,
  FIRST_APPLICATION: 10,
  
  // Başarılar
  TOP_10_DEPARTMENT: 50,
  FAST_LEARNER: 25, // 1 ayda 3 kurs
  INTERNSHIP_MASTER: 40, // 3 farklı staj
  SUPER_STUDENT: 100, // 1000 puan barajı
};

// Puan ekleme
export const addPoints = async (userId, category, action, points, description = null, metadata = null) => {
  try {
    // RPC fonksiyonunu çağır
    const { data, error } = await supabase.rpc('add_activity_and_points', {
      p_user_id: userId,
      p_category: category,
      p_action: action,
      p_points: points,
      p_description: description,
      p_metadata: metadata
    });

    if (error) throw error;

    return { success: true, activityId: data };
  } catch (error) {
    console.error('Puan ekleme hatası:', error);
    return { success: false, error: error.message };
  }
};

// Kullanıcının toplam puanını getir
export const getUserTotalPoints = async (userId) => {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('total_points')
      .eq('id', userId)
      .single();

    if (error) throw error;

    return data?.total_points || 0;
  } catch (error) {
    console.error('Toplam puan getirme hatası:', error);
    return 0;
  }
};

// Kullanıcının puan geçmişini getir
export const getUserPointsHistory = async (userId, limit = 50) => {
  try {
    const { data, error } = await supabase
      .from('user_points')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) throw error;

    return data || [];
  } catch (error) {
    console.error('Puan geçmişi getirme hatası:', error);
    return [];
  }
};

// Aktivite loglarını getir
export const getUserActivityLogs = async (userId, limit = 20) => {
  try {
    const { data, error } = await supabase
      .from('activity_logs')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) throw error;

    return data || [];
  } catch (error) {
    console.error('Aktivite logları getirme hatası:', error);
    return [];
  }
};

// Bölüm bazlı liderlik tablosu
export const getDepartmentLeaderboard = async (department, limit = 10) => {
  try {
    const { data, error } = await supabase
      .from('department_leaderboard')
      .select(`
        user_id,
        department,
        total_points,
        rank_in_department,
        profiles!inner(email, full_name)
      `)
      .eq('department', department)
      .order('rank_in_department', { ascending: true })
      .limit(limit);

    if (error) throw error;

    return data || [];
  } catch (error) {
    console.error('Liderlik tablosu getirme hatası:', error);
    return [];
  }
};

// Genel liderlik tablosu
export const getOverallLeaderboard = async (limit = 50) => {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('id, email, full_name, department, total_points')
      .order('total_points', { ascending: false })
      .limit(limit);

    if (error) throw error;

    // Sıralama ekle
    return data?.map((user, index) => ({
      ...user,
      rank: index + 1
    })) || [];
  } catch (error) {
    console.error('Genel liderlik tablosu getirme hatası:', error);
    return [];
  }
};

// Başarı rozetlerini kontrol et ve ekle
export const checkAndAwardBadges = async (userId) => {
  try {
    const totalPoints = await getUserTotalPoints(userId);
    
    // 1000 puan başarısı
    if (totalPoints >= 1000) {
      await awardBadge(userId, 'super_student', 'Süper Öğrenci', 
        '1000 puan barajını geçtiniz!', '🏆', POINT_VALUES.SUPER_STUDENT);
    }
    
    // Diğer başarılar için kontroller eklenebilir
    
    return { success: true };
  } catch (error) {
    console.error('Rozet kontrol hatası:', error);
    return { success: false, error: error.message };
  }
};

// Rozet ver
const awardBadge = async (userId, badgeType, title, description, icon, points) => {
  try {
    // Daha önce verilmiş mi kontrol et
    const { data: existing } = await supabase
      .from('user_badges')
      .select('id')
      .eq('user_id', userId)
      .eq('badge_type', badgeType)
      .single();

    if (existing) return; // Zaten verilmiş

    // Rozeti ekle
    const { error } = await supabase
      .from('user_badges')
      .insert({
        user_id: userId,
        badge_type: badgeType,
        badge_title: title,
        badge_description: description,
        icon: icon,
        points_awarded: points
      });

    if (error) throw error;

    // Puan ekle
    await addPoints(userId, 'achievement', badgeType, points, description);

  } catch (error) {
    console.error('Rozet verme hatası:', error);
  }
};

// Günlük giriş puanı kontrolü
export const checkDailyLogin = async (userId) => {
  try {
    // Bugünün başlangıcı ve bitişi (UTC)
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayStart = today.toISOString();
    
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const todayEnd = tomorrow.toISOString();
    
    // Bugün için daily_login kaydı var mı kontrol et
    const { data: existingLogin, error } = await supabase
      .from('activity_logs')
      .select('id')
      .eq('user_id', userId)
      .eq('action', 'daily_login')
      .gte('created_at', todayStart)
      .lt('created_at', todayEnd);

    // Eğer bugün için kayıt yoksa puan ver
    if (!error && (!existingLogin || existingLogin.length === 0)) {
      // Günlük giriş puanı ver
      await addPoints(
        userId, 
        'platform', 
        'daily_login', 
        POINT_VALUES.DAILY_LOGIN,
        'Günlük giriş bonusu'
      );
      
      return { alreadyLoggedIn: false };
    }

    return { alreadyLoggedIn: true };
  } catch (error) {
    console.error('Günlük giriş kontrolü hatası:', error);
    return { alreadyLoggedIn: true }; // Hata durumunda puan verme
  }
};

// Haftalık seri kontrolü
export const checkWeeklyStreak = async (userId) => {
  try {
    // Son 7 günün giriş sayısını kontrol et
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const { data, error } = await supabase
      .from('activity_logs')
      .select('created_at')
      .eq('user_id', userId)
      .eq('action', 'daily_login')
      .gte('created_at', sevenDaysAgo.toISOString())
      .order('created_at', { ascending: false });

    if (error) throw error;

    // 7 farklı gün giriş yapmış mı kontrol et
    const uniqueDays = new Set(
      data?.map(log => new Date(log.created_at).toISOString().split('T')[0])
    );

    if (uniqueDays.size >= 7) {
      // Son hafta içinde zaten ödül almış mı kontrol et
      const { data: existingReward } = await supabase
        .from('activity_logs')
        .select('id')
        .eq('user_id', userId)
        .eq('action', 'weekly_streak')
        .gte('created_at', sevenDaysAgo.toISOString())
        .single();

      if (!existingReward) {
        await addPoints(
          userId,
          'platform',
          'weekly_streak',
          POINT_VALUES.WEEKLY_STREAK,
          '7 gün üst üste giriş yaptınız!'
        );
        return { streakAwarded: true };
      }
    }

    return { streakAwarded: false, currentStreak: uniqueDays.size };
  } catch (error) {
    console.error('Haftalık seri kontrolü hatası:', error);
    return { streakAwarded: false, currentStreak: 0 };
  }
};