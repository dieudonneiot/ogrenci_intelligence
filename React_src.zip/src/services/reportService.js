import supabase from "../utils/supabaseClient";

// İlan görüntülemelerini kaydet
export const trackJobView = async (jobId, userId = null) => {
  try {
    const { error } = await supabase
      .from('job_views')
      .insert({
        job_id: jobId,
        user_id: userId,
        ip_address: await getUserIP(),
        user_agent: navigator.userAgent,
        session_id: getSessionId()
      });

    if (error) throw error;
  } catch (error) {
    console.error('Görüntüleme kaydı hatası:', error);
  }
};

// Staj görüntülemelerini kaydet
export const trackInternshipView = async (internshipId, userId = null) => {
  try {
    const { error } = await supabase
      .from('internship_views')
      .insert({
        internship_id: internshipId,
        user_id: userId,
        ip_address: await getUserIP(),
        user_agent: navigator.userAgent,
        session_id: getSessionId()
      });

    if (error) throw error;
  } catch (error) {
    console.error('Görüntüleme kaydı hatası:', error);
  }
};

// Şirket metriklerini getir
export const getCompanyMetrics = async (companyId, dateRange = 'last30days') => {
  const startDate = getStartDateForRange(dateRange);
  
  try {
    // Önce cache'i kontrol et
    const { data: cachedReport } = await supabase
      .from('report_cache')
      .select('*')
      .eq('company_id', companyId)
      .eq('report_type', 'metrics')
      .gte('expires_at', new Date().toISOString())
      .single();

    if (cachedReport) {
      return cachedReport.report_data;
    }

    // Cache yoksa yeni hesapla
    const metrics = await calculateCompanyMetrics(companyId, startDate);
    
    // Cache'e kaydet
    await supabase
      .from('report_cache')
      .insert({
        company_id: companyId,
        report_type: 'metrics',
        report_data: metrics,
        expires_at: new Date(Date.now() + 3600000).toISOString(), // 1 saat
        parameters: { dateRange }
      });

    return metrics;
  } catch (error) {
    console.error('Metrik getirme hatası:', error);
    throw error;
  }
};

// Detaylı rapor oluştur
export const generateDetailedReport = async (companyId, reportType, parameters) => {
  try {
    let reportData = {};

    switch(reportType) {
      case 'performance':
        reportData = await generatePerformanceReport(companyId, parameters);
        break;
      case 'candidates':
        reportData = await generateCandidateReport(companyId, parameters);
        break;
      case 'conversion':
        reportData = await generateConversionReport(companyId, parameters);
        break;
      default:
        throw new Error('Geçersiz rapor tipi');
    }

    return reportData;
  } catch (error) {
    console.error('Rapor oluşturma hatası:', error);
    throw error;
  }
};

// Yardımcı fonksiyonlar
const getStartDateForRange = (range) => {
  const now = new Date();
  switch(range) {
    case 'today':
      return new Date(now.setHours(0,0,0,0));
    case 'last7days':
      return new Date(now.setDate(now.getDate() - 7));
    case 'last30days':
      return new Date(now.setDate(now.getDate() - 30));
    case 'last90days':
      return new Date(now.setDate(now.getDate() - 90));
    case 'thisYear':
      return new Date(now.getFullYear(), 0, 1);
    default:
      return new Date(now.setDate(now.getDate() - 30));
  }
};

const calculateCompanyMetrics = async (companyId, startDate) => {
  // İş ilanları
  const { data: jobs } = await supabase
    .from('jobs')
    .select('id')
    .eq('company_id', companyId)
    .eq('is_active', true);

  const jobIds = jobs?.map(j => j.id) || [];

  // Görüntülemeler
  const { count: totalViews } = await supabase
    .from('job_views')
    .select('*', { count: 'exact', head: true })
    .in('job_id', jobIds)
    .gte('viewed_at', startDate.toISOString());

  // Benzersiz ziyaretçiler
  const { data: uniqueViewers } = await supabase
    .from('job_views')
    .select('user_id, ip_address')
    .in('job_id', jobIds)
    .gte('viewed_at', startDate.toISOString());

  const uniqueVisitors = new Set(
    uniqueViewers?.map(v => v.user_id || v.ip_address)
  ).size;

  // Başvurular
  const { data: applications } = await supabase
    .from('job_applications')
    .select('*')
    .in('job_id', jobIds)
    .gte('applied_at', startDate.toISOString());

  const totalApplications = applications?.length || 0;
  const acceptedApplications = applications?.filter(a => a.status === 'accepted').length || 0;
  const rejectedApplications = applications?.filter(a => a.status === 'rejected').length || 0;
  const pendingApplications = applications?.filter(a => a.status === 'pending').length || 0;

  // Yanıt süreleri
  const responseTimes = applications
    ?.filter(a => a.status !== 'pending')
    .map(a => {
      const applied = new Date(a.applied_at);
      const responded = new Date(a.updated_at);
      return (responded - applied) / (1000 * 60 * 60); // Saat
    }) || [];

  const avgResponseTime = responseTimes.length > 0
    ? responseTimes.reduce((a, b) => a + b) / responseTimes.length
    : 0;

  return {
    totalViews: totalViews || 0,
    uniqueVisitors,
    totalApplications,
    acceptedApplications,
    rejectedApplications,
    pendingApplications,
    conversionRate: totalViews > 0 ? (totalApplications / totalViews * 100) : 0,
    acceptanceRate: totalApplications > 0 ? (acceptedApplications / totalApplications * 100) : 0,
    avgResponseTime: avgResponseTime.toFixed(1)
  };
};

const generatePerformanceReport = async (companyId, parameters) => {
  // Performans raporu logic
  const startDate = getStartDateForRange(parameters.dateRange);
  
  // Günlük metrikler
  const dailyMetrics = [];
  for (let i = 0; i < 30; i++) {
    const date = new Date(startDate);
    date.setDate(date.getDate() + i);
    
    const dayMetrics = await calculateCompanyMetrics(companyId, date);
    dailyMetrics.push({
      date: date.toISOString().split('T')[0],
      ...dayMetrics
    });
  }

  return {
    summary: await calculateCompanyMetrics(companyId, startDate),
    daily: dailyMetrics,
    trends: calculateTrends(dailyMetrics)
  };
};

const generateCandidateReport = async (companyId, parameters) => {
  const { data: applications } = await supabase
    .from('job_applications')
    .select(`
      *,
      profile:profiles(*),
      job:jobs(title, department)
    `)
    .eq('job.company_id', companyId)
    .gte('applied_at', getStartDateForRange(parameters.dateRange).toISOString());

  // Departman dağılımı
  const departmentDistribution = {};
  applications?.forEach(app => {
    const dept = app.profile?.department || 'Belirtilmemiş';
    departmentDistribution[dept] = (departmentDistribution[dept] || 0) + 1;
  });

  // Sınıf dağılımı
  const yearDistribution = {};
  applications?.forEach(app => {
    const year = app.profile?.year || 0;
    yearDistribution[year] = (yearDistribution[year] || 0) + 1;
  });

  return {
    totalCandidates: applications?.length || 0,
    departmentDistribution,
    yearDistribution,
    topCandidates: applications?.slice(0, 10) || []
  };
};

const generateConversionReport = async (companyId, parameters) => {
  const startDate = getStartDateForRange(parameters.dateRange);
  
  // Dönüşüm hunisi verileri
  const { data: jobs } = await supabase
    .from('jobs')
    .select('id')
    .eq('company_id', companyId);

  const jobIds = jobs?.map(j => j.id) || [];

  const { count: views } = await supabase
    .from('job_views')
    .select('*', { count: 'exact', head: true })
    .in('job_id', jobIds)
    .gte('viewed_at', startDate.toISOString());

  const { count: applications } = await supabase
    .from('job_applications')
    .select('*', { count: 'exact', head: true })
    .in('job_id', jobIds)
    .gte('applied_at', startDate.toISOString());

  const { count: interviews } = await supabase
    .from('job_applications')
    .select('*', { count: 'exact', head: true })
    .in('job_id', jobIds)
    .not('interview_date', 'is', null)
    .gte('applied_at', startDate.toISOString());

  const { count: accepted } = await supabase
    .from('job_applications')
    .select('*', { count: 'exact', head: true })
    .in('job_id', jobIds)
    .eq('status', 'accepted')
    .gte('applied_at', startDate.toISOString());

  return {
    funnel: [
      { stage: 'Görüntüleme', count: views || 0, rate: 100 },
      { stage: 'Başvuru', count: applications || 0, rate: views > 0 ? (applications / views * 100) : 0 },
      { stage: 'Mülakat', count: interviews || 0, rate: applications > 0 ? (interviews / applications * 100) : 0 },
      { stage: 'Kabul', count: accepted || 0, rate: interviews > 0 ? (accepted / interviews * 100) : 0 }
    ],
    conversionRate: views > 0 ? (applications / views * 100) : 0,
    interviewRate: applications > 0 ? (interviews / applications * 100) : 0,
    acceptanceRate: interviews > 0 ? (accepted / interviews * 100) : 0
  };
};

const calculateTrends = (dailyMetrics) => {
  if (dailyMetrics.length < 2) return {};

  const lastWeek = dailyMetrics.slice(-7);
  const previousWeek = dailyMetrics.slice(-14, -7);

  const calculateChange = (current, previous) => {
    if (previous === 0) return 0;
    return ((current - previous) / previous * 100).toFixed(1);
  };

  const currentViews = lastWeek.reduce((sum, day) => sum + day.totalViews, 0);
  const previousViews = previousWeek.reduce((sum, day) => sum + day.totalViews, 0);

  const currentApps = lastWeek.reduce((sum, day) => sum + day.totalApplications, 0);
  const previousApps = previousWeek.reduce((sum, day) => sum + day.totalApplications, 0);

  return {
    viewsTrend: calculateChange(currentViews, previousViews),
    applicationsTrend: calculateChange(currentApps, previousApps),
    conversionTrend: calculateChange(
      currentViews > 0 ? currentApps / currentViews : 0,
      previousViews > 0 ? previousApps / previousViews : 0
    )
  };
};

// Session ID yönetimi
const getSessionId = () => {
  let sessionId = sessionStorage.getItem('session_id');
  if (!sessionId) {
    sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    sessionStorage.setItem('session_id', sessionId);
  }
  return sessionId;
};

// IP adresi alma (örnek)
const getUserIP = async () => {
  try {
    const response = await fetch('https://api.ipify.org?format=json');
    const data = await response.json();
    return data.ip;
  } catch (error) {
    return null;
  }
};

export default {
  trackJobView,
  trackInternshipView,
  getCompanyMetrics,
  generateDetailedReport
};